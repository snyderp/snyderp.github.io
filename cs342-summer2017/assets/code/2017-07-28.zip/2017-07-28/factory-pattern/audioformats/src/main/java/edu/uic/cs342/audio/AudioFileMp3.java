package edu.uic.cs342.audio;

import java.nio.file.Path;

public class AudioFileMp3 extends AudioFile implements AudioFormatInterface {

    public AudioFileMp3(Path file) {
        super(file);
    }

    public Integer getDuration() {
        // Do some file analysis to determine the length of this MP3
        return null;
    }

    public String getFormatName() {
        return "MPEG-2 Audio Layer III";
    }
}
package edu.uic.cs342.audio;

public interface AudioFormatInterface {

    public Integer getDuration();

    public String getFormatName();
}
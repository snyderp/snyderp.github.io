package edu.uic.cs342.audio;

import edu.uic.cs342.miditools.MidiFile;
import java.nio.file.Path;

public class AudioFileMidi implements AudioFormatInterface {

    private MidiFile someFile;

    public AudioFileMidi(MidiFile file) {
        this.someFile = file;
    }

    public Integer getDuration() {
        return (this.someFile.getNumMinutes() * 60) +
            this.someFile.getNumSeconds();
    }

    public String getFormatName() {
        return "MIDI";
    }
}
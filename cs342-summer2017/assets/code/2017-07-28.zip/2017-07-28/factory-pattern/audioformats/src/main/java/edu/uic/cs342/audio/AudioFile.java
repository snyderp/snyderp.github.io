package edu.uic.cs342.audio;

import java.nio.file.Path;

public class AudioFile {

    protected Path audioFile;

    public AudioFile(Path file) {
        this.audioFile = file;
    }
}
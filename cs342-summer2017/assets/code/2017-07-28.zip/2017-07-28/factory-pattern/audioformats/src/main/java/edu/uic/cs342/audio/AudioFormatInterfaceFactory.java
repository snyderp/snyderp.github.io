package edu.uic.cs342.audio;

import java.nio.file.Path;

public class AudioFormatInterfaceFactory {

    static public AudioFormatInterface getFormatInterface(Path input) {

        String normalizedPath = input.toString().toLowerCase();

        AudioFormatInterface audioFile = null;

        if (normalizedPath.endsWith(".mp3")) {
            AudioFileMp3 mp3File = new AudioFileMp3(input);
            audioFile = mp3File;
        } else if (normalizedPath.endsWith(".wav")) {
            AudioFileWav wavFile = new AudioFileWav(input);
            audioFile = wavFile;
        } else if (normalizedPath.endsWith(".flac")) {
            AudioFileFlac wavFile = new AudioFileFlac(input);
            audioFile = wavFile;
        } else if (normalizedPath.endsWith(".midi")) {
            AudioFileMidi midiFile = new AudioFileMidi(input.toFile());
            audioFile = midiFile;
        } else {
            System.err.println("Unable to determine type of audio file.");
            System.exit(1);
        }

        return audioFile;
    }
}
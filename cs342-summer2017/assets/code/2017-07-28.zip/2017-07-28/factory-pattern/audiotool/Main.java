import java.nio.file.Paths;
import java.nio.file.Path;
import edu.uic.cs342.audio.AudioFormatInterfaceFactory;
import edu.uic.cs342.audio.AudioFormatInterface;


public class Main {

    public static void main(String[] args) throws Exception {

        String normalizedPath = args[0].toLowerCase();
        Path inputFile = Paths.get(args[0]);

        AudioFormatInterface audioFile = AudioFormatInterfaceFactory.getFormatInterface(inputFile);

        System.out.printf("Type: %s\n", audioFile.getFormatName());
        System.out.printf("Length: %d\n", audioFile.getDuration());
    }
}

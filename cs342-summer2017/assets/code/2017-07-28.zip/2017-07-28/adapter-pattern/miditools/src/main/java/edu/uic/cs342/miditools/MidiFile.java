package edu.uic.cs342.miditools;

import java.io.File;

public class MidiFile {

    protected File midiSource;

    public MidiFile(File input) {
        this.midiSource = input;
    }

    public Integer getNumSeconds() {
        return null;
    }

    public Integer getNumMinutes() {
        return null;
    }

    public Integer getNumTracks() {
        return null;
    }
}
// Minimize State
// ---
class MathMagic {
    protected static int currentTotal = 0;
    public static int add(int newAmount) {
        MathMagic.currentTotal += newAmount;
        return MathMagic.currentTotal;
    }
}

MathMagic.add(2);  // Whats the correct output?
MathMagic.add(2);  // And this time?





// Dependency Injection
// ---
class DBUserInfo {

  // Connection to postgres server
  private Connection db = DriverManager.getConnection("url", "username", "password");

  public Integer numLoginsForUser(int primaryKey) {
    Integer returnValue = null;

    Statement st = this.db.createStatement();
    PreparedStatement st = conn.prepareStatement("SELECT COUNT(*) FROM logins WHERE user_id = ?");
    st.setInt(primaryKey);

    while (rs.next()) {
      returnValue = rs.getInteger(1);
      break;
    }

    return returnValue;
  }
}

DBUserInfo userInfo = new DBUserInfo();
userInfo.numLoginsForUser(3); // How to test?





// Push functionality into the class, state into the caller -> HW4

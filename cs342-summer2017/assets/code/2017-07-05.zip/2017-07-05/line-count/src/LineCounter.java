import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.stream.Collectors;

public class LineCounter {
  public Integer countLines(File aFile) throws java.io.IOException {

    String fullText = new String(Files.readAllBytes(aFile.toPath()));
    return fullText.split("\n").length;
  }
}

import java.util.HashMap;

public class Main {

  /**
    "data/1-lisa-on-ice.txt",
    "data/2-a-star-is-burns.txt",
    "data/3-homie-the-clown.txt"
  */

  public static void main(String[] args) {
    LineCounter counter = new LineCounter();
    try {
      System.out.println(counter.countLines(new java.io.File(args[0])));
    } catch (java.io.IOException error) {
      System.err.print(error.toString());
      System.exit(1);
    }
  }
}

package cs342;

import java.util.List;
import java.util.Arrays;
import java.util.stream.Collectors;

public class SentenceParser {

  public List<String> parseSentences(String inputText) {

    String[] sentences = inputText.replace("\n", " ").split("\\.");
    return Arrays.asList(sentences).stream()
        .map(x -> x.trim() + ".")
        .collect(Collectors.toList());
  }
}

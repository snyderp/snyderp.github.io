import java.util.stream.Collectors;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import cs342.SentenceParser;


public class Main {

  public static void main(String[] args) {
    Charset utf8CharSet = Charset.forName("UTF-8");
    File inputFile = new File(args[0]);

    List<String> inputLines;

    try {
      inputLines = Files.readAllLines(inputFile.toPath(), utf8CharSet);
    }
    catch (IOException error) {
      System.err.print(error.toString());
      System.exit(1);
      return;
    }

    String combinedString = inputLines.stream().collect(Collectors.joining("\n"));

    SentenceParser parser = new SentenceParser();
    List<String> sentences = parser.parseSentences(combinedString);
    Integer index = 0;
    for (String sentence : sentences) {
      index += 1;
      System.out.printf("%d. %s\n", index, sentence);
    }
  }
}

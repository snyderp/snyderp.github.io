import org.junit.Test;
import org.junit.Assert;


public class OperationsTest {

  @Test
  public void addTest() {
    Operations calc = new Operations();
    double result = calc.add(1, 2);
    Assert.assertEquals(3, result, .1);
  }

  @Test
  public void subTest() {
    Operations calc = new Operations();
    double result = calc.subtract(1, 2);
    Assert.assertEquals(-1, result, .1);
  }
}

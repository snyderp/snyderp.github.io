public class Main {
  public static void main(String ...args) {

    if (args.length < 3) {
      System.err.println("Error: Not enough arguments.");
      System.err.println("Usage: <first parameter> [+-*/] <second parameter>");
      System.exit(1);
    }

    Operations myLilCal = new Operations();

    try {
      System.out.println(myLilCal.calculate(args[0], args[1], args[2]));
      System.exit(0);
    } catch (IllegalArgumentException error) {
      System.err.println("Error: "  + error.getMessage());
      System.exit(1);
    }
  }
}

public class Operations {

  public double calculate(String first, String operation, String second) throws IllegalArgumentException {
    double firstAsDouble;
    double secondAsDouble;

    try {
      firstAsDouble = Double.parseDouble(first);
    } catch (NumberFormatException error) {
      throw new IllegalArgumentException(first + " could not be parsed as a double");
    }

    try {
      secondAsDouble = Double.parseDouble(second);
    } catch (NumberFormatException error) {
      throw new IllegalArgumentException(second + " could not be parsed as a double");
    }

    switch (operation) {
      case "+":
        return this.add(firstAsDouble, secondAsDouble);

      case "-":
        return this.subtract(firstAsDouble, secondAsDouble);

      case "*":
        return this.multiply(firstAsDouble, secondAsDouble);

      case "/":
        return this.divide(firstAsDouble, secondAsDouble);

      default:
        throw new IllegalArgumentException(operation + " did not match a supported operation [+-*/]");
    }
  }

  public double add(double first, double second) {
    return first + second;
  }

  public double subtract(double first, double second) {
    return first - second;
  }

  public double multiply(double first, double second) {
    if (first == 0.0d || second == 0.0d) {
      return 0.0d;
    }

    return first * second;
  }

  public double divide(double first, double second) {
    if (first == second) {
      return 1.0d;
    }

    return first / second;
  }
}

import java.lang.Thread;

interface Laterable {
  public void call();
}

// This class should allow us to do some arbitrary functionality in the future
public class InTheFuture {
  public void callLater(Integer seconds, Laterable toDo) {
    Thread.sleep(seconds);
    toDo.call();
  }
}

public class Caller {

  protected static class Printer implements Laterable {
    public void call() {
      System.out.print("HERE");
    }
  }

  public static void main(String[] args) {
    // We'd like to print each provided string off, pausing one second between
    // each one, and then print a nice message to the user in the future.
    InTheFuture future = new InTheFuture();
    future.callLater(3, new Printer());
  }
}

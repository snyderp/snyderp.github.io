/**
 * Code that selects an T at random from a given set of Ts.
 */

import java.util.Random;
import java.util.ArrayList;

public class Randomizer<T> {

  ArrayList<T> myInts = new ArrayList<>();

  Randomizer(T ...manyInts) {
    for (T anInt : manyInts) {
      this.myInts.add(anInt);
    }
  }

  public T pickOne() {

    Random randGenerator = new Random();
    int randInt = Math.abs(randGenerator.nextInt());
    int numItems = this.myInts.size();

    return myInts.get(randInt % numItems);
  }
}

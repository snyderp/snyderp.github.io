public class Main {
  public static void main(String[] args) {
   HashMap<String, Integer> numMapping = new HashMap<>();
   numMapping.set("one", 1);

   HashReverser reverser = new HashReverser();
   HashMap<Integer, String> reversedMapping = reverser.reverse(numMapping);
  }
}

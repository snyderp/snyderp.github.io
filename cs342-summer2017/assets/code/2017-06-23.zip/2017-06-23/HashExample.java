import java.util.HashMap;

public class HashExample {
  public static void main(String[] args) {
    HashMap<Integer, String> myMapping = new HashMap<>();
    myMapping.set(1, "one");
    myMapping.set(2, "two");


  }
}

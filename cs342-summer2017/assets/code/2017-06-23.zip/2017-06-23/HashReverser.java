import java.util.HashMap;

public class HashReverser {
  public HashMap<V, K> reverse(HashMap<K, V> initalMapping) {
    HashMap<V, K> reversedMapping = new HashMap<>();
    for (K aKey : initalMapping.keySet()) {
      V theValue = initalMapping.get(aKey);
      reversedMapping.set(theValue, aKey);
    }

    return reversedMapping;
  }
}

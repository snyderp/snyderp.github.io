public class CreditCardAccount {

  public boolean creditAccount(float someAmount) {

    // Some code that sends money to a credit card account
  }

  public boolean chargeAccount(float someAmount) {

    // Some code that takes money from a credit card account
  }

  protected boolean ping() {
    // Some code that sends a "ping" charge to a credit card
  }
}

public class VisaClass extends CreditCardAccount {

  public boolean creditAccount(...) {
    super.creditAccount();
  }
}


CreditCardAccount anAccount = new CreditCardAccount();
anAccount.ping();
if (anAccount.creditAccount(50.00) == true) {
  // Celebrate!
} else {
  // Something went wrong...
}

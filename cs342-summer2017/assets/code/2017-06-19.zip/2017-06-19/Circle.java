/**
 * Code example, showing how one could use static properties to store
 * constants or refactor code.
 */

public class Circle {

  public static double pi = 3.14;
  private float radius = 0;

  public static double area(ArrayList<Circle> circles) {

  }

  Circle(float myRadius) {
    this.radius = myRadius;
  }

  public double area() {
    return Circle.pi * this.radius * this.radius;
  }
}

Circle.area();

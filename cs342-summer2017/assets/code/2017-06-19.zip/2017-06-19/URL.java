/**
 * @file
 * Guts of a commandline tool to check and see if the UIC website is up
 * and functioning correctly.
 */

/**
 * URL
 *  public URLConnection openConnection() throws IOException
 * URLConnection
 *  public String getResponseCode() throws IOException
*/

URL url = new URL("https://uic.edu");
URLConnection uicConnection = url.openConnection();
int response = uicConnection.getResponseCode();

if (response < 300) {
    System.out.println("Website looks good");
} else {
    System.out.println("Website seems bad, its dun gone wrong.");
}

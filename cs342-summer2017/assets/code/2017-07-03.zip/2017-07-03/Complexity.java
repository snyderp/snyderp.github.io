import java.util.Arrays;

/**
 * This code is an example of how to consider code as a call graph.
 */
public class Complexity {
  public static void main(String[] args) {

    boolean isInArray = Arrays.asList(args).contains("important");
    System.out.printLn(isInArray);
  }
}

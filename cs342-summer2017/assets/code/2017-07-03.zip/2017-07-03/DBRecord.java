public class DBRecord {
  public Integer idColumn;
  public String nameColumn;
  public Integer favoriteNumberColumn;

  DBRecord(Integer idToLoad) {

  }

  public boolean load(Integer idToLoad) {
    // Call to the database to get latest values.
    // Populate object with those values
    return true;
  }

  public boolean resync() {
    // Push values from object back into the database.
    return true;
  }
}

public class Expensive {
  FileCacher cache = new FileCacher();

  public String expensiveOperation() {
    // Do a HTTP request to a slow server, takes 1 minute to fetch
    String httpResponseBody = "this was what we were looking for.";
    return httpResponseBody;
  }
}

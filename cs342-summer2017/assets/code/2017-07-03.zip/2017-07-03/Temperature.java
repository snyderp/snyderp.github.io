public class Temperature {
  public Integer degreeFahrenheit;

  public String toString() {
    return String.valueOf(this.degreeFahrenheit) + "°F";
  }
}

/**
 * What if we wanted to add the ability to store Celsius values?
 */

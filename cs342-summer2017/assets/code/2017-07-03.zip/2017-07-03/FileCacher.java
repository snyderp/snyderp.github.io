import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class FileCacher {

  public void put(String key, bytes[] data) {
    Path destination = new Path("/tmp/" + key);
    Files.write(destination, data, StandardOpenOption.APPEND);
  }

  public bytes[] get(String key) {
    Path destination = new Path("/tmp/" + key);
    return Files.readAllBytes(destination);
  }
}

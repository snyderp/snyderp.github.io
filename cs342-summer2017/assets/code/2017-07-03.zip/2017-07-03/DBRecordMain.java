public class DBRecordMain {
  public static void main(String[] args) {

    DBRecord aRecord = new DBRecord(3);
  }
}

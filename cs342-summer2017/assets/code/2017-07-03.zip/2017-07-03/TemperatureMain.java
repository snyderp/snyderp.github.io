public class TemperatureMain {
  public static void main(String[] args) {

    Temperature theTemp = new Temperature();
    theTemp.degreeFahrenheit = 72;

    System.out.print(theTemp.toString());
  }
}

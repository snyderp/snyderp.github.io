import java.net.HttpUrlConnection;

public class JSONSender {

  private JSONObject someJson;

  public boolean sendToAddress(URL targetUrl) {
    // Code to send JSON over the network to some address/
    connection = (HttpURLConnection) url.openConnection();
    connection.setRequestMethod("POST");
    connection.setRequestProperty("Content-Type",
        "application/x-www-form-urlencoded");

    String urlParameters = "json=" + this.someJson.toString();

    connection.setRequestProperty("Content-Length",
        Integer.toString(urlParameters.getBytes().length));
    connection.setRequestProperty("Content-Language", "en-US");

    connection.setUseCaches(false);
    connection.setDoOutput(true);

    DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
    wr.writeBytes(urlParameters);
    wr.close();

    // etc etc etc

    InputStream is = connection.getInputStream();
    return this.isValidHTTPResponse(is);
  }

  private boolean isValidHTTPResponse(InputStream serverResponse) {
    // Code to check if this is valid HTTP, and if it looks like a 200 response
  }

  public JSONSender setJson(JSONObject someJsonObject) {
    this.someJson = someJsonObject;
  }
}

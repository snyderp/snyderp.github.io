import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.channels.AsynchronousChannelGroup;
import java.net.InetSocketAddress;
import java.nio.channels.CompletionHandler;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.CountDownLatch;



public class AsyncServer {

  public static class OnSocketWrite implements CompletionHandler<Integer, Void> {

    protected AsynchronousSocketChannel socket;
    protected ByteBuffer buffer;

    OnSocketWrite(AsynchronousSocketChannel socket, ByteBuffer buffer) {
      this.socket = socket;
      this.buffer = buffer;
    }

    public void completed(Integer result, Void ignore) {
      if (result != 0) {
        socket.write(this.buffer, null, this);
      }
    }

    public void failed(Throwable error, Void ignore) {
      try {
        this.socket.close();
      } catch (Exception err) {}
    }
  }



  public static class OnFileRead implements CompletionHandler<Integer, ByteBuffer> {

    protected AsynchronousSocketChannel socket;

    OnFileRead(AsynchronousSocketChannel socket) {
      this.socket = socket;
    }

    public void completed(Integer result, ByteBuffer data) {
      data.limit(result);
      data.rewind();
      this.socket.write(data, null, new OnSocketWrite(this.socket, data));
    }

    public void failed(Throwable error, ByteBuffer data) {
      try {
        this.socket.close();
      } catch (Exception err) {}
    }
  }



  public static class OnSocketRead implements CompletionHandler<Integer, ByteBuffer> {

    protected AsynchronousSocketChannel socket;

    OnSocketRead(AsynchronousSocketChannel socket) {
      this.socket = socket;
    }

    public void completed(Integer result, ByteBuffer data) {

      byte fileToReadByte = data.get(0);
      byte[] fileToReadArray = {fileToReadByte};
      Charset ascii = Charset.forName("US-ASCII");
      String fileNameToRead = new String(fileToReadArray, ascii);
      Path fileToRead = Paths.get("files", fileNameToRead + ".data");

      ByteBuffer readBuffer = ByteBuffer.allocate(500_000_000);

      try {

        AsynchronousFileChannel fileChannel = AsynchronousFileChannel.open(fileToRead, StandardOpenOption.READ);
        fileChannel.read(readBuffer, 0, readBuffer, new OnFileRead(this.socket));

      } catch (IOException error) {

        try {
          this.socket.close();
        } catch (Exception err) {}
      }
    }

    public void failed(Throwable error, ByteBuffer data) {

      try {
        this.socket.close();
      } catch (Exception err) {}
    }
  }



  public static class OnSocketConnect implements CompletionHandler<AsynchronousSocketChannel, Void> {

    protected AsynchronousServerSocketChannel server;

    OnSocketConnect(AsynchronousServerSocketChannel server) {
      this.server = server;
    }

    public void completed(AsynchronousSocketChannel socket, Void ignore) {

      System.out.println("Socket connected.");
      ByteBuffer buffer = ByteBuffer.allocate(2);
      socket.read(buffer, buffer, new OnSocketRead(socket));
      server.accept(null, this);
    }

    public void failed(Throwable error, Void ignore) {
      System.err.println("Looks like we lost a socket ¯\\_(ツ)_/¯");
    }
  }



  public static void main(String[] args) throws IOException {
    InetSocketAddress address = new InetSocketAddress(9090);

    CountDownLatch done = new CountDownLatch(1);
    AsynchronousServerSocketChannel server = AsynchronousServerSocketChannel.open().bind(address);
    server.accept(null, new OnSocketConnect(server));

    try {
      done.await();
    } catch (InterruptedException error) {
      System.err.println("Server exited.");
    }
  }
}

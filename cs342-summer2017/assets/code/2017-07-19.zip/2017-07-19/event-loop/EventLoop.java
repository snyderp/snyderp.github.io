// Keep track of which completion handlers should fire for which kernel-level
// updates.
HashMap<Integer, CompletionHandler> events = new HashMap<>();

while (true) { 

    // Wait until the kernel tells us something happened with one of the
    // file descriptors we're watching.
    Integer fileDesc = select(events.keySet());

    CompletionHandler toCall = events.get(fileDesc);
    Object result = read(fileDesc);

    if (/* something went wrong */) {
      toCall.failed(result);
    } else {
      toCall.completed(result);
    }
}

import java.nio.channels.AsynchronousFileChannel;
import java.nio.channels.CompletionHandler;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.io.IOException;
import java.util.concurrent.CountDownLatch;


public class ReadAsync {

  static class OnReadComplete implements CompletionHandler<Integer, ByteBuffer> {

    public void completed(Integer result, ByteBuffer data) {
      data.rewind();
      String fileContents = StandardCharsets.UTF_8.decode(data).toString();
      System.out.println(fileContents);
    }

    public void failed(Throwable error, ByteBuffer data) {
      System.err.println("wasn't able to read the file.");
    }
  }


  public static void main(String[] args) throws IOException {

    CountDownLatch done = new CountDownLatch(1);

    Path fileToRead = Paths.get(args[0]);
    AsynchronousFileChannel fileChannel = AsynchronousFileChannel.open(fileToRead, StandardOpenOption.READ);
    ByteBuffer buffer = ByteBuffer.allocate(10_000_000);
    fileChannel.read(buffer, 0, buffer, new ReadAsync.OnReadComplete());

    System.out.println("Finished handling input");

    try {
      done.await();
    } catch (InterruptedException error) {}
  }
}

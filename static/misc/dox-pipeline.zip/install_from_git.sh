#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
WORKING_DIR=$DIR/envs;
CONFIGS_DIR=$DIR/configs;

if [[ ! -d $WORKING_DIR ]]; then
  mkdir -p $WORKING_DIR;
fi;

if [[ -z `which virtualenv` ]]; then
  echo "Error: Unable to find the python 'virtualenv' script in your path." 1>$2;
  exit;
fi;

IFS="\n" cat $DIR/projects.txt | while read LINE; do
  PROJECT_NAME=`echo $LINE | awk -F ' ' '{print $1}'`;
  PROJECT_REPO=`echo $LINE | awk -F ' ' '{print $2}'`;

  cd $WORKING_DIR;
  virtualenv $PROJECT_NAME;
  cd $PROJECT_NAME;
  git clone $PROJECT_REPO $PROJECT_NAME;
  source bin/activate;
  cd $PROJECT_NAME;
  pip install -r requirements.txt;
  deactivate;
  cd $DIR;

  if [ -f "$CONFIGS_DIR/$PROJECT_NAME.config.py" ]; then
    ln -s "$CONFIGS_DIR/$PROJECT_NAME.config.py" $WORKING_DIR/$PROJECT_NAME/$PROJECT_NAME/config.py;
  fi;
done;


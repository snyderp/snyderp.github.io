#!/usr/bin/env bash

USAGE="Usage: ./launch.sh [-p port] [-h host] [-b path to firefox] [-v]";
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
WORKING_DIR=$DIR/envs;
LOG_DIR=$DIR/logs;

if [[ ! -d $WORKING_DIR ]]; then
  echo "Error: Unable to find service environments.  Run 'install.sh' first?" 1>&2;
  exit;
fi;


HOST="0.0.0.0"
INIT_PORT=8080;
FF_BINARY=`which firefox`;
VERBOSE_FLAG="";
if test -f $DIR/http_proxies.txt; then
    PROXY_FLAGS=`cat $DIR/http_proxies.txt`;
else
    PROXY_FLAGS="";
fi;


while getopts h:p:b:v OPT; do

  case $OPT in
    x)
      PROXY_FLAGS="-x $PROXY_FLAGS";
      ;;
    h)
      HOST=$OPTARG;
      ;;

    p)
      INIT_PORT=$OPTARG;
      ;;

    b)
      FF_BINARY=$OPTARG;
      ;;

    v)
      VERBOSE_FLAG="-v";
      ;;
  esac;
done;


if [[ ! -f $FF_BINARY ]]; then
  echo "Error: Unable to find Firefox binary." 1>&2;
  echo $USAGE 1>&2;
  exit;
fi;

./services.sh -h $HOST -p $INIT_PORT -b $FF_BINARY $VERBOSE_FLAG &
SERVICES_PID=$!;
sleep 5;

MARSHALLER_PORT=$INIT_PORT;
DB_CONNECTOR_PORT=$(($INIT_PORT + 3));
SCRAPER_PORT=$(($INIT_PORT + 4));

./scrape.sh -h $HOST -p $MARSHALLER_PORT -d $DB_CONNECTOR_PORT -s $SCRAPER_PORT $VERBOSE_FLAG $PROXY_FLAGS &
SCRAPER_PID=$!;

shutdown_pipeline () {
  echo "SHUTTING DOWN PIPELINE";
  kill $SERVICES_PID;
  kill $SCRAPER_PID;
}

trap 'shutdown_pipeline' SIGTERM SIGINT;
wait $SERVICES_PID $SCRAPER_PID;


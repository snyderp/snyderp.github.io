#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
DEST_DIR=$DIR/envs;
SOURCE_DIR=$DIR/packages;
CONFIG_DIR=$DIR/configs;

if ! test -d $DEST_DIR; then
    mkdir $DEST_DIR;
fi;

ls $SOURCE_DIR | while read PACKAGE; do
    MODULE_NAME=`echo $PACKAGE | sed 's/\.tar//g'`;
    CONFIG_NAME="$MODULE_NAME.config.example.py";
    cd $DEST_DIR;
    virtualenv $MODULE_NAME;
    cd $MODULE_NAME;
    mkdir $MODULE_NAME;
    tar -xzvf ../../packages/$PACKAGE -C $MODULE_NAME;
    source bin/activate;
    cd $MODULE_NAME;
    pip2.7 install -r requirements.txt;
    if test -f $CONFIG_DIR/$CONFIG_NAME; then
        cp $CONFIG_DIR/$CONFIG_NAME ./$MODULE_NAME.config.py;
    fi;
    deactivate;
    cd ../..;
done;

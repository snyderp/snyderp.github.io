Dox Measurement Pipeline
===

Overview
---
This project contains tools for measuring doxing related activity on sites
that are frequently used for sharing doxing materials.  This code has the
following steps:

1.  Record text files shared on forums and text sharing sites
2.  Use a classifier to programatically distingush doxing files from other
    comments and text shared on these sites.
3.  Extract social networking accounts from the dox files (ex the
    target's Facebook, Instagram, etc. accounts).
4.  Selenium based scrapers to record the status of those extracted social
    networking accounts (i.e. whether the account is public, private or closed)
    and, optionally, the comments / posts left on the account.
5.  A scheduler to automatically re-scrape the found social networking
    accounts periodically after they're first observered.


Requirements
---
This code requires:
*   A even-semi-recent version of PostgreSQL
*   `python2.7`, `pip` and [virtualenv](https://virtualenv.pypa.io/en/stable/)
    in your PATH
*   A linux or similar environment


Installing
---
1.  Copy each of the `*.config.example.py` files in the `configs/` directory
    to the same file name, but without "config" (e.g.
    `dox-social-scrapers.config.example.py` -> `dox-social-scrapers.config.py`).
    Then, edit each of these files with your environment's parameters (e.g.
    the database parameters for connecting to your postgres example,
    Twitter and Instagram API keys, etc.)  In the `dox-social-scrapers.config.py`
    file, you should only edit the strings in angel brackets, and leave
    the rest of the file's format unchanged.
2.  Run the `install.sh` script, which will unarchive the submodules
    and create their virtual environments in the `envs/` directory.
3.  To avoid harming doxing victims further, we are not distrubting any dox
    files, meaning **you will need to gather your own labeled "these files
    are doxes, these are not" data set to train the classifier**.  Once
    you have this training set, place your *yes this is a dox* examples
    in `envs/dox-classifier/dox-classifier/data/doxes`, and your *no this
    is not a dox* examples in `envs/dox-classifier/dox-classifier/data/not_doxes`
4.  Import the schema provided in
    `envs/dox-db-connector/dox-db-connector/data/schema.sql` into your database.
5.  (Optionally) edit the `http_proxies.txt` to include any http proxies
    you'd like to use when scraping sites.  The URLs for these proxies
    should be comma seperated, in the form of `ip1:port1,ip2:port2,etc`.
6.  Run the `launch.sh` script to fire everything up and start scraping
    dox materials.


Arguments
---
The `launch.sh` command accepts the following, optional arguments:

*   `-h`: Set the host name the webservices will serve from.  By default
    uses `0.0.0.0`.
*   `-p`: The system launches 9 webservices.  By default, they listen on
    ports 8080-8088.  Use this argument to change the lowest port
    the services should listen on.  The services will always use 9 sequential
    ports.
*   `-b`: Path to the Firefox binary.  By default this is determined by
     running `which firefox`, but if your binary is somewhere else,
     you can point the system to it using this argument.
*   `-v`: If provided, sets the system to run in verbose mode.  Useful
     for debugging start up problems.
*   `-x`: Override the HTTP proxy settings.  By default, these are
    read out of the http_proxy.txt file in the root of the project, but you
    can use this argument to override those settings.


Structure
---
The pipeline contains 9 sub-projects, which together make up the full pipeline
functionality.  Each sub-project is designed as a web service, and all
communication between them is done over HTTP (which in retrospect might not
have been a great choice, but, welp, what can you do?).

Each of the below projects are maintained in their

The functionality of each of those sub-projects is described below:

*   `dox-account-recrawler`
    Code responsibile for revisiting social networking accounts that have been
    found in dox files.  This module does not do the recrawling itself (which
    is handled by the `dox-social-scrapers` module), but just the scheduling
    of when to revisit an account.
*   `dox-classifier`
    Web service that wraps a trained, sci-kit learn classifier to distinguish
    doxing material from other text that is posted to forums and text sharing
    sites.
*   `dox-comment-extractor`
    Periodically checks the database for social networking accounts data
    to extract comments from scraped postings, to look for abusive material.
*   `dox-db-connector`
    Web service that communicates with the postgres database.  This is the
    only module in the system that talks directly to the dabtabase; all
    other modules communicate with the database indirectly through
    this module. (With one example, the `dox-comment-extractor` also
    talks directly to the database, since it's functioanlity can run "offline"
    and doesnt need to be part of the measurement pipeline).
*   `dox-extractor`
    Extracts references to social networking accounts from the text of dox
    files.  For example, given an input text file, this module returns,
    if they exist, the Facebook, Instagram, Twitter, etc handles mentioned
    in the text.
*   `dox-marshaller`
    This module is the central point of the system.  It is responsible for
    calling the other modules, sending data to services, etc.  For example,
    this module will ask the scraping module to look for new doxes, and
    the scaping module will return the new text files to the marshaller.
    The marshaller will then pass the received text files to the classifier
    to determine which text files look like doxes.  The classifier will
    report back to the marshaller, etc.  The marshaller makes the relationship
    between the different nodes in the system "hub-and-spoke" instead of
    "spaghetti".
*   `dox-pastebin-views`
    Checks with pastebin to see how many times a given text file has been
    viewed.
*   `dox-scrapers`
    Module that fetches and preprocesses new text files from Pastebin, 4chan
    8ch and other places where text files might be shared.
*   `dox-social-scrapers`
    Selenium based scrapers for deteremining the status of social networking
    accounts (public, private, closed), along with the text of posts and
    comments left on those accounts.


Credits and Complaints
---
The work that generated this code was done by the below authors:
*   Peter Snyder <psnyde2@uic.edu>
*   Periwinkle Doerfler <pid207@nyu.edu>
*   Chris Kanich <ckanich@uic.edu>
*   Damon McCoy <mccoy@nyu.edu>

This system was written in carrying out the research that lead to:

Peter Snyder, Periwinkle Doerfler, Chris Kanich, Damon McCoy
"[Fifteen Minutes of Unwanted Fame: Detecting and Characterizing Doxing](https://www.cs.uic.edu/~psnyder/static/papers/fifteen-minutes.pdf)",
Proceedings of the 2017 Internet Measurement Conference, 2017

If you have issues, complaints or questions about the code, please contact
Pete Snyder, at the above email, and he'll do his darndest to help.

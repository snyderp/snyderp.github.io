In order to have configuration files that persist across deployments of the
pipeline, create files in this directory named <PROJECT NAME>.config.py.  
When install.sh is run, it'll look for matching config files here and link them
into the projects.

Ie a file in `configs/dox-db-connector.config.py` would be symlinked to
`work/dox-db-connector/dox-db-connector/config.py` whenever install.sh was
run.

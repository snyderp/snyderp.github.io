"""
Configuration parameters for scraping OSN accounts, such as API credentials.
"""
import collections

TwitterAuthParams = collections.namedtuple(
    "TwitterAuthParams",
    "access_token access_secret consumer_key consumer_secret"
)

twitter_auth_params = TwitterAuthParams(
    "<access token>",
    "<access secret>",
    "<consumer key>",
    "<consumer secret>"
)

InstagramParams = collections.namedtuple(
    "InstagramParams",
    "access_token"
)

instagram_auth_params = InstagramParams(
    "<access_token>"
)

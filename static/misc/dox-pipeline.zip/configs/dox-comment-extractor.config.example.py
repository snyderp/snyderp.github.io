"""
Example configuration file for running the webservice middle layer between
the postgres database and the other elements in the system.

Copy and edit this file to `config.py`
"""

postgres = "dbname={} user={} password={} host={} port={}".format(
    None, None, None, None, None
)

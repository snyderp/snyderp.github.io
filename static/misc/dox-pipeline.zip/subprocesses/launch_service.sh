#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
WORKING_DIR=$DIR/../envs;

PROJECT_NAME=$1;
HOST=$2;
PORT=$3;
LOG_DIR=$4;
ADDITIONAL_ARGS=$5;

cd $WORKING_DIR/$PROJECT_NAME;
source bin/activate;
cd $PROJECT_NAME;
./server.py -p $PORT --ip $HOST -l $LOG_DIR $ADDITIONAL_ARGS;


#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
WORKING_DIR=$DIR/../envs;
PROJECT="dox-pastebin-views";

DB_PORT=$1;
DB_HOST=$2;
LOG_DIR=$3;
ADDITIONAL_ARGS=$4;

cd $WORKING_DIR/$PROJECT;
source bin/activate;
cd $PROJECT
./record.py -i $DB_HOST -p $DB_PORT -l $LOG_DIR $ADDITIONAL_ARGS;

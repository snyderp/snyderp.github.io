#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
WORKING_DIR=$DIR/../envs;
PROJECT="dox-comment-extractor";

LOG_DIR=$1;
ADDITIONAL_ARGS=$2;

cd $WORKING_DIR/$PROJECT;
source bin/activate;
cd $PROJECT
./extract.py -l $LOG_DIR $ADDITIONAL_ARGS;

#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
WORKING_DIR=$DIR/../envs;

SCRAPER=$1;
HOST=$2;
PORT=$3;
LOG_DIR=$4;
ADDITIONAL_ARGS=$5;

cd $WORKING_DIR/dox-scrapers;
source bin/activate;
cd dox-scrapers;
./scrape.py -m $HOST:$PORT -s $SCRAPER -l $LOG_DIR $ADDITIONAL_ARGS;


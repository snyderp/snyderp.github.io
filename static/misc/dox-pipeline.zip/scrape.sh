#!/usr/bin/env bash

USAGE="Usage: ./scrape.sh [-p port] [-h host] [-v]";
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
WORKING_DIR=$DIR/envs;
LOG_DIR=$DIR/logs;

if [[ ! -d $WORKING_DIR ]]; then
  echo "Error: Unable to find service environments.  Run 'install.sh' first?" 1>&2;
  exit;
fi;


HOST="127.0.0.1"
MARSHALLER_PORT=8080;
VERBOSE_FLAG="";
PROXY_FLAGS="";

while getopts h:p:d:s:v OPT; do

  case $OPT in
    x)
      for PROXY in `echo $OPTARG | sed 's/,/ /g'`; do
        PROXY_FLAGS="$PROXY_FLAGS -x $PROXY";
      done;
      ;;

    h)
      HOST=$OPTARG;
      ;;

    p)
      MARSHALLER_PORT=$OPTARG;
      ;;

    d)
      DB_PORT=$OPTARG;
      ;;

    s)
      SCRAPER_PORT=$OPTARG;
      ;;

    v)
      VERBOSE_FLAG="-v";
      ;;
  esac;
done;


if [[ -z $DB_PORT ]]; then
  echo "Error: Missing port for DB connector service." 1>&2;
  echo $USAGE 1>&2;
  exit 1;
fi;

if [[ -z $SCRAPER_PORT ]]; then
  echo "Error: Missing port for social network scraper service." 1>&2;
  echo $USAGE 1>&2;
  exit 1;
fi;

./subprocesses/launch_scraper.sh pastebin $HOST $MARSHALLER_PORT $LOG_DIR "$VERBOSE_FLAG $PROXY_FLAGS" &
PASTEBIN_PID=$!;

./subprocesses/launch_scraper.sh fourchan-pol $HOST $MARSHALLER_PORT $LOG_DIR "$VERBOSE_FLAG $PROXY_FLAGS" &
FOURCHAN_POL_PID=$!;

./subprocesses/launch_scraper.sh fourchan-b $HOST $MARSHALLER_PORT $LOG_DIR "$VERBOSE_FLAG $PROXY_FLAGS" &
FOURCHAN_B_PID=$!;

./subprocesses/launch_scraper.sh eightchan-pol $HOST $MARSHALLER_PORT $LOG_DIR "$VERBOSE_FLAG $PROXY_FLAGS" &
EIGHTCHAN_POL_PID=$!;

./subprocesses/launch_scraper.sh eightchan-baphomet $HOST $MARSHALLER_PORT $LOG_DIR "$VERBOSE_FLAG $PROXY_FLAGS" &
EIGHTCHAN_BAPHOMET_PID=$!;

./subprocesses/launch_rescraper.sh $DB_PORT $SCRAPER_PORT $LOG_DIR "$VERBOSE_FLAG" &
RESCRAPER_PID=$!;

./subprocesses/launch_view_counter.sh $DB_PORT $HOST $LOG_DIR "$VERBOSE_FLAG" &
VIEW_COUNTER_PID=$!;

./subprocesses/launch_comment_extractor.sh $LOG_DIR "$VERBOSE_FLAG $PROXY_FLAGS" &
COMMENT_EXTRACTOR_PID=$!;

shutdown_scrapers () {
  echo " ! Shutting down scrapers";
  pkill -TERM -P $PASTEBIN_PID;
  pkill -TERM -P $FOURCHAN_POL_PID;
  pkill -TERM -P $FOURCHAN_B_PID;
  pkill -TERM -P $EIGHTCHAN_POL_PID;
  pkill -TERM -P $EIGHTCHAN_BAPHOMET_PID;
  pkill -TERM -P $RESCRAPER_PID;
  pkill -TERM -P $VIEW_COUNTER_PID;
  pkill -TERM -P $COMMENT_EXTRACTOR_PID;
}

trap 'shutdown_scrapers' SIGTERM SIGINT;
echo "Stared Scrapers";
echo "---";
echo " * PasteBin:          $PASTEBIN_PID";
echo " * 4chan-pol:         $FOURCHAN_POL_PID";
echo " * 4chan-b:           $FOURCHAN_B_PID";
echo " * 8ch-pol:           $EIGHTCHAN_POL_PID";
echo " * 8ch-baphomet:      $EIGHTCHAN_BAPHOMET_PID";
echo " * Rescraper:         $RESCRAPER_PID";
echo " * View Counter:      $VIEW_COUNTER_PID";
echo " * Comment Extractor: $COMMENT_EXTRACTOR_PID";
wait $PASTEBIN_PID $FOURCHAN_POL_PID $FOURCHAN_B_PID $EIGHTCHAN_POL_PID $EIGHTCHAN_BAPHOMET_PID $RESCRAPER_PID $VIEW_COUNTER_PID $COMMENT_EXTRACTOR_PID;

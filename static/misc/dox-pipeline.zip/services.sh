#!/usr/bin/env bash

USAGE="Usage: ./services.sh [-p port] [-h host] [-b path to firefox] [-v]";
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
WORKING_DIR=$DIR/envs;
LOG_DIR=$DIR/logs;

if [[ ! -d $WORKING_DIR ]]; then
  echo "Error: Unable to find service environments.  Run 'install.sh' first?" 1>&2;
  exit;
fi;


HOST="0.0.0.0"
INIT_PORT=8080;
FF_BINARY=`which firefox`;
VERBOSE_FLAG="";


while getopts h:p:b:v OPT; do

  case $OPT in
    h)
      HOST=$OPTARG;
      ;;

    p)
      INIT_PORT=$OPTARG;
      ;;

    b)
      FF_BINARY=$OPTARG;
      ;;

    v)
      VERBOSE_FLAG="-v";
      ;;
  esac;
done;


if [[ ! -f $FF_BINARY ]]; then
  echo "Error: Unable to find Firefox binary." 1>&2;
  echo $USAGE 1>&2;
  exit;
fi;

CLASSIFIER_PORT="$(($INIT_PORT + 1))";
./subprocesses/launch_service.sh dox-classifier $HOST $CLASSIFIER_PORT $LOG_DIR "$VERBOSE_FLAG" &
CLASSIFIER_PID=$!;

EXTRACTOR_PORT="$(($INIT_PORT + 2))";
./subprocesses/launch_service.sh dox-extractor $HOST $EXTRACTOR_PORT $LOG_DIR "$VERBOSE_FLAG" &
EXTRACTOR_PID=$!;

DB_CONNECTOR_PORT=$(($INIT_PORT + 3));
./subprocesses/launch_service.sh dox-db-connector $HOST $DB_CONNECTOR_PORT $LOG_DIR "$VERBOSE_FLAG" &
DB_CONNECTOR_PID=$!;

SCRAPER_PORT="$(($INIT_PORT + 4))";
./subprocesses/launch_service.sh dox-social-scrapers $HOST $SCRAPER_PORT $LOG_DIR "-b $FF_BINARY $VERBOSE_FLAG" &
SCRAPER_PID=$!;

MARSHALLER_PORT="$(($INIT_PORT))";
./subprocesses/launch_service.sh dox-marshaller $HOST $MARSHALLER_PORT $LOG_DIR "-c $HOST:$CLASSIFIER_PORT -d $HOST:$DB_CONNECTOR_PORT -e $HOST:$EXTRACTOR_PORT -s $HOST:$SCRAPER_PORT $VERBOSE_FLAG" &
MARSHALLER_PID=$!;

shutdown_services () {
  echo " ! Shutting down services";
  pkill -TERM -P $CLASSIFIER_PID;
  pkill -TERM -P $EXTRACTOR_PID;
  pkill -TERM -P $DB_CONNECTOR_PID;
  pkill -TERM -P $SCRAPER_PID;
  pkill -TERM -P $MARSHALLER_PID;
}

trap 'shutdown_services' SIGTERM SIGINT;
echo "Started services";
echo "---";
echo " * Classifier service: $HOST:$CLASSIFIER_PORT ($CLASSIFIER_PID)";
echo " * Extractor service:  $HOST:$EXTRACTOR_PORT ($EXTRACTOR_PID)";
echo " * DB service:         $HOST:$DB_CONNECTOR_PORT ($DB_CONNECTOR_PID)";
echo " * Scraper service:    $HOST:$SCRAPER_PORT ($SCRAPER_PID)";
echo " * Marshaller service: $HOST:$MARSHALLER_PORT ($MARSHALLER_PID)";
wait $CLASSIFIER_PID $EXTRACTOR_PID $DB_CONNECTOR_PID $SCRAPER_PID $MARSHALLER_PID;


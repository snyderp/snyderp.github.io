from tornadio2 import proto
from datetime import datetime


class WorkRequest(object):

    """A class to wrap a user request as it travels through a series of
    Socket.IO requests.

    Args:
        user       -- the drano.User instance representing the user for whom
                      this work is being performed
        request_id -- a user / client generated unique identifier for this
                      work request, which they can use if the need to
                      re-connect to this work request
        work_desc  -- the description of the work being performed, mostly
                      used for logging purposes
        socket     -- a tornadio2.SocketConnection instance that was used to
                      generate this work request

    """
    def __init__(self, user, request_id, work_desc, socket):
        self.user = user
        self.request_id = request_id
        self.work_desc = work_desc
        self.start_time = datetime.now()

        # This is the socket that we should write messages over.  It should
        # always be the most recent socket related to this work request
        self.writing_socket = socket

        # This is the first socket connection / request that started this work
        # request.  This is held onto so that we can be sure that the
        # underlying SocketConnection object isn't garbage collected
        # out from under us while we're doing work.  This means that a single
        # user can hold onto to SocketConnections at the same time
        self.initial_socket = socket

    def emit(self, name, *args, **kwargs):
        """Writes a Socket.IO message out over the Socket.IO instance
        responsible for listening to this request.  This will be the
        SocketConnection instance that started this connection"""
        msg = proto.event(None, name, None, *args, **kwargs)
        self.writing_socket.session.send_message(msg)

    def set_writing_socket(self, new_socket):
        """Set what the current socket is for this request.  This is the most
        recent Socket.IO request related to this work.

        If the current socket isn't equal to the writing socket (ie we've
        already replaced this once), close the intermediate "current socket"

        Args:
            new_socket -- The most recent tornadio2.SocketConnection instance
                          related to this work request
        """
        if new_socket != self.writing_socket:
            self.emit("registered-work-changed")
            self.writing_socket.session.close()
        self.writing_socket = new_socket

    def close(self):
        self.writing_socket.close()
        self.initial_socket.close()

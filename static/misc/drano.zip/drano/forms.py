import pybootstrap_forms.form as bootstrap_forms
from pybootstrap_forms.inputs import Field, Checkbox, Radios, Dropdown, TextArea, Markup
from pybootstrap_forms.collections import RaitingsGrid
import config


def survey_form(version=2):

    def _pairs(*items):
        return tuple(((v, v) for v in items))

    fields = []

    if version == 2:

        gender_options = _pairs("Male", "Female", "Other")
        age_ranges = _pairs('18-21', '22-25', '26-30', '31-40', '41-50', '51-60',
                            '61 and over')
        income_options = _pairs("Less than $10,000", "$10,000 to less than $20,000",
                                "$20,000 to less than $30,000",
                                "$30,000 to less than $50,000",
                                "$50,000 to less than $75,000",
                                "$75,000 to less than $100,000",
                                "$100,000 or more",
                                "Don't know")
        edu_options = _pairs("Less than high school", "High School", "Some College",
                             "College graduate (B.S., B.A., or other 4 year-degree)",
                             "Post-graduate training or professional schooling after college (e.g. toward a master's degree or Ph.D.; law or medical school)")

        privacy_questions = (
            "All things considered, the Internet poses serious privacy problems.",
            "Compared to others, I am more sensitive about the way online companies handle my personal information.",
            "To me, it is the most important thing to keep my privacy intact from online companies.",
            "I believe other people are too concerned with online privacy issues.",
            "Compared with other concerns I have, personal privacy is very important.",
            "I am concerned about threats to my personal privacy today.",
        )

        useability_questions = (
            "I would like to use the Cloudsweeper tool frequently.",
            "I found Cloudsweeper to be unnecessarily complex.",
            "I thought Cloudsweeper was easy to use.",
            "I think that I would need the support of a technical person to be able to use Cloudsweeper.",
            "I found that the functions in Cloudsweeper were well integrated.",
            "I thought there was too much inconsistency in the Cloudsweeper tool.",
            "I would imagine that most people would learn to use Cloudsweeper very quickly.",
            "I found that Cloudsweeper was very cumbersome to use.",
            "I felt very confident using the Cloudsweeper tool.",
            "I needed to learn a lot of things before I could get going with Cloudsweeper.",
        )

        fields = (
            Radios('gender', gender_options, label="What is your gender?"),
            Radios('age', age_ranges, label='What is your age?'),
            Radios('income', income_options, label="What was your total household income from all sources before taxes last year?"),
            Radios('education', edu_options, label="What is the last grade or class that you completed in school?"),
            RaitingsGrid('privacy_concerns', privacy_questions, label="For the following statements, express your agreement or disagreement with the statement (1=Strongly disagree, 7=Strongly Agree):"),
            RaitingsGrid('usability', useability_questions, label="For the following statements, express your agreement or disagreement with the statement (1=Strongly disagree, 7=Strongly Agree)"),
            Field('own_identify_theft', label="In the past five years how often have you personally been a victim of identity theft?"),
            Field('other_identity_theft', label=" In the past five years how often has someone you know has been a victim of identity theft?"),
            Field('business_idenitity_theft', label="In the past five years how often have you personally experienced a successful or unsuccessful privacy breach? For example, if someone tried to hack into your email, or if a service provider you know was hacked (e.g. Sony))"),
            Field('privacy_breach', label="In the past five years how often has someone you know experienced a successful or attempted privacy breach?"),
            Checkbox('future_surveys', '1', label="I would be willing to participate in future surveys to help improve {site}.".format(site=config.site_name)),
            Checkbox('receive_updates', "1",
                     label="Would you like to receive email updates about {site}?".format(site=config.site_name)),
            Field('receive_email', label="Email address to notify of updates",
                  help="Feel free to sign up with a different email address.",
                  attrs={
                      "data-visible-when": "receive_updates",
                  })
        )
    elif version == 1:

        gender_options = _pairs("Male", "Female")
        age_ranges = _pairs('18-21', '22-25', '26-30', '31-40', '41-50', '51-60',
                            '61 and over')
        income_options = _pairs('Prefer not to say', '$0 - $25,000',
                                '$25,000 - $50,000', '$50,000 - $75,000',
                                '$75,000 - $100,000', '$100,000 or more')
        marital_status_options = _pairs('Single, Never Married', 'Married',
                                        'Separated', 'Divorced', 'Widowed')
        education_options = _pairs('Less than High School', 'High School/GED',
                                   'Some College',
                                   '2-Year College Degree(Associates)',
                                   '4-Year College Degree(BA,BS)',
                                   "Master's Degree",
                                   'Doctoral Degree',
                                   'Professional Degree(MD,JD)')
        yes_no_options = _pairs('Yes', 'No')
        automated_options = _pairs('Humans', 'Automated')
        interest_options = _pairs("Not interested", "Slightly interested",
                                  "Interested", "Very Interested")

        fields = (
            Radios('gender', gender_options, label="Are you Male or Female?"),
            Dropdown('age', age_ranges, label='What is your age?'),
            Dropdown('household_income', income_options,
                     label="What is your household income?"),
            Radios('marital_status', marital_status_options,
                   label="What is your current marital status?"),
            Dropdown('education_mother', education_options,
                     label="What is the highest level of education your mother completed?"),
            Dropdown('education_father', education_options,
                     label='What is the highest level of education your father completed?'),
            Radios('had_unknown_passwords', yes_no_options,
                   label="Did you find passwords in your mailbox that you didn't realize were stored there?"),
            Radios('found_sensitive_info', yes_no_options,
                   label="Did you find passwords in your mailbox that you use for important accounts, like your primary email, bank, or online shopping sites that store your billing information?"),
            Radios('redacted_info_from_humans', automated_options,
                   label="Did you find emails mostly from other humans, or automated programs?"),
            TextArea('emailing_services', rows=5, classes=["input-block-level"],
                     label="What services were emailing you back your password? Feel free to be specific or general, and list as many or as few as you wish."),
            TextArea('other_info_to_redact', rows=5, classes=["input-block-level"],
                     label="If you had the ability to redact or encrypt other types of information in your email account, what would you want to be able to change?"),
            Markup("<h3>Which features would you be most interested in using if they were available?</h3>"),
            Dropdown('interest_other_services', interest_options,
                     label="Other services (Yahoo, Outlook, etc.)"),
            Dropdown('interest_cloud_storage', interest_options,
                     label="Redact in cloud storage (dropbox, box.net)"),
            Dropdown('interest_find_replace', interest_options,
                     label="Arbitrary text find and redact"),
            Dropdown('interest_encrypt_old', interest_options,
                     label='Encrypt all messages over X months/years old'),
            Dropdown('interest_personal_info', interest_options,
                     label="Redact personal information (birthdate, SSN, Home address)"),
            Dropdown('interest_attachments', interest_options,
                     label="Search in attachments (.doc, .pdf)"),
            Dropdown('interest_recurring_search', interest_options,
                     label="Automatically enrypt/redact new email as it arrives"),
            Dropdown('interest_privacy_alerts', interest_options,
                     label="Privacy alerts (for instance if an email includes a password)"),
            Dropdown('interest_speedup', interest_options,
                     label='Speed improvements for Cloudsweeper'),
            Checkbox('receive_updates', "1",
                     label="Would you like to receive email updates about " + config.site_name),
            Field('receive_email', label="Email address to notify of updates",
                  help="Feel free to sign up with a different email address.",
                  attrs={
                      "data-visible-when": "receive_updates",
                  })
        )

    return bootstrap_forms.Form("Survey", *fields)

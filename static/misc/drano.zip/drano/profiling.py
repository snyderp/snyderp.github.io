"""Code related to profiling, seeing what Torando / Drano is doing with
all our memory, cpu time, and sanity"""

import os
import sys
import time
import config
from imaplib2 import IMAP4_SSL
from tornado.simple_httpclient import SimpleAsyncHTTPClient, _HTTPConnection
from tornado.iostream import SSLIOStream
from tornado import stack_context
import functools
import datetime


class Stats:

    def __init__(self, sequence, title):
        # sequence of numbers we will process
        # convert all items to floats for numerical processing
        self.sequence = [float(item) for item in sequence]
        self.title = title

    def __str__(self):
        return "\n".join([self.title, "==============",
                          "Data Points: %d" % self.count(),
                          "Min: %f" % self.min(), "Max: %f" % self.max(),
                          "Avg: %f" % self.avg(), "Median: %f" % self.median(),
                          "Total: %d" % self.sum(),
                          "Std Dev: %f" % self.stdev(), ""])

    def sum(self):
        if len(self.sequence) < 1:
            return None
        else:
            return sum(self.sequence)

    def count(self):
        return len(self.sequence)

    def min(self):
        if len(self.sequence) < 1:
            return None
        else:
            return min(self.sequence)

    def max(self):
        if len(self.sequence) < 1:
            return None
        else:
            return max(self.sequence)

    def sum(self):
        if len(self.sequence) < 1:
            return None
        else:
            return sum(self.sequence)

    def avg(self):
        if len(self.sequence) < 1:
            return None
        else:
            return sum(self.sequence) / len(self.sequence)

    def median(self):
        if len(self.sequence) < 1:
            return None
        else:
            self.sequence.sort()
            return self.sequence[len(self.sequence) // 2]

    def stdev(self):
        if len(self.sequence) < 1:
            return None
        else:
            avg = self.avg()
            sdsq = sum([(i - avg) ** 2 for i in self.sequence])
            stdev = (sdsq / (len(self.sequence) - 1)) ** .5
            return stdev

    def percentile(self, percentile):
        if len(self.sequence) < 1:
            value = None
        elif (percentile >= 100):
            sys.stderr.write('ERROR: percentile must be < 100.  you supplied: %s\n' % percentile)
            value = None
        else:
            element_idx = int(len(self.sequence) * (percentile / 100.0))
            self.sequence.sort()
            value = self.sequence[element_idx]
        return value


def plop_profiling(ioloop, secs=60):
    """Adding plop profiling to the tornado instance, so that we grab plop
    profiles at a given interval

    Args:
        ioloop -- reference to the tornado IOLoop to be profiled

    Keyword Args:
        secs -- time between profile snapshots
    """
    from plop.collector import Collector

    # If we're going to profile the app, we do it a dumb simple way, of grabbing
    # profile information for 5 minutes, and then we force tornado to shutdown
    # and write its profiling data out to disk
    profiler = Collector()
    profiler.start()

    if not os.path.isdir(config.plop_path):
        os.makedirs(config.plop_path)

    def plop_snapshot():
        log_path = os.path.join(config.plop_path, str(time.time()) + "-profile.log")
        log_dest_handle = open(log_path, 'w')
        log_dest_handle.write(repr(dict(profiler.stack_counts)))
        log_dest_handle.close()

    ioloop.instance().add_timeout(
        datetime.timedelta(seconds=secs),
        plop_snapshot)


def heapy_profiling(ioloop, secs=60):
    """Adding Heapy profiling to the tornado instance, so that we grab heapy_profiling
    information from the application at a given interval

    Args:
        ioloop -- reference to the tornado IOLoop to be profiled

    Keyword Args:
        secs -- time between profile snapshots
    """
    from guppy import hpy
    hp = hpy()
    hp.setrelheap()

    if not os.path.isdir(config.heapy_path):
        os.makedirs(config.heapy_path)

    def heap_snapshot():
        log_path = os.path.join(config.heapy_path, str(time.time()) + ".log")
        log_dest_handle = open(log_path, 'w')
        log_dest_handle.write(hp.heap())
        log_dest_handle.close()

    ioloop.instance().add_timeout(
        datetime.timedelta(seconds=config.heapy_time),
        heap_snapshot)


# The below functions and code all relate to stress testing and profiling
# by dumping out application level network traffic to disk, and then
# replicating in a pexpect style situation


def write(data, desc, incoming=False, duration=None):
    """Writes a log of network data to the configured netdumps directory.
    Files are written in the following format:
        <unix timestamp>-<incoming / outgoing>-<port>-<source>

    Args:
        data -- a bytestring to be written to the disk, should probably be some
                kind of network traffic
        desc -- a very short user readable desciption of the network traffic
                (like IMAP4 or HTTP)

    Keyword Args:
        incoming -- Whether the provided data is incoming or outgoing, only used
                    in naming the log files
        duration -- the amount of time, in seconds, that it took this operation
                    to execute

    Returns:
        The given bytestring, unchanged
    """
    direction = "response" if incoming else "request"
    file_name = "-".join(['%.10f' % time.time(), direction, desc])
    fh = open(os.path.join(config.netdump_path, file_name), 'w')
    fh.write(data)
    fh.close()

    if config.netdump_time_path and duration:
        dh = open(os.path.join(config.netdump_time_path, file_name), 'w')
        dh.write(str(duration))
        dh.close()

    return data


class IMAP4_SSL_Netdump(IMAP4_SSL):
    """A subclass of the standard imaplib2 library that dumps all incoming and
    outgoing network traffic.  All this logging is done in a blocking manner,
    so it'll be much slower (duh)."""

    def __getattr__(self, name, value):
        """In order to get consistant, hashable responses to and from the
        server, we need to override the IMAP library's random method of
        generating IMAP message tags.  We do that by hardcoding the tag value,
        and then not letting anyone else touch it / set it.
        """
        if name == "tagpre":
            return config.imap_message_tag
        else:
            super(IMAP4_SSL_Netdump, self).__setattr__(name, value)

    def read(self, size):
        duration = None
        if hasattr(self, 'start') and self.start:
            duration = time.time() - self.start
            self.start = None
        return write(super(IMAP4_SSL_Netdump, self).read(size), 'imap', True, duration)

    def send(self, data):
        self.start = time.time()
        super(IMAP4_SSL_Netdump, self).send(data)
        write(data, 'imap', False)


class SSLIOStream_Netdump(SSLIOStream):
    """Subclass of Tornado's iostream library so that we can dump anything
    sent or received over the Async HTTPS client"""

    def write(self, data, callback=None):
        write(data, 'https', False)
        super(SSLIOStream_Netdump, self).write(data, callback=callback)

    def _consume(self, loc):
        data = super(SSLIOStream_Netdump, self)._consume(loc)
        write(data, 'https', True)
        return data


class _HTTPConnection_Netdump(_HTTPConnection):
    """Sublcass the workhorse HTTP connection class used in tornado so that
    we can force it (as lightly and respectfully as possible) to use
    our streaming classes, instead of the default Tornado ones"""

    def __setattr__(self, name, value):
        if name == "stream":
            self.__dict__[name] = SSLIOStream_Netdump(
                value.socket,
                io_loop=self.io_loop,
                ssl_options=value._ssl_options,
                max_buffer_size=value.max_buffer_size
            )
        else:
            super(_HTTPConnection_Netdump, self).__setattr__(name, value)


class SimpleAsyncHTTPClient_Netdump(SimpleAsyncHTTPClient):
    """Subclass the tornado provide HTTP client class (the class that actually
    does the call / response, instead of the singleton constructor class below)
    to add logging for all sends and responses"""

    def _process_queue(self):
        with stack_context.NullContext():
            while self.queue and len(self.active) < self.max_clients:
                request, callback = self.queue.popleft()
                key = object()
                self.active[key] = (request, callback)
                _HTTPConnection_Netdump(
                    self.io_loop, self, request,
                    functools.partial(self._release_fetch, key),
                    callback,
                    self.max_buffer_size,
                    self.resolver)

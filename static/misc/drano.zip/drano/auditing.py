"""Rules for attempting to determine the price for an account, and for assessing
what kinds of sensitive information are in the account."""


import re
from drano.database import connection


def audit_rules(callback):
    """Returns a list of zero or more pricing rules that should be searched
    for in a gmail account

    Returns:
        A list of zero or more AuditRule objects
    """
    def _on_fetch(response, error):
        rules = []
        for rule in response:
            new_rule = AuditRule(str(rule['_id']))
            new_rule.name = rule['name']
            new_rule.add_broad_rules(rule['broad_rules'])
            new_rule.severity = rule['severity']
            new_rule.domain = rule['domain']

            try:
                new_rule.extra_factor = rule['extra_factor']
            except KeyError:
                new_rule.extra_factor = None

            if 'narrow_rule' in rule and rule['narrow_rule']:
                new_rule.set_narrow_rule(rule['narrow_rule'], rule['narrow_rule_is_regex'])

            if 'broad_rules_negation' in rule:
                new_rule.broad_rules_negation = rule['broad_rules_negation']

            try:
                new_rule.price = rule['prices'][-1]['price']
            except KeyError:
                new_rule.price = None

            rules.append(new_rule)
        callback(rules)

    mongo = connection()
    mongo.pricing_rules.find(callback=_on_fetch)


class AuditRule(object):

    def __init__(self, identifier):
        # An identifier for this rule. It should be unique among all rules
        # searched for at a time
        self.name = ""

        # A Unique ID for this particular pricing rule
        self.id = identifier
        self._broad_rules = []
        self.broad_rules_negation = []
        self.narrow_rule = None
        self.narrow_rule_is_regex = False
        self.price = False
        self.severity = None
        self.extra_factor = None

    def set_narrow_rule(self, narrow_rule, regex=False):
        """Sets the narrow rule that should be matched against email messages
        after they've already been pulled down from the server. The given rule
        should be a string that'll compile into a regular expression, which will
        then be matched against the email messages.

        Args:
            narrow_rule -- A string that forms a valid regular expression,
                           used to narrow down a larger pool of email messages
                           into those that correctly match a more general,
                           Gmail searchable criteria

        Keyword Args:
            regex -- Whether the given narrow rule should be treated as a
                     regular expression

        Returns:
            Reference to the current PricingRule object.
        """
        if regex:
            self.narrow_rule_is_regex = True
            self.narrow_rule = re.compile(narrow_rule, flags=re.I | re.M | re.U)
        else:
            self.narrow_rule = narrow_rule
        return self

    def add_broad_rule(self, broad_rule):
        """Adds a broad rule to the set of searches that should be sent to
        Gmail to gather UIDs for this particular rule

        See:
            https://developers.google.com/google-apps/gmail/imap_extensions#extension_of_the_search_command_x-gm-raw

        Args:
            broad_rule -- A string that is a valid search for a raw search
                          against gmail

        Returns:
            A reference to the current PricingRule object
        """
        self._broad_rules.append(broad_rule)
        return self

    def add_broad_rules(self, broad_rules):
        """Adds a list of rules to the set of searches that should be sent to
        Gmail to gather UIDs for this particular rule

        See:
            https://developers.google.com/google-apps/gmail/imap_extensions#extension_of_the_search_command_x-gm-raw

        Args:
            broad_rules -- A list of one or more strings that are valid queries
                           for a raw search against gmail

        Returns:
            A reference to the current PricingRule object
        """
        self._broad_rules = list(set(self._broad_rules + broad_rules))
        return self

    def broad_rules(self):
        """Returns a list of one or more strings that should be used for a raw
        search against Gmail to get matching messages / uids.  The matching
        set of email messages should, together, form some meaningful set (ex
        confirmation messages from Amazon)

        See:
            https://developers.google.com/google-apps/gmail/imap_extensions#extension_of_the_search_command_x-gm-raw

        Returns:
            A list of zero or more strings that match the restrictions / format
            of the gmail raw search interface
        """
        return self._broad_rules

    def matches_narrow_rule(self, text):
        """Returns a boolean description of whether the given text matches the
        finer grained set of rules for this larger pricing rule.

        If a narrow rule hasn't been specified for this rule, the result of this
        method will always be True

        Args:
            text -- a string, probably the raw, complete text of an email
                    message

        Returns:
            True if there is a match, and False in all other situations
        """
        if not self.narrow_rule:
            return True
        elif text is None:
            return False
        elif self.narrow_rule_is_regex:
            return self.narrow_rule.match(text) is not None
        else:
            return text.find(self.narrow_rule) > -1

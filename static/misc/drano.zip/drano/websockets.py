from tornadio2 import SocketConnection
from tornado.log import gen_log

import drano.events.password_search
import drano.events.password_decrypt
import drano.events.password_encrypt
import drano.events.touch
import drano.events.fill
import drano.events.audit
import config
import datetime


class SocketIOServer(SocketConnection,
                     drano.events.password_search.PasswordSearchEvent,
                     drano.events.password_decrypt.PasswordDecryptEvent,
                     drano.events.password_encrypt.PasswordEncryptEvent,
                     drano.events.touch.TouchEvent,
                     drano.events.fill.FillEvent,
                     drano.events.audit.AuditEvent):

    def on_open(self, request):
        """Whenever the user opens up a Socket.IO connection, we register the
        new connection / session as the user's new connection, and direct
        all messages from any previously queued work to them. This allows
        us to keep up with users between redirects, socket closures, etc.

        In order to deal with problems of session reconnection and limiting the
        user to a single gmail connection at a time, we take the following
        steps:

            - On Socket.IO connection, check to make sure we have the following
              three parameters.  Without all three of these parameters,
              the user isn't allowed to create a Socket.IO connection:
                token         -- A unique token, used to represent a single user
                                 throughout their interaction with drano
                request_token -- A client / browser generated token, used to
                                 keep track of this work request through out
                                 the lifetime of this work request.  Used for
                                 reconnecting with a previous work request
                                 between Socket.IO connections
                email         -- The email address used to connect with Gmail.
                                 Used to make sure that a user can't DOS us
                                 by connecting multiple times to Gmail with
                                 different sessions

            - If the above parameters represent a work request already underway,
              then we want to shim the current SocketConnection into the user's
              work request, but don't do any new work (ie connect the session
              and then stop processing)

            - If the above parameters don't represent a work request underway,
              create a new work request, possibly replacing a work request
              that already exists for the user.  This will cause any work
              currently being done for the user to stop before starting the
              new work.
        """
        gen_log.debug("Received request for {port}".format(port=config.port))
        user_token = request.get_argument('token')
        request_token = request.get_argument('request_token')
        email = request.get_argument('email')
        params = [user_token, request_token, email]

        # There is a disconnect here between the query parameters we receive
        # here (which could be a javascript oddness like "undefined") and
        # the session parameters sent over the Socket.IO request (which
        # will not include invalid js variables), so we just test and filter
        # out any missing params here
        params = [t for t in params if t and t != "undefined"]
        return len(params) == 3

    @drano.gen.prepare_socket_request('close-connection-client-initiated')
    def close_connection(self, user, account, req, *args, **kwargs):
        """When we get a message from the client that the current session should
        be closed, we first need to end the session, and only then remove the
        work 'mutex'.  Doing so in the oposite order will cause the current
        page to display an error immediatly before ending the Socket.IO session.
        """
        user.end_current_work()

    def debug(self, user, message, *args):
        message = message % args
        gen_log.debug("%s:%s: %s" % (user.current_work, user.email, message))

    # General Methods useful in multiple events

    def _sign_account_out(self, websocket_event, mongo_response=False, req=None):
        if config.stress_test_run:
            print (datetime.datetime.now() - self._timing).seconds
        req.emit(websocket_event)
        req.user.end_current_work()

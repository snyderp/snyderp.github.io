from collections import OrderedDict


class Collection(object):
    """Datastore for keeping track of what mailboxes the current user has
    in their gmail account

    Basically just a dict with a global count and some convenience getters.
    The value assigned to each mailbox name (the key) is the number of messages
    found in the mailbox (the value).

    This class is iterable.  Each iteration returns the name of a mailbox in
    the account, in alphabetical order.

    """
    def __init__(self):
        self.total = 0
        self.mailboxes = dict()

    def __iter__(self):
        """Iterate over the names of the mailboxes we've seen so far"""
        return iter(OrderedDict(sorted(self.mailboxes.items(), key=lambda t: t[0])))

    def __setitem__(self, key, value):
        self.mailboxes[key] = value

    def __getitem__(self, key):
        """Return the number of messages associated with the given mailbox"""
        return self.mailboxes[key]

    def __len__(self):
        return len(self.mailboxes)

    def __repr__(self):
        return "Mailbox Collection (%d mailboxes, %d messages)" % (
            len(self), sum([int(self.mailboxes[key]) for key in self.mailboxes]))

    def reset(self):
        self.mailboxes = {}

    def add_mailbox(self, mailbox_name, count):
        """Stores the name of mailbox in the current user's gmail account, along
        with the number of messages that were found in that mailbox

        Args:
            mailbox_name -- A string of the name / label of the mailbox
            count        -- The number of messages stored in this mailbox
        """
        self.mailboxes[mailbox_name] = count

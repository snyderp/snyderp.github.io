"""Simple functions used just for template markup convenience"""


def attr_escape(value):
    """Escapes a given string so that it is safe to insert into an HTML
    element attribute"""
    return value.replace('"', "'")


def password_obfuscate(password, char="*"):
    """Obfuscates a password by replacing something like "thisispassw0rd"
    with "t***********d

    Args:
        password -- a string version of a password

    Keyword Args:
        char -- the character to use to obfuscate the password

    Return:
        A string the the same lenght of the given password, but with all
        non-terminal characters as "*"
    """
    password_length = len(password)
    if password_length:
        return password[0] + (char * (password_length - 2)) + password[-1]
    else:
        return password_length * char

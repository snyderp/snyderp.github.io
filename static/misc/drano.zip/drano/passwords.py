import Crypto.Cipher
import Crypto.Random
import re
import config
from base64 import decodestring, encodestring


def drano_nonce_create():
    return Crypto.Random.get_random_bytes(16)


def drano_nonce_search_token(nonce):
    """Creates a tag that can be used to search for ciphertext tags in email

    Args:
        nonce -- A semi-uniquely idenfiying tag for identifiying the a set of
                 ciphertext blocks, as a bit string

    Returns:
        A string in the format of [<nonce_base64>
    """
    return "[" + encodestring(nonce).strip()


def drano_key_create():
    return Crypto.Random.get_random_bytes(32)


def decrypt_ciphertext_in_text(key, nonce, text):
    """Decrypts all matching ciphertext blocks, encoded under the given key

    Args:
        key   -- A bit string encoding of the key used to AES256 encode some
                 data.  This bit string should include the IV as the first
                 16 bits.
        nonce -- A semi-uniquely idenfiying tag for identifiying the a set of
                 ciphertext blocks
        text  -- A text string to search for ciphertext tags

    Returns:
        A list of zero or more tuples, each with the found drano cipher text tag
        in the first position, and the decrypted value in the second
    """
    matches = find_drano_ciphertext_tags(nonce, text)
    results = []
    if matches:
        for match in matches:
            rs = parse_drano_ciphertext_tag(match)
            if rs:
                found_nonce, found_bit_string = rs
                decrypted_value = decrypt_password(found_bit_string, key)
                results.append((match, decrypted_value.strip()))
    return results


def find_drano_ciphertext_tags(nonce, text):
    """Searches a block of text for matching drano ciphertext tags

    Args:
        nonce -- A semi-uniquely idenfiying tag for identifiying the a set of
                 ciphertext blocks, as bit string
        text  -- A text string to search for ciphertext tags

    Return:
        None if there are no ciphertext tags for the given nonce in the searched
        text.  Otherwise, a list of matching tags
    """
    pattern = r'\[(?:Cloudsweeper\.)?' + encodestring(nonce).strip().replace("+", "\+") + r'\s+[\w+/=\s]+]'
    return re.findall(pattern, text, flags=re.MULTILINE | re.IGNORECASE)


def parse_drano_key(drano_key):
    """Retreves the nonce and key from a drano key

    When a user encrypts some text, they are given a drano key, which is a
    combination of branding, a nonce, and the encrypting key.  The format is

        <tag_name>.<key_base64>.<nonce>

    Args:
        drano_key -- A provided drano key to unlock some encrypted text

    Returns:
        None if the format of the given drano key isn't recognized, otherwise
        a two indexed tuple, with an encoded key as a bit string in the first
        position, and an identifiying nonce in the second position.
    """
    parts = drano_key.split('.')
    if len(parts) == 3 and parts[0] == config.tag_name:
        try:
            return (decodestring(parts[1]), decodestring(parts[2]))
        except:
            return None
    else:
        return None


def create_drano_key(nonce, key):
    """Creates a user store-able encoding for Drano encoded information

    Creates a plain-text, copy-pasteable encoding of information a user needs
    to decrypt their data with drano.

    Args:
        nonce -- A semi-uniquely idenfiying tag for identifiying the cipher text
                 this key unlocks
        key   -- A bit string encoding of the key used to AES256 encode some
                 data.  This bit string should include the IV as the first
                 16 bits.

    Returns:
        A user-ready string in the form of <tag_name>.<key_base64>.<nonce>
    """
    return "%s.%s.%s" % (config.tag_name, encodestring(key).strip(),
                         encodestring(nonce).strip())


def parse_drano_ciphertext_tag(tag):
    """Parses a cipthertext tag, as stored in email, into its constituant parts.

    Args:
        tag -- A drano ciphertext tag, in the format of
               [<nonce> <cipher_text_base64>]

    Returns:
        None if the given tag is not in the expected format, and otherwise
        a tuple with the nonce bit string in the first position, and the
        encrypted bit string in the second position.
    """
    tag = tag.replace('Cloudsweeper.', '')
    if tag[0] != "[" or tag[-1] != "]":
        return None
    else:
        parts = tag.split(" ")
        if len(parts) != 2:
            return None
        else:
            nonce_section = parts[0][1:]
            nonce = decodestring(nonce_section)
            cipher_text_str = parts[1][:-1]
            cipher_text = decodestring(cipher_text_str)
            return nonce, cipher_text


def create_drano_ciphertext_tag(nonce, cipher_text):
    """Creates a cipher text tag for embed encrypted in an email message

    Args:
        nonce       -- A semi-uniquely idenfiying tag for identifiying this
                       cipher text, as a bit string
        cipher_text -- A bit string depiction of encrypted text.  This should
                       include the IV as the first 16 bits

    Returns:
        A string in the form of [<nonce> <cipher_text_base64>] for
        embeding in an email body.
    """
    return "[%s %s]" % (encodestring(nonce).strip(),
                        encodestring(cipher_text).strip())


def pad_term(term, block_size=16):
    term = term.encode('utf-8')
    term_length = len(term)
    return term + (block_size - term_length % block_size) * '\0'


def encrypt_password(plain_text, key):
    """Encrypts the given term under the specified key using AES256

    Args:
        plain_text -- A term to encrypt under AES256
        key        -- The key to use when encrypting the given password

    Returns:
        The ciphertext of the given plain_text, encrypted under the provided
        key. The 16 byte IV is appended to the beginning of the ciphertext.
    """
    padded_plain_text_bits = pad_term(plain_text)
    iv = Crypto.Random.get_random_bytes(16)

    aes_cipher = Crypto.Cipher.AES
    cbc_mode = Crypto.Cipher.AES.MODE_CBC
    encoder = aes_cipher.new(key, cbc_mode, iv)
    cipher_text = encoder.encrypt(padded_plain_text_bits)
    return iv + cipher_text


def decrypt_password(cipher_text, key):
    """Decrypts a term that was encrypted under AES256 using the given key

    Args:
        ciphertext -- The result of encrypting a term with AES256
        key        -- The key that was used to encrypt the given password

    Returns:
        A tuple with the original cipher text in the first position, and the
        plaintext version in the second.
    """
    cypher = Crypto.Cipher.AES.new(key, Crypto.Cipher.AES.MODE_CBC,
                                   cipher_text[:16])
    plain_text = cypher.decrypt(cipher_text[16:])
    return unicode(plain_text.rstrip(' \t\r\n\0'), 'utf-8')


def clean_password(password):
    """Returns a semi-cleaned version of the password provided"""
    length = len(password)
    if length > 2:
        return password[0] + "".join(["*" for item in range(length - 2)]) + password[-1]
    else:
        return password


class Collection(object):
    """Datastore for keeping track of which passwords have been found in which
    gmail message

    Basically just a dict with a global count and some convenience getters.
    The passwords are stored as the dict keys, and a list of Gmail message
    objects are stored as the corresponding values.

    This class is iterable.  Each iteration returns a password from the
    collection.

    """
    def __init__(self):
        self.total = 0
        self.message_count = 0
        self.passwords = dict()
        # Keep a lazy loaded verison of the keys in order of usage, and then
        # alphabetically sorted.
        self.ordering_dirty = True
        self.ordering = []

    def __iter__(self):
        """Iterate by returning each password we've captured so far"""
        return iter(self.passwords_by_use())

    def __getitem__(self, key):
        """Return the list of zero or more messages associated with the
        password"""
        return self.passwords[key]

    def __len__(self):
        return len(self.passwords)

    def __repr__(self):
        return "Password Collection (%d total, %d passes, %d messages)" % (
            self.total, len(self.passwords), self.message_count)

    def clear_mapping(self):
        """Deletes the internal mapping between semi-random integers and
        passwords.
        """
        self.mapping = None

    def generate_mapping(self):
        """Creates a non-reversable mapping of numbers to passwords. This can
        be used to refer to the passwords in this collection w/o having to
        reveal the values of the passwords.

        Returns:
            An integer x, such that all values from 0...(x - 1) are irreversable
            mappings into the set of passwords in this collection.
        """
        # Since self.passwords is a dict, the order of the returned passwords
        # is not guaranteed and thus not-reversable
        self.mapping = self.passwords.keys()
        return len(self.mapping)

    def mapped_password(self, index):
        """Returns the password for the given index (using the index / mapping
        generated by self.mapping()).

        Args:
            index -- an integer, less than the value reutrned by self.mapping

        Returns:
            The password if one still exists (it hasn't been removed since
            the mapping was generated), and otherwise None
        """
        if not hasattr(self, 'mapping'):
            return None
        else:
            try:
                return self.mapping[index]
            except IndexError:
                return None
            except TypeError:
                return None

    def mapped_messages(self, index):
        """Returns the list of zero or more messages that contain the password
        that corresponds to the given index (using the index / mapping
        generated by self.mapping()).

        Args:
            index -- an integer, less than the value reutrned by self.mapping

        Returns:
            A list of zero or more messages that contain the mapped password,
            if one still exists (ie if the password hasn't been removed
            from this collection since the mapping was generated),
            and otherwise None
        """
        mapped_password = self.mapped_password(index)
        if not mapped_password:
            return None
        else:
            try:
                return self.passwords[mapped_password]
            except KeyError:
                return None

    def combine(self, collection):
        """Create new collection from contents of current and passed collections

        Returns a newly instantiated Collection object that includes the
        contents of the current password collection and the password collection
        passed in.

        Arguments:
            collection -- A password collection object

        Returns:
            A password collection object
        """
        new_collection = Collection()

        for password in self:
            for message_summary in self[password]:
                new_collection.add_instance(password, message_summary)

        for password in collection:
            for message_summary in collection[password]:
                new_collection.add_instance(password, message_summary)

        return new_collection

    def _compare_passwords_by_sender(self, first_pass, second_pass):
        """Comparator for sorting passwords by usage by different senders.
        On tie, compare by absolute number of messages

        Args:
            first_pass  -- A password that appears in the collection
            second_pass -- Another password that appears in the collection

        Return:
            An integer, equivilent to a value returned by cmp, that determines
            the order first pass should appear relative to second pass
        """
        fp_domain_count = len(set(x[2] for x in self.passwords[first_pass]))
        sp_domain_count = len(set(x[2] for x in self.passwords[second_pass]))
        if fp_domain_count == sp_domain_count:
            return cmp(len(self.passwords[first_pass]), len(self.passwords[second_pass]))
        else:
            return cmp(fp_domain_count, sp_domain_count)

    def _compare_passwords_by_use(self, first_pass, second_pass):
        """Comparator for sorting passwords by usage

        First sorts passwords by number of found instances.  Passwords that
        appear in the collection an equal number of times are then sorted
        alphabetically by the password itself.

        Note that this function is designed to return a list with the highest
        used password first, but with equally used passwords appearing
        alphabetically descending.

        Args:
            first_pass  -- A password that appears in the collection
            second_pass -- Another password that appears in the collection

        Return:
            An integer, equivilent to a value returned by cmp, that determines
            the order first pass should appear relative to second pass
        """
        first_pass_count = len(self.passwords[first_pass])
        second_pass_count = len(self.passwords[second_pass])
        if first_pass_count != second_pass_count:
            return cmp(first_pass_count, second_pass_count)
        else:
            return cmp(first_pass, second_pass)

    def passwords_by_use(self):
        """Returns a dictionary of passwords in order of popularity

        Returns a list of passwords, sorted by the number of messages each
        password appears in (from most to least).

        Returns:
            A list of zero or more strings, each of which are a password
            in the current collection.
        """
        if self.ordering_dirty:
            passes = self.passwords
            self.ordering_dirty = False
            self.ordering = sorted(passes.keys(), cmp=self._compare_passwords_by_sender, reverse=True)
        return self.ordering

    def remove_password(self, password):
        self.message_count -= len(self.passwords[password])
        self.passwords[password] = []
        self.ordering_dirty = True

    def empty(self):
        self.message_count = 0
        self.passwords = {}
        self.ordering_dirty = True
        self.ordering = []
        self.total = 0

    def remove_instance(self, password, message):
        """Removes a stored instance of a message having a given password

        Args:
            password -- A string depicting a password
            message  -- A pygmail.message.Message object representing an email
                        that the given password was located in

        Returns:
            True if an instance was removed, otherwise False
        """
        if message not in self.passwords[password]:
            return False
        else:
            self.passwords[password].remove(message)
            self.message_count -= 1
            return True

    def add_instance(self, password, message):
        """Stores an association between a password and a specific gmail message

        Args:
            password -- A string depicting a password
            message  -- A pygmail.message.Message object representing an email
                        that the given password was located in

        Returns:
            True if the message was added to the collection of messages for This
            password.  Returns False if the messge was already in there (ie
            no changes were made).
        """
        self.ordering_dirty = True
        self.total += 1

        if password not in self.passwords:
            self.passwords[password] = []

        if message in self.passwords[password]:
            return False
        else:
            self.passwords[password].append((message.uid, message.subject, unicode(message.from_address)))
            self.message_count += 1
            return True

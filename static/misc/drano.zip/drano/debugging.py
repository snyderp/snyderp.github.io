"""A set of functions to help debug Drano issues"""


import logging
import config
import os
from os.path import isfile, join
from logging.handlers import TimedRotatingFileHandler
import tornado.ioloop
from tornado.log import app_log
from pygmail.mailbox import Mailbox
from pygmail.message import MessageBase
from pygmail.account import Account
import drano.users as DU
from drano.work_request import WorkRequest
import tornado.web


# Monkey patch in to the redirect method so that when we get the dreadded
# "can't redirect after headers have been written exception", we can at least
# log what the already written headers are
prev_redirect = tornado.web.RequestHandler.redirect


def redirect(self, url, permanent=False, status=None):
    if self._headers_written:
        app_log.error("about to write redirect when headers already exist")
        for name in self._headers:
            app_log.error(" - {header}: {value}".format(header=name, value=self._headers[name]))
    prev_redirect(self, url, permanent=permanent, status=status)

tornado.web.RequestHandler.redirect = redirect

# Monkey-patch in a new function for debugging errors that happen in the
# OILoop, so that we can try and at least get information about the user
# who triggered the exception in the logs too
prev_exception_handler = tornado.ioloop.IOLoop.handle_callback_exception


def new_exception_handler(self, callback):

    import inspect
    import sys

    def _log_message_details(a_message):
        # Only record possibly sensitive information if we're in debug mode
        # (ie if only developers are using the site)
        if config.debug:
            app_log.error("Problem Message Details\n  Subject: {subject}\n  Msg ID: {msg_id}".format(subject=a_message.subject, msg_id=a_message.message_id))

    prev_exception_handler(self, callback)

    type, value, traceback = sys.exc_info()
    email = None
    user = None
    child_frames = inspect.getinnerframes(traceback)

    for f in child_frames:
        child_args = inspect.getargvalues(f[0])
        # If we're in a Socket.IO callback, look for a user object we can
        # pull useful information out of

        if not user:
            for arg in child_args[3].values():
                if isinstance(arg, WorkRequest):
                    user = arg.user
                    email = user.email
                    break

        if not user:
            for arg in child_args[3].values():
                if isinstance(arg, DU.User):
                    user = arg
                    email = user.email
                    break

        if 'a_message' in child_args[3]:
            _log_message_details(child_args[3]['a_message'])
        elif 'message' in child_args[3]:
            _log_message_details(child_args[3]['message'])
        elif 'self' in child_args[3] and isinstance(child_args[3]['self'], MessageBase):
            _log_message_details(child_args[3]['self'])

        if 'user' in child_args[3]:
            user = child_args[3]['user']
            email = user.email
            break

        # Otherwise, if we're in a pygmail callback, step down through the
        # traceback frames and see if we can extract a email address
        # from one of the pygmail objects
        else:
            if 'self' in child_args[3]:
                obj = child_args[3]['self']

                if isinstance(obj, MessageBase):
                    email = obj.account.email
                    _log_message_details(obj)
                    break
                elif isinstance(obj, Mailbox):
                    email = obj.account.email
                    break
                elif isinstance(obj, Account):
                    email = obj.email
                    break

    # Only record PPI information in the logs if we're on a devel machine
    # (ie only record PPI if it is developers' PPI )
    if config.debug:
        if email is not None:
            app_log.error("User Account: {email}".format(email=email))
        else:
            app_log.error("Unable to determine email account")

    if user:
        user.end_current_work()
    del child_frames

tornado.ioloop.IOLoop.handle_callback_exception = new_exception_handler


def configure_logger():
    format = "%(created)f|%(pathname)s|%(message)s"

    if not os.path.exists(config.log_dir):
        os.makedirs(config.log_dir)
    access_log_file = os.path.join(config.log_dir,
                                   "access_{port}.log".format(port=config.port))
    access_log_handler = TimedRotatingFileHandler(access_log_file,
                                                  when="midnight")
    access_log_formatter = logging.Formatter("%(created)f|%(message)s")
    access_log_handler.setFormatter(access_log_formatter)
    access_logger = logging.getLogger('tornado.access')
    access_logger.addHandler(access_log_handler)
    access_logger.propagate = False

    error_log_file = os.path.join(config.log_dir,
                                  "error_{port}.log".format(port=config.port))
    error_log_handler = TimedRotatingFileHandler(error_log_file,
                                                 when="midnight")
    error_log_formatter = logging.Formatter(format)
    error_log_handler.setFormatter(error_log_formatter)
    error_logger = logging.getLogger('tornado.application')
    error_logger.addHandler(error_log_handler)
    error_logger.propagate = False

    gen_log_file = os.path.join(config.log_dir,
                                "gen_{port}.log".format(port=config.port))
    gen_log_handler = TimedRotatingFileHandler(gen_log_file,
                                               when="midnight")
    gen_log_formatter = logging.Formatter(format)
    gen_log_handler.setFormatter(gen_log_formatter)
    gen_logger = logging.getLogger('tornado.general')
    gen_logger.setLevel(logging.DEBUG if config.debug else logging.WARNING)
    gen_logger.addHandler(gen_log_handler)
    gen_logger.warning("drano started.")
    gen_logger.propagate = False


def drano_log(request_handler):
    if not config.log_dir:
        return
    else:
        status = request_handler.get_status()
        if status >= 400 or request_handler.request.uri.find('/static') != 0:
            http_request = request_handler.request
            params = dict(
                remote_ip=http_request.remote_ip,
                status=status,
                method=http_request.method,
                uri=http_request.uri,
                protocol=http_request.protocol
            )
            logging.getLogger("tornado.access").warning("%(remote_ip)s %(status)d %(protocol)s %(method)s %(uri)s" % params)


def test_messages():
    """Returns a list of all test messages currently in Drano's test set

    Returns:
        File names of all test messages in Drano's test set
    """
    test_message_dir = join(config.root_dir, "test_messages")
    test_messages = [f for f in os.listdir(test_message_dir) if isfile(join(test_message_dir, f))]
    return test_messages


def test_message_path(file_name):
    """Returns the complete path to a test message in Drano's test set

    Args:
        file_name -- The file name of a drano test email message

    Returns:
        The absolute path to the given test message, or None if it doesn't
        exist
    """
    full_path = join(config.root_dir, "test_messages", file_name)
    return full_path


def test_message_text(file_name):
    """Returns the text of a given test message in Drano's test set

    Args:
        file_name -- The file name of a drano test email message

    Returns:
        The body of the test messge, as a string, or None if the message
        couldn't be read
    """
    full_path = test_message_path(file_name)
    if not full_path:
        return None
    else:
        try:
            file = open(full_path, 'r')
            return ''.join(file.readlines())
        except IOError:
            return None

from pygmail.account import Account
from tornado.ioloop import IOLoop
from datetime import datetime
from tornado.log import gen_log
import time
import uuid
import passwords
import mailboxes
import config
import drano.passwords as DP
import drano.common as common
from drano.utilities import loop_cb_args, add_loop_cb


# If were in debug mode, also log information about current drano sessions and
# garbage collection.  Here we just poll the collection of current sessions
# and log some information about them.
if config.debug:
    def _user_session_monitor():
        gen_log.debug("Found {count} sessions".format(count=len(User.COLLECTION)))
        gen_log.debug(str([(User.COLLECTION[email].token, email) for email in User.COLLECTION]))


def _garbage_collect_user(email):
    """Removes all tracking information for a drano user. Triggered by a user
    tied logout event that fires after its been 12 hours since we've seen the
    user.

    Args:
        token -- the unique, user identification token

    Returns:
        True if any information was removed, and otherwise False
    """
    gen_log.debug(u"GC user: " + email)

    def _close_imap_connection(was_closed):
        gen_log.debug(u"GC closed IMAP connection for " + email)

    if email in User.COLLECTION:
        user = User.COLLECTION[email]
        del User.COLLECTION[email]
        user.close_gmail(callback=_close_imap_connection)


class User(object):
    """User objects store all semi-peristant information needed for drano.
    This class isn't intended to be instiantiated directly, and should
    instead be managaged by the above Collection class.

    Classes have the following properties:
        token        -- A string that uniquely identifies this user in drano
        last_seen    -- A datetime object, describing the last time this user
                        logged in or was seen
        tracking     -- A boolean description of whether this user opted in to
                        allow their informaiton to be tracked for analytic
                        purposes
        access_token -- The oauth returned access token for accessing this user's
                        gmail account
        email        -- The email address for the gmail account to be scanned
        passwords    -- a dictionary, with keys being mailbox names, and the
                        corresponding values bing drano.passwords.Passwords
                        object describing passwords found in that mailbox
    """

    # A collection of user objects currently logged into this server
    COLLECTION = {}

    @classmethod
    def load(cls, email, token, callback, reset=True, identifier=None):
        """Attempts to load an user object from the set of currently logged in
        users.

        Args:
            email -- the email address of the user to log in
            token -- the unique, server generated token for the user.  This
                     is a secret between the client and the server

        Keyword Args:
            reset      -- Whether to close the gmail IMAP connection, if one
                          exists
            identifier -- If this is set, use this identifier to distinguish
                          user sessions instead of the email address

        The given callback is called with a User object on success, and
        otherwise with None if no user could be loaded
        """
        found_user = dict()

        sess_id = identifier or email

        if sess_id not in cls.COLLECTION:
            loop_cb_args(callback, None)
            return

        # If we found a user, check to make sure that the given session
        # token is valid.  If its not, then something has gone wrong,
        # so again return nothing
        found_user[sess_id] = cls.COLLECTION[sess_id]

        if found_user[sess_id].token != token:
            loop_cb_args(callback, None)
            return

        found_user[sess_id].last_seen = datetime.now()

        # If we have instructions to close the IMAP connection for the user,
        # if its currently open, we should do so here before returning
        if reset:
            found_user[sess_id].end_current_work(callback=callback)
        # Otherwise, we can just return the user object directly without
        # changing it
        else:
            loop_cb_args(callback, found_user[sess_id])

    @classmethod
    def end(cls, email, token, callback, identifier=None):
        """Attempts to end the user session associated with the given user
        object.

        Args:
            email -- the email address of the user to log in
            token -- the unique, server generated token for the user.  This
                     is a secret between the client and the server

        Keyword Args:
            identifier -- If this is set, use this identifier to distinguish
                          user sessions instead of the email address

        If a session was closed, the given callback is called with True.
        Otherwise, the callback is called with False.
        """
        sess_id = identifier or email
        if sess_id not in cls.COLLECTION:
            loop_cb_args(callback, False)
        else:
            user = cls.COLLECTION[sess_id]
            if user.token != token:
                loop_cb_args(callback, False)
            else:
                del cls.COLLECTION[sess_id]
                user_cb = lambda x: loop_cb_args(callback, True)
                user.close_gmail(callback=user_cb)

    @classmethod
    def new(cls, email, callback, identifier=None):
        """Creates and returns a new user object for the given email address.
        The returned user object will have its token property set,
        which should be used by the browser / client as a unique token for
        accessing this user in the future.

        Args:
            email -- the email address of the user to log in

        Keyword Args:
            identifier -- If this is set, use this identifier to distinguish
                          user sessions instead of the email address
        """
        token = unicode(uuid.uuid4())
        user = User(token)
        user.email = email

        sess_id = identifier or email

        cls.COLLECTION[sess_id] = user
        loop_cb_args(callback, user)

    def __init__(self, token=None, silent=False):
        """Initilizer for User objects

        Arguments:
            drano_token -- A string that uniquely identifies this user in drano
        """
        self.token = token
        self.email = False
        self.last_seen = datetime.now()

        # Whether the user has opted into being tracked (ie having non-PPI
        # information stored about them)
        self.tracking = False

        # The OAuth2 access token that we use to connect on behalf of this
        # user to Gmail, and the time that'll expire
        self.access_token = None
        self.token_expiration = None

        # The localized names of the user's [Gmail]\All Mail and
        # [Gmail]\Trash folders
        self.all_folder = None
        self.trash_folder = None

        # Used to hold a reference to a description of the work currently
        # being done by the user.  Will either be None, if nothing intereactive
        # is being done with the user, or a reference to a
        # drano.work_request.WorkRequest object
        self.current_work = None

        # A lazy-loaded pygmail.account.Account instance, used for
        # connecting to the gmail
        self._account = None

        self.record_id = None

        # In order to make encrypting more stable, set a single encryption
        # key per session
        self.drano_key = DP.drano_key_create()
        self.drano_nonce = DP.drano_nonce_create()
        self.drano_key_tag = DP.create_drano_key(self.drano_nonce,
                                                 self.drano_key)

        self.data = dict()

        if not silent:
            try:
                since_update = datetime.now() - self.timeout_last_reset
                if 'timeout_handle' not in self.data:
                    self._schedule_gc()
                elif since_update.seconds >= 3600:
                    IOLoop.instance().remove_timeout(self.data['timeout_handle'])
                    self._schedule_gc()
            except AttributeError:
                self._schedule_gc()

    def has_been_gced(self):
        """Checks to see if we've been garbage collected, and thus our session
        data is no longer in a consistant state.  If so, we try to clean
        up our local state as much as possible and abandon ship

        Returns:
            True if the user is no longer valid (because of garbage collecting),
            and False in all other cases
        """
        if not self.email in User.COLLECTION:
            return True
        else:
            return False

    def _schedule_gc(self):
        self.data['timeout_handle'] = IOLoop.instance().add_timeout(
            config.session_gc_time,
            lambda: _garbage_collect_user(self.email)
        )
        self.timeout_last_reset = datetime.now()

    def _remove_gc(self):
        if 'timeout_handle' in self.data:
            IOLoop.instance().remove_timeout(self.data['timeout_handle'])
            return True
        else:
            return False

    def mailboxes(self):
        if "mailboxes" not in self.data:
            self.data['mailboxes'] = mailboxes.Collection()
        return self.data['mailboxes']

    def passwords_for_mailbox(self, mailbox):
        """Returns the password collection for the current user's mailbox

        Returns the password collection describing the set of passwords found
        in a mailbox owned by the current user.  If one doesn't already exists
        for the user, on is initilzied, but empty.

        Args:
            mailbox -- The name of a mailbox

        Returns:
            A drano.passwords.Password object
        """
        if "passwords" not in self.data:
            self.data['passwords'] = dict()
        if mailbox not in self.data['passwords']:
            self.data['passwords'][mailbox] = passwords.Collection()
        return self.data['passwords'][mailbox]

    def set_passwords_for_mailbox(self, password_collection, mailbox):
        """Sets a new collection of passwords for a user's mailbox

        Args:
            password_collection -- A drano.passwords.Collection object
                                   describing a set of passwords found in a
                                   mailbox
            mailbox             -- The name of a mailbox

        Returns:
            A reference to the current object
        """
        if 'passwords' not in self.data:
            self.data['passwords'] = dict()
        self.data['passwords'][mailbox] = password_collection
        return self

    def set_sec_till_expiration(self, secs):
        """Sets the number of seconds the current user has until her or his
        Oauth access token expires.

        Args:
            secs -- A positive integer value for the number of seconds until
                    this user's oauth access token expires
        """
        self.token_expiration = int(time.time()) + secs

    def sec_till_expiration(self):
        """Returns the number of seconds until the user's oauth access token
        expires.

        Returns:
            An integer number of seconds if the token is still valid, and otherwise
            None
        """
        if not self.access_token or not self.token_expiration:
            return None
        else:
            secs = self.token_expiration - int(time.time())
            return None if secs < 0 else secs

    def close_gmail(self, callback=None):
        """Attempts to close the IMAP connection to Gmail.  The given callback
        is called with the current user object as the only argument.
        """
        def _on_account_closed(was_closed):
            self._account = None
            if callback:
                callback(self)

        if self._account:
            self._account.close(callback=add_loop_cb(_on_account_closed))
        elif callback:
            callback(self)

    def get_gmail(self, callback, close=False):
        """Returns a pygmail.account.Account instance.

        The given callback will be called with a tuple containing two values,
        first the current user object, and second, the gmail account connection

        Keywork Args:
            close -- If True, the given pygmail connection will be closed
                     before its returned, if its currently open.
        """
        def _on_close(user):
            return self.get_gmail(callback)

        if self._account:
            if close:
                self._account.close(callback=_on_close)
            else:
                loop_cb_args(callback, (self, self._account))
            return

        id_params = dict(
            name=config.site_name,
            version=common.version,
            vendor=common.vender,
            contact=common.contact,
        )

        # If drano is configured to dump all network traffic, we want
        # to shim in our own IMAP4 subclass so that we can capture
        # all the back-and-forths
        if config.stress_test_record:
            import drano.profiling
            import drano.stress_test
            drano.stress_test.apply_monkey_patches()
            imap_class = drano.profiling.IMAP4_SSL_Netdump
        elif config.stress_test_run:
            # Importing this module will monkey patch the imap library
            # to use a predictable request tag
            import drano.stress_test
            drano.stress_test.apply_monkey_patches()
            imap_class = None
        else:
            imap_class = None
        self._account = Account(self.email, oauth2_token=self.access_token,
                                id_params=id_params, imap_class=imap_class)
        loop_cb_args(callback, (self, self._account))

    def get_current_work(self, callback):
        """Returns the current work request being performed by the user,
        if one exists.  The given callback will be called with two arguments,
        the current user object and the work request, if one exists, and other
        wise None"""
        loop_cb_args(callback, (self, self.current_work))

    def set_current_work(self, work, callback):
        """Sets the work currently being done by the user.  If this is different
        from the work currently being done by them, it'll close out the previous
        request before setting the new one.

        The given callback is called with two arguments.  First the current user
        object, and second, the newly set work request object

        Args:
            work -- a drano.work_request.WorkRequest instance, describing the
                    work currently being done by the user
        """
        if self.current_work and self.current_work != work:
            self.current_work.close()
            self.current_work = None
        self.current_work = work
        loop_cb_args(callback, (self, work))

    def end_current_work(self, callback=None):
        """ends the curret work being done by the user, including closing the
        gmail connection, if it is currently open.

        The given callback function is called with the current user as the
        only argument
        """
        if self.current_work:
            self.current_work.close()
            self.current_work = None
        self.close_gmail(callback=callback)

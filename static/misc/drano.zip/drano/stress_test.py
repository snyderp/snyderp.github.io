from tornado.httpclient import HTTPRequest
from tornado.simple_httpclient import SimpleAsyncHTTPClient
import imaplib2
import config


def apply_monkey_patches():
    """Hook into classes and functions we need to override / edit in order
    to get stress testing functioning
    """
    imaplib2.Int2AP = lambda x: config.imap_message_tag


class SimpleAsyncHTTPClient_Stresstest(SimpleAsyncHTTPClient):
    """Subclass the tornado provide HTTP client class (the class that actually
    does the call / response, instead of the singleton constructor class below)
    to disable all SSL validation on outgoing HTTPS requests"""

    def fetch(self, request, callback, **kwargs):
        if not isinstance(request, HTTPRequest):
            request = HTTPRequest(url=request, **kwargs)
        request.validate_cert = False
        return super(SimpleAsyncHTTPClient_Stresstest, self).fetch(request, callback, **kwargs)

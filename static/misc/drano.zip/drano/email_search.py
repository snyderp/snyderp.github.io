import re
import config


PASSWORD_PATTERN = re.compile(r'password\s?(?::|\sis)\s+?(?P<password>[\S]{5,})', re.I)

# A simple regular expression that is used to remove html tags from
# the end of token matches (so we don't include trailing HTML in
# passwords in HTML)
STRIP_END_TAGS_PATTERN = re.compile(r'&nbsp;|</?(?:div|p|b|strong|span|em|a).*?>', re.I)

# A simple regular expression to just check and see if a string looks like
# a url
SIMPLE_URL_PATTERN = re.compile(r'https?://', re.I)


def passwords_in_string(string):
    tokens = PASSWORD_PATTERN.findall(string)
    matches = []
    if tokens:
        for a_token in [strip_tags(t).strip() for t in tokens]:
            if not is_url(a_token) and not is_drano_tag(a_token) and len(a_token) > 4:
                matches.append(a_token)
    return matches


def is_drano_tag(string):
    try:
        if len(string) > 0 and string[0] == "[" and len(string) == 25:
            return True
        else:
            return string.index("[" + config.tag_name) == 0
    except ValueError:
        return False


# Simple function for attempting to strip away (X)HTML elements from the
# beginning and end of a possible password
def strip_tags(text):
    return STRIP_END_TAGS_PATTERN.sub(" ", text)


# Simple function that returns a boolean description of whether the given
# string looks like a URL
def is_url(text):
    return SIMPLE_URL_PATTERN.match(text) is not None

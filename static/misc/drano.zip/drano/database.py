"""Code and functions related to persistantly storing information in Drano"""

import config
import asyncmongo
from datetime import datetime
from pygmail.errors import is_encoding_error


connection_store = dict()


def connection():
    try:
        return connection_store['connection']
    except KeyError:
        connection_store['connection'] = asyncmongo.Client(**config.mongo)
        return connection_store['connection']


def audit_for_account(account_email, matching_rules, callback, db=None, fields=None):
    db = db if db else connection()
    record = {
        "matching_rules": [rule.name for rule in matching_rules],
        "created_on": datetime.utcnow(),
        "price": sum([rule.price for rule in matching_rules if rule.price])
    }

    record.update(fields)
    db.audit.insert(record, callback=callback)


def mailbox_summary(account_email, msg_count, uuid, passwords, callback, db=None):
    db = db if db else connection()

    domains = set()
    for pw in passwords:
        for msg_smry in passwords[pw]:
            sender = msg_smry[2]
            if "@" in sender:
                a_domain = sender.split("@")[1].strip(">")
                if " " in a_domain:
                    a_domain = a_domain.split(" ")[0]
                domains.add(a_domain)

    record = {
        "session": uuid,
        "messages": msg_count,
        "created_on": datetime.utcnow(),
        "num_passwords": sum((len(passwords[passwd]) for passwd in passwords)),
        "senders": list(domains)
    }
    db.summaries.insert(record, callback=callback)


def message_summary(message, uuid, passwords, action, callback, db=None):
    db = db if db else connection()
    is_reply = True
    try:
        message.headers['References']
    except KeyError:
        is_reply = False

    html_body = message.html_body()
    if not html_body or is_encoding_error(html_body):
        has_images = False
    else:
        has_images = "<IMG " in html_body.upper()

    if message.from_address.address and len(message.from_address.address.split("@")) > 1:
        fromdomain = message.from_address.address.split("@")[1]
    else:
        fromdomain = None

    record = {
        "session": uuid,
        "sender_domain": fromdomain,
        "sent_date": message.sent_datetime(),
        "action": action,
        "is_reply": is_reply,
        "has_images": has_images
    }
    db.messages.insert(record, callback=callback)


def survey_results(session_uuid, responses, callback, db=None):
    db = db if db else connection()
    responses = responses or dict()
    responses['session'] = session_uuid
    responses['created_on'] = datetime.now()
    responses['version'] = 2

    if "receive_updates" not in responses or responses['receive_updates'] != "1":
        responses['receive_email'] = ""

    db.survey_results.insert(responses, callback=callback)

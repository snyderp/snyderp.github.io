"""Stores common configuration and data structures used throughout Drano,
but which aren't intended to be configured between deployments"""

from tornado import template

# Strings and variables used throughout the site
version = '1.4.5'
vender = "UIC BITSLab"
contact = "ckanich@uic.edu"


# Mapping of the different actions we support over websockets to the
# landing urls for that action
ACTIONS = dict(
    refresh=None,
    search="/search/work",
    decrypt="/decrypt/search",
    audit="/audit/work",
)

"""

A global store for error codes, so that we can easily push users messages
to users after redirects with simple query string parameters (msg=3, etc.).

Not amazing, but easier than setting up a flash message system...

"""

MESSAGES = [
    u"There was an error authenticating with Gmail.  If you're interested in connecting, please try again",
    u"This looks like an invalid email address.  Please check again.",
    u"The given email address didn't match the one you authenticated with on GMail.  Please try again.",
    u"Your connection with GMail has expired.  Please connect again.",
    u"You have been successfully logged out.  Thanks!",
    u"You must select at least one password to encrypt or redact",
    u"Unknown action requested. Plese try again",
    u"Unable to find the [Gmail]/All Messages folder in your Gmail account. Please check your IMAP settings in Gmail before proceeding",
    u"Unable to find the [Gmail]/Trash folder in your Gmail account. Please check your IMAP settings in Gmail before proceeding",
]


def error_msg(code_num):
    """Returns the error message that corresponds to the given error code

    Arguments:
        code_num -- an integer, greater than 0, that corresponds to a drano
                    system message

    Returns:
        None if no matching error message could be found, otherwise the message
        as a unicode string
    """
    try:
        code_num = int(code_num)
        return None if code_num > len(MESSAGES) else MESSAGES[(code_num - 1)]
    except ValueError:
        return None


def render_partial(name, args):
    """Loads a template from the partials views directory

    These templates are intended to be used when returning HTML fror
    a web socket, or some other situation where the Tornado template
    block / extends pattern doesn't make sense. Most of the time this
    function should not be needed.

    Args:
        name -- the name of the template to load in the "views/partials"
                directory, excluding the trailing ".html"
        args -- a dictory of variables to use when rendering the template

    Returns:
        A string version of the content of the template
    """
    loader = template.Loader("/partials")
    return loader.load(name + ".html").generate(**args)

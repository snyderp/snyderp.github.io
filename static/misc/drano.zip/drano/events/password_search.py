from drano.email_search import passwords_in_string
from base64 import b64encode
from pygmail.errors import is_encoding_error
import drano.utilities as DUTIL
import drano.database as DD
import drano.gen
import config

EVENT_NAME = 'password-search-begin'


class PasswordSearchEvent(object):

    @drano.gen.prepare_socket_request(EVENT_NAME)
    def password_search(self, user, account, req, *args, **kwargs):
        cbp = dict(req=req)
        cb = DUTIL.add_loop_cb_args(self._password_search_mailbox, cbp)
        self.debug(user, "Fetching mailbox %s", user.all_folder)
        account.get(user.all_folder, callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    @drano.gen.mailbox_check(key='all_folder')
    def _password_search_mailbox(self, mailbox, req=None):
        self.debug(req.user, "Searching mailbox '%s'", mailbox.name)
        cbp = dict(mailbox=mailbox, req=req)
        cb = DUTIL.add_loop_cb_args(self._password_search_search, cbp)
        mailbox.search("password", limit=False, only_uids=True, callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    def _password_search_search(self, uids, mailbox, req=None):
        user = req.user
        req.emit("password-search-count", dict(count=len(uids)))

        passwords = user.passwords_for_mailbox(mailbox.name)
        passwords.empty()
        uid_bins = list(DUTIL.chunks(uids, 20))

        @drano.gen.validate_work_request(pos=0, socket=self, name=EVENT_NAME)
        def _work_cb(sub_uids, callback, **kwargs):
            self.debug(user, "Fetching uids '%s'", ", ".join(sub_uids))
            mailbox.fetch_all(sub_uids, callback=callback, teaser=True)

        @drano.gen.validate_work_request(pos=1, socket=self, name=EVENT_NAME)
        def _result_cb(sub_uids, messages, **kwargs):
            searched = 0
            new_match = []

            for message in messages:
                self.debug(user, "Searching for passwords in %s", message)
                searched += 1
                tokens_in_message = []

                if message.get_header('X-PyGmail-Data'):
                    self.debug(user,
                               "Skipping over previous transaction message %s",
                               message)
                elif message.body and not is_encoding_error(message.body):
                    plain_matches = passwords_in_string(message.body)
                    for a_token in plain_matches:
                        if a_token == config.removed_tag.split()[0]:
                            continue
                        if a_token not in tokens_in_message and passwords.add_instance(a_token, message):
                            new_match.append(dict(
                                sender=message.from_address.address,
                                password=a_token,
                                hashed_pass=b64encode(a_token.encode("utf-8", "replace"))
                            ))
                            tokens_in_message.append(a_token)

            req.emit("password-search-progress", dict(searched=searched, found=new_match))

        DUTIL.async_iterate(
            uid_bins,
            work_cb=_work_cb,
            result_cb=_result_cb,
            complete_cb=lambda: self._password_search_record(mailbox, req=req),
            req=req
        )

    @drano.gen.validate_work_request(name=EVENT_NAME)
    def _password_search_record(self, mailbox, req=None):
        user = req.user
        pws = user.passwords_for_mailbox(mailbox.name)
        pws.generate_mapping()
        hashed_passes = [(pw, b64encode(pw.encode("utf-8", "replace"))) for pw in pws.mapping]

        req.emit("password-search-mapping", dict(passwords=hashed_passes))
        user.record_id = req.request_id

        # Check to see if the user opted to not have their data tracked,
        # in which case, we're all done and nothing more is needed
        if user.tracking and config.stats_record:
            cbp = dict(mailbox=mailbox, req=req)
            cb = DUTIL.add_loop_cb_args(self._password_search_mailbox_count, cbp)
            mailbox.count(callback=cb)
        else:
            self._sign_account_out("password-search-complete", req=req)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    def _password_search_mailbox_count(self, msg_count, mailbox, req=None):
        user = req.user
        cbp = dict(websocket_event="password-search-complete", req=req)
        cb = DUTIL.add_loop_cb_mongo_args(self._sign_account_out, cbp)
        DD.mailbox_summary(user.email, msg_count, user.record_id,
                           user.passwords_for_mailbox(mailbox.name),
                           callback=cb)

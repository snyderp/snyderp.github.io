import drano.utilities as DUTIL
import drano.passwords as DP
import drano.gen
from pygmail.errors import is_encoding_error

EVENT_NAME = 'account-decrypt'


class PasswordDecryptEvent(object):

    ### Mailbox Decrypting Events ###
    @drano.gen.prepare_socket_request(EVENT_NAME)
    def account_decrypt(self, user, account, req, *args, **kwargs):

        # First, check and make sure we have a valid drano key to work with
        key = kwargs.get('key', None)
        key_parts = DP.parse_drano_key(key)
        if not key_parts:
            req.emit("account-decrypt-key-error")
            user.end_current_work()
            return

        user.data['decrypt_count'] = 0
        user.data['message_count'] = 0
        self.debug(user, "Decrypting passwords in %s", user.all_folder)
        cbp = dict(key_parts=key_parts, req=req)
        cb = DUTIL.add_loop_cb_args(self._account_decrypt_mailbox, cbp)
        account.get(user.all_folder, callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    @drano.gen.mailbox_check(key='all_folder')
    def _account_decrypt_mailbox(self, mailbox, key_parts, req=None):
        user = req.user
        key, nonce = key_parts
        search_term = '"' + DP.drano_nonce_search_token(nonce).strip() + '"'
        self.debug(user, "Searching for encrypted text in %s", user.all_folder)

        cbp = dict(mailbox=mailbox, key_parts=key_parts, req=req)
        cb = DUTIL.add_loop_cb_args(self._account_decrypt_messages, cbp)
        mailbox.search(search_term.replace(r'/', r'\\/'), limit=False, gm_ids=True, callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    def _account_decrypt_messages(self, gm_ids, mailbox, key_parts, req=None):
        key, nonce = key_parts
        user = req.user
        req.emit("account-decrypt-count", dict(count=len(gm_ids)))

        @drano.gen.validate_work_request(pos=0, name=EVENT_NAME, socket=self)
        def _fetch_cb(gmail_id, callback=None, **kwargs):
            self.debug(user, "Fetching message with uid %s", gmail_id)
            mailbox.fetch_gm_id(gmail_id, callback=callback, full=True)

        @drano.gen.validate_work_request(pos=1, name=EVENT_NAME, socket=self)
        def _work_cb(gmail_id, message, callback=None, **kwargs):
            if not message:
                callback(None)
                return

            plain_body = message.plain_body()
            html_body = message.html_body()

            matches = []
            if plain_body and not is_encoding_error(plain_body):
                matches += DP.decrypt_ciphertext_in_text(key, nonce, plain_body)
            if html_body and not is_encoding_error(html_body):
                matches += DP.decrypt_ciphertext_in_text(key, nonce, html_body)

            self.debug(user, "About to decrypt %d passwords in %s",
                       len(matches), message)
            user.data['decrypt_count'] += len(matches)
            user.data['message_count'] += 1
            if len(matches) > 0:
                finds = []
                replacements = []
                for match in matches:
                    finds.append(match[0])
                    replacements.append(match[1])
                message.replace(finds, replacements, user.trash_folder,
                                callback=callback)
            else:
                callback(False)

        @drano.gen.validate_work_request(pos=2, name=EVENT_NAME, socket=self)
        def _result_cb(gmail_id, message, work_result, callback=None, **kwargs):
            self.debug(user, "Finished decryption for %s", message)
            subject = message.subject if message else None
            req.emit("account-decrypt-progress", dict(subject=subject))
            callback()

        DUTIL.async_iterate_remote(
            gm_ids,
            fetch_cb=_fetch_cb,
            work_cb=_work_cb,
            result_cb=_result_cb,
            complete_cb=lambda: self._sign_account_out("account-decrypt-complete", req=req),
            req=req
        )

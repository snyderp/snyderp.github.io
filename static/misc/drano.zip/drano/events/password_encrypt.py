import drano.utilities as DUTIL
import drano.database as DD
import drano.passwords as DP
import drano.gen
import config


# In order to make sure we make no irreversable changes to user's mailboxes,
# we create a temporary copy of each message in the user's mailbox before we
# delete / resave any messages. The below is the name we use for this mailbox
TRANSACTIONAL_LABEL = '"%s Work"' % (config.site_name,)
EVENT_NAME = 'password-encrypt-begin'


class PasswordEncryptEvent(object):

    ### Password Scrubbing Events ###
    @drano.gen.prepare_socket_request(EVENT_NAME)
    def encrypt(self, user, account, req, *args, **kwargs):
        pw_mappings = kwargs.get('pw_mappings', None)
        action = kwargs.get('action', None)
        mailbox_name = user.all_folder

        # Passwords are sent to us as a series of integers, which correspond
        # to the indexes of which passwords should be scrubbed.  Since the
        # passwords in the password colleciton are strictly ordered, we know
        # that these indexes will match up to the passwords the user
        # selected
        pw_collection = user.passwords_for_mailbox(mailbox_name)

        message_pws = dict()

        # Next, break the selected passwords up into tupples, with the first
        # item being the password that should be scrubbed from email messages
        # in this mailbox, and the second index being a tuple of message
        # uids that contain the password
        for mapped_index in (int(index) for index in pw_mappings):
            password_to_scrub = pw_collection.mapped_password(mapped_index)
            short_messages_with_pw = pw_collection.mapped_messages(mapped_index)
            if password_to_scrub and short_messages_with_pw:
                for message_short in short_messages_with_pw:
                    if message_short not in message_pws:
                        message_pws[message_short] = []
                    message_pws[message_short].append(password_to_scrub)

        # Note that the "work units" here is a nested tuple in the
        # following format
        #   ((message_uid, message_subject, message_sender_address), password))
        work_units = tuple((message_smry, message_pws[message_smry]) for message_smry in message_pws)
        pw_collection.clear_mapping()
        self.debug(user, "'%s' passwords in '%s'", action, mailbox_name)
        cbp = dict(action=action, work_units=work_units, req=req)
        cb = DUTIL.add_loop_cb_args(self._password_encrypt_mailbox, cbp)
        account.get(mailbox_name, callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    @drano.gen.mailbox_check('all_folder')
    def _password_encrypt_mailbox(self, mailbox, action, work_units, req=None):
        user = req.user
        user_passwords = user.passwords_for_mailbox(mailbox.name)
        req.emit("password-encrypt-details", dict(count=len(work_units)))

        temp_message_state = dict()
        db = DD.connection() if user.tracking and config.stats_record else None

        @drano.gen.validate_work_request(pos=0, name=EVENT_NAME, socket=self)
        def _fetch_cb(work_unit, callback=None, **kwargs):
            message_smry, passwords = work_unit
            msg_uid, msg_subject, msg_sender = message_smry
            self.debug(user, "Fetching uid '%s'", msg_uid)
            mailbox.fetch_all((msg_uid,), full=True, callback=callback)

        @drano.gen.validate_work_request(pos=1, name=EVENT_NAME, socket=self)
        def _work_cb(work_unit, a_msg, callback=None, **kwargs):
            # If this message doesn't have a message id, its not safe
            # to operate on, since we rely on the message ID to delete the
            # copied message and have gmail insert it back into any threaded
            # conversation
            if not a_msg.message_id:
                callback(None)
                return
            org_msg_smry, passwords = work_unit
            orig_msg_uid, orig_msg_subject, orig_sender = org_msg_smry

            @drano.gen.validate_work_request(pos=0, name=EVENT_NAME, socket=self)
            def _on_copy_saved(copied_message_identifiers, **kwargs):
                copy_uid, copy_message_id = copied_message_identifiers
                temp_message_state['copy_uid'] = copy_uid
                temp_message_state['copy_message_id'] = copy_message_id

                finds = []
                replaces = []

                for pw in passwords:
                    if action == "encrypt":
                        cipher_text = DP.encrypt_password(pw, user.drano_key)
                        drano_cipher_text_tag = DP.create_drano_ciphertext_tag(
                            user.drano_nonce, cipher_text)
                    else:
                        drano_cipher_text_tag = config.removed_tag

                    user_passwords.remove_instance(pw, org_msg_smry)

                    finds.append(pw)
                    replaces.append(drano_cipher_text_tag)

                user.set_passwords_for_mailbox(user_passwords, mailbox.name)
                self.debug(user, "Encrypting '%s'", a_msg)
                a_msg.replace(finds, replaces, user.trash_folder, callback=callback)

            self.debug(user, "Saving transaction of %s to %s", a_msg,
                       TRANSACTIONAL_LABEL)

            cbp = dict(req=req)
            cb = DUTIL.add_loop_cb_args(_on_copy_saved, cbp)
            a_msg.save_copy(TRANSACTIONAL_LABEL,
                            header_label=config.site_name, callback=cb)

        @drano.gen.validate_work_request(pos=2, name=EVENT_NAME, socket=self)
        def _result_cb(work_unit, a_msg, work_result, callback=None, **kwargs):
            if work_result is None:
                req.emit("password-encrypt-malformed-message")
                callback()
                return

            orig_msg_smry, passwords = work_unit

            @drano.gen.validate_work_request(pos=0, name=EVENT_NAME, socket=self)
            def _on_delete_copy(was_deleted, req=None):
                if was_deleted:
                    self.debug(user, "Deleted '%s' transaction", a_msg)
                    if db:
                        DD.message_summary(a_msg, user.record_id,
                                           passwords, action,
                                           lambda result, error: callback(), db=db)
                    else:
                        callback()
                else:
                    self.debug(user, 'Error deleting message %s', str(a_msg))
                    req.emit("password-encrypt-error")
                    callback()

            req.emit("password-encrypt-progress", dict(message=a_msg.subject))
            self.debug(user, "Encrypted '%s'", a_msg)
            cbp = dict(req=req)
            cb = DUTIL.add_loop_cb_args(_on_delete_copy, cbp)
            mailbox.delete_message(temp_message_state['copy_uid'],
                                   temp_message_state['copy_message_id'],
                                   user.trash_folder,
                                   callback=cb)

        DUTIL.async_iterate_remote(
            work_units,
            fetch_cb=_fetch_cb,
            work_cb=_work_cb,
            result_cb=_result_cb,
            complete_cb=lambda: self._password_encrypt_complete(mailbox, req=req),
            req=req
        )

    @drano.gen.validate_work_request(pos=None, name=EVENT_NAME)
    def _password_encrypt_complete(self, mailbox, req=None):
        user = req.user
        req.emit("password-encrypt-cleanup")

        # Once we've finished encrypting / redacting all messages, we can go
        # ahead and delete the temporary / transaction mailbox (if it is empty)
        mailbox.account.clear_mailbox_cache()
        self.debug(user, "Fetching '%s' mailbox to see if it is empty",
                   TRANSACTIONAL_LABEL)
        cbp = dict(req=req)
        cb = DUTIL.add_loop_cb_args(
            self._password_encrypt_fetched_trans_mailbox, cbp)
        mailbox.account.get(TRANSACTIONAL_LABEL, callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    @drano.gen.mailbox_check(name=TRANSACTIONAL_LABEL)
    def _password_encrypt_fetched_trans_mailbox(self, mailbox, req=None):
        cbp = dict(mailbox=mailbox, req=req)
        cb = DUTIL.add_loop_cb_args(self._password_encrypt_count, cbp)
        mailbox.count(callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    def _password_encrypt_count(self, count, mailbox, req=None):
        user = req.user
        self.debug(user, "Found '%d' messages in %s", count, TRANSACTIONAL_LABEL)

        # If there are still messages tagged with the "Transactional" label,
        # don't remove the label, since there could be messages there from
        # a previous encryption / decryption attempt.
        if count > 0:
            self.debug(user, "Not attempting to remove %s since it is not empty",
                       TRANSACTIONAL_LABEL)
            self._sign_account_out("password-encrypt-complete", req=req)
        else:
            self.debug(user, "Attempting to remove %s", TRANSACTIONAL_LABEL)
            cbp = dict(websocket_event="password-encrypt-complete", req=req)
            cb = DUTIL.add_loop_cb_args(self._sign_account_out, cbp,
                                        include_return=False)
            mailbox.delete(callback=cb)

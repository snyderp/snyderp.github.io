from drano.auditing import audit_rules
import drano.utilities as DUTIL
import drano.database as DD
import drano.gen
import config

WORK_NAME = 'mailbox-audit'


class AuditEvent(object):
    """SocketIO event for triggering and providing feedback about searching
    a users email account for messages that suggest that the account would
    give an attacker access to other high value sites / accounts on the
    internet (ie if buying / cracking this account would also give the attacker
    access to an Amazon account, etc.)

    Assuming no errors, connecting clients will receive the following
    responses:

    * mailbox-audit-connecting:
        Informing the client that a the server is attempting to connect to the
        current users mail account

    * mailbox-audit-num-rules:
        Informs the client that a connection has been successfully established
        with the IMAP server.  Also informs the client the number of rules /
        ties to remote accounts that will be searched for the account.

        Response:
            num_rules: (int) the number of searches that will be performed

    * mailbox-audit-rule-start: (for each rule)
        Informs the client that we're about conduct a search of the user's
        email account to see if any messages look like they could be matches
        for messages indicating access to another valuable account.

        Response:
            name: (string)    A user displayable summary of this rule (ex Amazon
                              account)
            uid: (string)     A unique identifier for this rule
            rule_index: (int) The 0 indexed position of the currently executed
                              rule in the collection of all rules that will
                              executed

    * mailbox-audit-rule-filter: (for each message returned from a rule's broad
                                  search)
        Informs the client that we recevied some results for a broad search
        for messages indicating access to a high value account and are now
        filtering them, one by one, to make sure they are not false positives

        Response:
            name: (string)      A user displayable summary of this rule (ex
                                Amazon account)
            uid: (string)       A unique identifier for this rule
            rule_index: (int)   The 0 indexed position of the currently executed
                                rule in the collection of all rules that will
                                executed
            match_index: (int)  The position / index of the message being
                                closely checked in the full set of the broad
                                matches (0 indexed)
            match_count: (int)  The number of messages that match the board
                                search term for this pricing rule. Will always
                                be > to index

    * mailbox-audit-rule-done: (for each message returned from a rule's broad
                               search)
        Informs the client that we've finished narrow searching / filtering
        a message, and can (for our purposes) conclusivly say if the message
        is a match or not for the given rule

        Response:
            name: (string)      A user displayable summary of this rule (ex
                                Amazon account)
            uid: (string)       A unique identifier for this rule
            subject: (string)   The subject of the email message that was
                                exhastivly searched
            date: (string)      User presentable date string of when the email
                                was sent (in MM/DD/YYYY format)
            is_match: (bool)    A boolean description of whether we think this
                                messsage was a match for the rule or not
            match_index: (int)  The position / index of the message being
                                closely checked in the full set of the broad
                                matches (0 indexed)
            match_count: (int)  The number of messages that match the board
                                search term for this pricing rule. Will always
                                be > to index

    * mailbox-audit-complete:
        Informs the client that the search is complete

    """

    ### Attempts to assess the value of a mailbox to a neirdowell
    @drano.gen.prepare_socket_request(WORK_NAME)
    def mailbox_audit(self, user, account, req):
        req.emit("mailbox-audit-connecting")
        self.debug(user, "Pricing account based on %s", user.all_folder)
        cbp = dict(req=req)
        callback = DUTIL.add_loop_cb_args(self._mailbox_audit_mailbox, cbp)
        account.get(user.all_folder, callback=callback)

    @drano.gen.validate_work_request(name=WORK_NAME)
    @drano.gen.mailbox_check(key='all_folder')
    def _mailbox_audit_mailbox(self, mailbox, req=None):
        cbp = dict(mailbox=mailbox, req=req)
        callback = DUTIL.add_loop_cb_args(self._mailbox_audit_fetched_rules, cbp)
        audit_rules(callback)

    @drano.gen.validate_work_request(name=WORK_NAME)
    def _mailbox_audit_fetched_rules(self, rules, mailbox, req=None):
        # As we execute each pricing rule, use the below dict to
        # keep track of state of the rule search (ex which rule
        # in the rule collection we're currently executing)
        rule_state = dict(index=0, matches=[])
        req.emit("mailbox-audit-num-rules", dict(num_rules=len(rules)))

        @drano.gen.validate_work_request(pos=0, socket=self, name=WORK_NAME)
        def _fetch_cb(a_pricing_rule, callback, **kwargs):
            rule_state['index'] = kwargs['index']

            return_params = dict(name=a_pricing_rule.name,
                                 uid=a_pricing_rule.id,
                                 rule_index=kwargs['index'])
            req.emit("mailbox-audit-rule-start", return_params)

            broad_rules = " OR ".join(a_pricing_rule.broad_rules())

            if a_pricing_rule.broad_rules_negation:
                broad_rules += " " + " ".join(["-" + br for br in a_pricing_rule.broad_rules_negation])

            mailbox.search(broad_rules, limit=200, teaser=True,
                           callback=DUTIL.add_loop_cb(callback))

        @drano.gen.validate_work_request(pos=1, socket=self, name=WORK_NAME)
        def _work_cb(a_pricing_rule, a_teaser, callback, **kwargs):
            return_params = dict(name=a_pricing_rule.name,
                                 uid=a_pricing_rule.id,
                                 rule_index=rule_state['index'],
                                 match_index=kwargs['index'],
                                 match_count=kwargs['count'])
            req.emit("mailbox-audit-rule-filter", return_params)

            # If this rule doesn't have any narrow rules, it means
            # that a match to the broad rule is an automatic
            # match.  Otherwise, run the given regular expression
            # (narrow rule) against the body of the message to
            # see if the message matches the more narrow criteria
            # too.
            matches = False
            if a_pricing_rule.matches_narrow_rule(a_teaser.body):
                matches = True
            DUTIL.loop_cb_args(callback, matches)

        @drano.gen.validate_work_request(pos=2, socket=self, name=WORK_NAME)
        def _result_cb(a_pricing_rule, a_teaser, is_match, callback, **kwargs):
            return_params = dict(name=a_pricing_rule.name,
                                 uid=a_pricing_rule.id,
                                 match_index=kwargs['index'],
                                 match_count=kwargs['count'],
                                 subject=a_teaser.subject,
                                 is_match=is_match)
            if is_match:
                rule_state['matches'].append(a_pricing_rule)
                return_params['rule'] = dict(
                    name=a_pricing_rule.name,
                    severity=a_pricing_rule.severity,
                    price=a_pricing_rule.price,
                    extra_factor=a_pricing_rule.extra_factor,
                    domain=a_pricing_rule.domain,
                    id=a_pricing_rule.id,
                )

            req.emit('mailbox-audit-rule-done', return_params)

            # If we've found a match for this rule, there is no need
            # to keep processing messages for the rule.  We just
            # care about any messages that match the rule, not all
            # of them.
            DUTIL.loop_cb_args(callback, not is_match)

        DUTIL.async_iterate_remote(
            rules,
            fetch_cb=_fetch_cb,
            work_cb=_work_cb,
            result_cb=_result_cb,
            complete_cb=lambda: self._mailbox_audit_complete(
                mailbox, rule_state['matches'], req=req),
            req=req,
            quick_exit=True
        )

    @drano.gen.validate_work_request(name=WORK_NAME)
    def _mailbox_audit_complete(self, mailbox, matched_rules, req=None):
        if req.user.tracking and config.stats_record:
            cbp = dict(websocket_event="mailbox-audit-complete", req=req)
            cb = DUTIL.add_loop_cb_mongo_args(self._sign_account_out, cbp)
            additional_fields = {}
            for a_field in ('study_name', 'participant_tag'):
                if a_field in req.user.data:
                    additional_fields[a_field] = req.user.data[a_field]
            DD.audit_for_account(req.user.email, matched_rules, callback=cb, fields=additional_fields)
        else:
            self._sign_account_out("mailbox-audit-complete", req=req)

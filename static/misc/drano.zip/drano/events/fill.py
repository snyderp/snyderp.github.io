import drano.utilities as DUTIL
import drano.gen
import drano.debugging
from datetime import datetime

EVENT_NAME = 'mailbox-fill'


class FillEvent(object):

    @drano.gen.prepare_socket_request(EVENT_NAME)
    def mailbox_fill(self, user, account, req, *args, **kwargs):
        files = kwargs.get('files')
        new_msgs = files or drano.debugging.test_messages()
        cbp = dict(new_msgs=new_msgs, req=req)
        cb = DUTIL.add_loop_cb_args(self._mailbox_fill_account, cbp)
        account.get(user.all_folder, callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    @drano.gen.mailbox_check('all_folder')
    def _mailbox_fill_account(self, mailbox, new_msgs, req=None):
        cbp = dict(mailbox=mailbox, new_msgs=new_msgs, req=req)
        cb = DUTIL.add_loop_cb_args(self._mailbox_fill_messages, cbp)
        mailbox.messages(limit=False, callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    def _mailbox_fill_messages(self, current_msgs, mailbox, new_msgs, req=None):
        user = req.user

        @drano.gen.validate_work_request(pos=0, name=EVENT_NAME, socket=self)
        def _work_cb(message, callback=None, **kwargs):
            message.delete(user.trash_folder, callback=callback)

        @drano.gen.validate_work_request(pos=1, name=EVENT_NAME, socket=self)
        def _result_cb(message, rs, **kwargs):
            req.emit("mailbox-fill-deleted", dict(deleted=message.subject))

        req.emit("mailbox-fill-overview", dict(to_delete=len(current_msgs),
                                               to_create=len(new_msgs)))

        DUTIL.async_iterate(
            current_msgs,
            work_cb=_work_cb,
            result_cb=_result_cb,
            complete_cb=lambda: self._mailbox_fill_create(mailbox, new_msgs,
                                                          req=req),
            req=req
        )

    @drano.gen.validate_work_request(name=EVENT_NAME)
    def _mailbox_fill_create(self, mailbox, drano_messages, req=None):
        req.emit("mailbox-fill-deleted-complete")
        cbp = dict(drano_messages=drano_messages, mailbox=mailbox, req=req)
        cb = DUTIL.add_loop_cb_args(self._mailbox_fill_connection, cbp)
        mailbox.account.connection(callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    def _mailbox_fill_connection(self, connection, drano_messages, mailbox, req=None):

        @drano.gen.validate_work_request(pos=0, name=EVENT_NAME, socket=self)
        def _work_cb(test_msg, callback=None, **kwargs):
            now = tuple(datetime.now().timetuple())
            connection.append('"INBOX"', '()', now,
                              drano.debugging.test_message_text(test_msg),
                              callback=callback)

        @drano.gen.validate_work_request(pos=1, name=EVENT_NAME, socket=self)
        def _result_cb(test_msg, rs, **kwargs):
            msg = dict(created=test_msg)
            req.emit("mailbox-fill-created", msg)

        DUTIL.async_iterate(
            drano_messages,
            work_cb=_work_cb,
            result_cb=_result_cb,
            complete_cb=lambda: self._sign_account_out("mailbox-fill-complete",
                                                       req=req),
            req=req
        )

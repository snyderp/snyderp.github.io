"""account touch - download, reencode, and store to test for decoding errors"""

from pygmail.errors import is_encoding_error
from pygmail.message import Message, MessageTeaser
import drano.utilities as DUTIL
import drano.gen

EVENT_NAME = 'mailbox-touch'


class TouchEvent(object):

    @drano.gen.prepare_socket_request(EVENT_NAME)
    def account_touch(self, user, account, req, *args, **kwargs):
        user.data['touch_count'] = 0
        self.debug(user, "touching passwords in %s", user.all_folder)
        cbp = dict(req=req)
        cb = DUTIL.add_loop_cb_args(self._account_touch_mailbox, cbp)
        account.get(user.all_folder, callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    @drano.gen.mailbox_check(key='all_folder')
    def _account_touch_mailbox(self, mailbox, req=None):
        user = req.user
        self.debug(user, u"Loading all email messages in %s", mailbox.name)
        cbp = dict(mailbox=mailbox, req=req)
        cb = DUTIL.add_loop_cb_args(self._account_touch_messages, cbp)
        mailbox.messages(limit=False, only_uids=True, offset=0, callback=cb)

    @drano.gen.validate_work_request(name=EVENT_NAME)
    def _account_touch_messages(self, uids, mailbox, req=None):
        uid_bins = list(DUTIL.chunks(uids, 10))
        user = req.user
        req.emit("mailbox-touch-overview", dict(to_touch=len(uids)))

        @drano.gen.validate_work_request(name=EVENT_NAME, socket=self, pos=0)
        def _fetch_cb(some_uids, callback=None, **kwargs):
            self.debug(user, "Fetching message with uid %s", some_uids)
            mailbox.fetch_all(some_uids, callback=callback, full=True)

        @drano.gen.validate_work_request(name=EVENT_NAME, socket=self, pos=1)
        def _work_cb(some_uids, a_message, callback=None, **kwargs):
            callback(a_message.gmail_id)

        @drano.gen.validate_work_request(name=EVENT_NAME, socket=self, pos=2)
        def _result_cb(some_uids, a_message, gmail_id, callback=None, **kwargs):
            self.debug(user, "Finished touching for %s", a_message)

            date = a_message.sent_datetime().__str__() if a_message.sent_datetime() else "(missing)"

            values = dict(
                internal_date=a_message.internal_date.__str__() if a_message.internal_date else '(malformed)',
                date=date,
                recipient_address=a_message.to_address.address,
                recipient_name=a_message.to_address.name,
                sender_address=a_message.from_address.address,
                sender_name=a_message.from_address.name,
                touched=a_message.subject,
                message_id=gmail_id,
                labels=a_message.labels_raw,
                flags=", ".join(a_message.flags)
            )

            if a_message.__class__ == MessageTeaser:
                body = a_message.body if a_message.body and not is_encoding_error(a_message.body) else ''
                values['body_len'] = len(body)
                values['amt'] = len(body) + len(a_message.headers)
            elif a_message.__class__ == Message:
                plain_body = a_message.plain_body()
                html_body = a_message.html_body()
                plain_body = plain_body if plain_body and not is_encoding_error(plain_body) else ''
                html_body = html_body if html_body and not is_encoding_error(html_body) else ''
                values['plain_len'] = len(plain_body)
                values['html_len'] = len(html_body)
                values['amt'] = len(a_message.as_string())

            req.emit("mailbox-message-touched", values)
            callback()

        DUTIL.async_iterate_remote(
            uid_bins,
            fetch_cb=_fetch_cb,
            work_cb=_work_cb,
            result_cb=_result_cb,
            complete_cb=lambda: self._sign_account_out("mailbox-touch-complete",
                                                       req=req),
            req=req
        )

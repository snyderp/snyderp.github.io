"""Functions and decorators useful for handling errors with imaplib,
pygmail, and socket.io"""

from pygmail.errors import is_imap_error, is_auth_error, is_connection_closed_error
from pygmail.mailbox import Mailbox
from drano.work_request import WorkRequest
from tornado.log import app_log, gen_log
import config
import drano.users
import tornado.web
import datetime


def prepare_socket_request(event):
    """A decorator for SocketIO events to validate and, if appropriate,
    create a new work request object.  It is expected to decorate a function
    already decorated by the tornadio2.event decorator.

    This decorator expects that the underlying event will be called with
    the following three arguments:
        token         -- A unique token, used to represent a single user
                         throughout their interaction with drano
        request_token -- A client / browser generated token, used to
                         keep track of this work request through out
                         the lifetime of this work request.  Used for
                         reconnecting with a previous work request
                         between Socket.IO connections
        email         -- The email address used to connect with Gmail.
                         Used to make sure that a user can't DOS us
                         by connecting multiple times to Gmail with
                         different sessions

    (These values are loosely enforced drano.websockets.SocketIOServer.on_open)

    1)  If these values don't exist, nothing is done, and the current
        SocketRequest is closed immediatly.

    2)  If the values do exist, we check to make sure that the given email
        address and token correspond to a valid current drano user.  If not
        a message "invalid-socket-request" is sent over the current
        SocketRequest, and then the connection is closed.

    3)  Once we have a valid user object, we can look to see if it currently
        has a work request attached to it.

            * If so, see if it is the same request that corresponds to the
              client generated `request_token`.  If so, then it means
              the client is likely trying to reconnect to the same request,
              so just shim in the current socket connection to the existing
              work request.  Do nothing else...

            * If there is a work request object, but it doesn't correspond
              to the existing request token, then close the previous work
              request object and create a new one for what is being requested
              now.

            * If there is not a work request for the user currently, then
              just create a new one and register it with the user
    """
    def decorator(func):
        def inner(self, token, request_token, email, *args, **kwargs):

            def _on_gmail(user, account, work_request):
                func(self, user, account, work_request, *args, **kwargs)

            def _on_work_set(rs):
                user, work_request = rs
                cb = lambda x: _on_gmail(x[0], x[1], work_request)
                user.get_gmail(callback=cb)

            def _on_work_cancelled(user):
                new_work = WorkRequest(user, request_token, event, self)
                user.set_current_work(new_work, callback=_on_work_set)

            def _on_current_work(rs):
                user, work_request = rs
                # If there isn't currently a work request for the user, then
                # we're in the simplest situation, since we can just create
                # a new work request, attach it to the user, and then
                # continue on with the work at hand
                if not work_request:
                    new_work = WorkRequest(user, request_token, event, self)
                    user.set_current_work(new_work, callback=_on_work_set)
                    return

                # Otherwise, if ther is a work request currently scheduled for
                # the user, check to see if it has the same request token
                # that we're currently requesting with.  If it doesn,
                # then it means we want to hang onto the work currently being
                # done, so just shim the new socket request into the existing
                # work request.
                #
                # Note that we don't call back to the wrapped funciton here,
                # because we don't want to double execute this work.  Instead,
                # we just let this request hang and be forgotten for the moment,
                # until the work request completes and closes it for us.
                if work_request.request_id == request_token:
                    work_request.set_writing_socket(self)
                # Otherwise, there is a stale work request that we want to
                # override, so first close the existing work request
                # and then create a new one
                else:
                    user.end_current_work(callback=_on_work_cancelled)

            def _on_user_loaded(user):
                if not user:
                    self.emit("invalid-socket-request")
                    self.close()
                else:
                    user.get_current_work(callback=_on_current_work)

            if config.stress_test_run:
                self._timing = datetime.datetime.now()

            if config.stress_test_run:
                sess_id = kwargs.get('mplex_sess', None)
            else:
                sess_id = None

            # Note that we don't reset the user's gmail connection here
            # because it's possible that we don't want to interupt whats
            # currnetly being done, and that we want to shim our new
            # socket connection in place of the work currently going on
            drano.users.User.load(email, token, reset=False,
                                  identifier=sess_id,
                                  callback=_on_user_loaded)
        inner._event_name = event
        return inner
    return decorator


def load_user(require=False, reset=True, refresh=False):
    """A decorator that loads the current user's user object, if one exists,
    and otherwise sets the user argument to None

    Keyword Args:
        require -- Whether to redirect the user to the landing page
                   if we're not able to load a user for them
        reset   -- Whether to close any imap connections open for the user
                   before returning the user object
        refresh -- If True, we check to see if the Oauth token is still valid.
                   If it is not, push the user through the refresh oauth
                   flow before allowing them to land on the page
    """
    def decorator(func):
        def inner(self, *args, **kwargs):
            def _refresh_oauth(user):
                secs_left = user.sec_till_expiration()

                # If the current user's access token is in danger of expiring soon,
                # push them back through the oauth flow to get a fresh token and
                # then redirect them back to the currently requested URL
                if not secs_left or secs_left < config.oauth2_expiration_threshold:
                    msg = "token-refresh:{email}: Updating OAuth (was {num_sec} secs left)"
                    gen_log.debug(msg.format(email=user.email, num_sec=secs_left or -1))
                    self.oauth_flow()
                else:
                    func(self, user=user, *args, **kwargs)

            def _on_user_load(user):
                if config.stress_test_run and config.devel_oauth_credentials:
                    oauth = config.devel_oauth_credentials
                    if not user:
                        user_identifier = self.get_secure_cookie('mplex_sess', None)
                        sess_id = user_identifier or oauth['email']
                        user = drano.users.User('stress-test', True)
                        drano.users.User.COLLECTION[sess_id] = user
                    user.email = oauth['email']
                    user.trash_folder = '"[Gmail]/Trash"'
                    user.all_folder = '"[Gmail]/All Mail"'
                    user.access_token = oauth['access_token']
                    user.set_sec_till_expiration(oauth['expires_in'])

                if require and not user:
                    self.oauth_flow()
                elif refresh:
                    _refresh_oauth(user)
                else:
                    func(self, user=user, *args, **kwargs)

            token = self.get_secure_cookie('drano_user')
            email = self.get_secure_cookie('email')

            # If we're not able to load a user object from the values currently
            # stored in the requester's cookies though, redirect them home,
            # since it means something odd happened and the user hasn't
            # been through the oauth flow yet
            if (not token and not config.stress_test_run) and not email:
                if require:
                    self.oauth_flow()
                else:
                    func(self, user=None, *args, **kwargs)
            else:

                if config.stress_test_run:
                    sess_id = self.get_secure_cookie('mplex_sess', None)
                else:
                    sess_id = None

                drano.users.User.load(email, token, reset=reset,
                                      callback=_on_user_load,
                                      identifier=sess_id)
        return tornado.web.asynchronous(inner)
    return decorator


def validate_work_request(name=None, pos=1, socket=None):
    """A decorator used to validate the response to a async
    socket.io callback.  Functions / methods using this decorator must have
    at least one argument called req, (an instance of WorkRequest above),
    and are expected to have the returned value be the first *arg value.

    If there is something invalid in the request, the following steps will be
    taken:
        IMAP Error:
            - Log the message into the error log
            - send message over user's websocket informing them that there
              was an imap protocol error
            - delete user state relating to this work being performed (which
              also closes the websocket and the imap connectoin)
        IMAP Auth Error:
            - send message over user's websocket informing them of the imap
              auth error
            - delete user state relating to this work being performed (which
              also closes the websocket and the imap connectoin)
        IMAP Connection Closed:
            - Send a message over the user's websocket informing them that their
              connection closed, likely because of opening two windows at the
              same time.
            - close websocket
        Mutex Error (ie the mutex attached to this request is not the most
            recent mutex assigned to the user, indicating that they have
            started doing other work somewhere else)
            - log a debug level message
            - close imap connection
            - send socket io message informing user of problem
            - close this websocket connection

    Args:

    Keyword Args:
        name  --  A description of the work request being created.  If this
                  differs from the work descripion of the current user's work
                  request, then it will be treated as a "mutex non match" (ie
                  that the tested work is no longer valid)
        pos    -- The position of the argument in the returned args to validate
                  as a possible imap or auth error.  If None, no arguments will
                  be checked for error status
        socket -- The socket connection that is work is being performed on.
                  If this is None, we assume that its the first argument
                  passed into the decorated function (ie the self on a
                  SocketConnection instance)
    """
    def decorator(func):
        def inner(*args, **kwargs):
            work = kwargs['req']
            rs = args[pos] if pos is not None else None

            socket_connection = socket or args[0]

            # First, check to see if the response we got from the callback
            # is an imap error.  If so, inform the user, close everything down
            # and proceed no further
            if pos is not None and is_imap_error(rs):
                # First, log the message
                log_msg = "Received an imap error: {msg} (context: {context})"
                app_log.error(log_msg.format(msg=rs.msg, context=rs.context))

                # Then, send a response down over the websocket connection
                # infoming the user that there was an imap error
                if config.debug:
                    params = dict(message=rs.msg, context=str(rs.context))
                else:
                    params = dict()
                work.emit("imap-error", params)

                # Then, close down the imap connection.  Once that is done,
                # finish up by closing the imap connection
                work.user.end_current_work()

            # Next, check if this is an error dealing with IMAP authentication.
            # If it is, the first step is to send a socket.io message, informing the
            # user that something has gone wrong
            elif pos is not None and is_auth_error(rs):
                work.emit("auth-error")

                # Next, close down the imap connection for this request.
                # Once that is complete, finish by cleaning up user state
                # and not proceeding any further
                work.user.end_current_work()

            elif pos is not None and is_connection_closed_error(rs):
                work.emit("registered-work-changed")
                if socket_connection:
                    socket_connection.close()

            # Last, check to see if this work request should continue.
            elif work.work_desc != name:
                _log_mutex_error(work, name)
                work.user.end_current_work()

            # Otherwise, if everything still looks good at this point,
            # we can call the original, decorated function
            else:
                func(*args, **kwargs)
        return inner
    return decorator


def mailbox_check(key='all_folder', name=None):
    """Decorator to check to see if a mailbox exists in the user's account.
    Methods using this decorator are expected to have a keyword
    argument called `req` that is a WorkRequest instance.  Further, there first
    argument (that isn't self) is expected to be a mailbox instance.  If
    its not, the situation will be treated as an error.

    If the mailbox does not exist, the following steps are taken:
        - close imap connection
        - send message over user's websocket informing them that there was an
            imap protocol error
        - delete user state relating to this work being performed
        - close websocket

    Keyword Argument:
        key  -- the key on the user object (in the req keyword argument)
                that should be used to extract the name of the desired mailbox
        name -- An alternative to the above, where, instead of querying the
                user object for the name of the mailbox we're checking for,
                we have a hardcoded value
    """
    def decorator(func):
        def inner(self, *args, **kwargs):
            req = kwargs['req']
            mailbox = args[0]
            mailbox_name = name if name else getattr(req.user, key)

            # If the given mailbox object is a valid mailbox instance,
            # then we don't have to do anything, and we can just execute
            # the decorated function as expected
            if isinstance(mailbox, Mailbox):
                func(self, *args, **kwargs)
            # Otherwise, first close the imap connection
            else:
                if is_imap_error(mailbox):
                    app_log.error("Received IMAP '{error} error when looking for mailbox {mailbox}".format(error=mailbox.msg, mailbox=mailbox_name))
                elif is_auth_error(mailbox):
                    app_log.error("Received Auth '{error}' error when looking for mailbox {mailbox}".format(error=mailbox.msg, mailbox=mailbox_name))

                req.emit("mailbox-open-error", dict(mailbox_name=mailbox_name))
                req.user.end_current_work()
        return inner
    return decorator


def _log_mutex_error(work, name):
    """Try to keep the information we log about mutext errors as dry as
    possible, so capture it here even though it isn't useful outside this
    module"""

    # If the user doesn't have a mutex, it means that the current user
    # requested a stop to all work.  We can treat this as a mutex
    # conflict in all ways except for logging, which we shouldn't do
    # since this is an expected event
    if not work.work_desc:
        gen_log.debug("stop-request:{email}: Stop request received".format(email=work.user.email))
    else:
        log_msg = "check_work: Received 'mutex' error: Held '{work_desc}', expected '{exp_mtx}'"
        app_log.error(log_msg.format(email=work.user.email, work_desc=work.work_desc, exp_mtx=name))

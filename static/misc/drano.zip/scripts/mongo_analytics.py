#!/usr/bin/env python

"""This script provides a general entry point to perform analysis operations
against the current mongo datastore"""

import os
import imp
import pymongo
import sys

script_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.abspath(os.path.join(script_dir, os.pardir))
contrib_dir = os.path.join(root_dir, 'contrib')
sys.path.insert(0, os.path.join(contrib_dir, "imaplib2", "imaplib2"))
config = imp.load_source('config', os.path.join(root_dir, 'config.py'))
profiling = imp.load_source('config', os.path.join(root_dir, 'drano', 'profiling.py'))
Stats = profiling.Stats


m = config.mongo

connection = pymongo.MongoClient(m['host'], m['port'])
database = connection[m['dbname']]

if 'dbuser' in m:
    database.authenticate(m['dbuser'], m['dbpass'])


max_passwords = []
num_encrytions = []
docs = database.messages.find({"action": "encrypt"}).distinct('session')

count = 0
for doc in docs:
    count += 1
    rs = database.summaries.find({'session': doc}, {'num_passwords': 1})
    try:
        max_passwords.append(max([d['num_passwords'] for d in rs]))
        num_encrytions.append(database.messages.find({'session': doc, 'action': 'encrypt'}).count())
    except:
        pass

avg_pw = sum(max_passwords) / float(count)
avg_encrypt = sum(num_encrytions) / float(count)

print "Avg PW: {0}\nAvg Encrypts: {1}".format(avg_pw, avg_encrypt)
print "Search Time: {0}\nEncrypt Time: {1}".format(avg_pw / float(1902), avg_encrypt / float(3.6))




message_counts = []
passwd_counts = []
pass_ratios = []
encryption_ratios = []
redact_ratios = []
combined_ratios = []
combined_subset_count = []
combined_subset_ratio = []


for doc in database.summaries.find():

    num_messages = doc['messages']
    str_num_msg = str(num_messages)

    # There are some nonsense values in the collection, who knows why,
    # so filter them out if they look really silly
    if len(str_num_msg) % 2 == 0:
        part_1 = str_num_msg[:(len(str_num_msg)/2)]
        part_2 = str_num_msg[(len(str_num_msg)/2):]

        if part_1 == part_2:
            print " - looks bad (in 2)"
            print " - {0}".format(num_messages)
            continue

    if len(str_num_msg) % 3 == 0:
        part_1 = str_num_msg[:(len(str_num_msg)/3)]
        part_2 = str_num_msg[(len(str_num_msg)/3):(len(str_num_msg) * 2/3)]
        part_3 = str_num_msg[(len(str_num_msg)*2/3):]

        if part_1 == part_2 and part_2 == part_3:
            print " - looks bad (in 3s)"
            print " - {0}".format(num_messages)
            continue

    if num_messages >= 1000000:
        print " - num looks too big!"
        print " - {0}".format(num_messages)
        continue

    num_passes = doc['num_passwords']
    session = doc['session']
    num_encrypt = database.messages.find({"session": session, "action": "encrypt"}).count()
    num_redact = database.messages.find({"session": session, 'action': {'$in': ["remove", "redact"]}}).count()

    message_counts.append(num_messages)
    passwd_counts.append(num_passes)

    try:
        pass_ratios.append(num_passes / float(num_messages))
    except ZeroDivisionError:
        pass_ratios.append(0)

    if num_passes == 0:
        encryption_ratios.append(0)
        redact_ratios.append(0)
        combined_ratios.append(0)
    else:
        encryption_ratios.append(num_encrypt / float(num_passes))
        redact_ratios.append(num_redact / float(num_passes))
        combined_count = num_encrypt + num_redact
        combined_ratios.append(combined_count / float(num_passes))

        if combined_count:
            combined_subset_count.append(combined_count)
            combined_subset_ratio.append(combined_count / float(num_passes))


all_stats = [Stats(message_counts, "Number of messages in account"),
             Stats(passwd_counts, "Number of passwords in account"),
             Stats(pass_ratios, "Percent of passwords in messages"),
             Stats(encryption_ratios, "Percent of found passwords encrypted"),
             Stats(redact_ratios, "Percent of found passwords redacted"),
             Stats(combined_ratios, "Percent of found passwords redacted or encrypted"),
             Stats(combined_subset_count, "Number of passwords acted on (if >= 1)"),
             Stats(combined_subset_ratio, "Percent of passwords acted on (if >= 1)")]

for stat in all_stats:
    print stat

#!/bin/bash
# Simple re-launcher script, with takes a single argument, a number 1-8,
# which is used to determine which backend running on whihc 808<num>
# port to kill and restart

if [ $# -ge 1 ]
then
    PORT="808$1"
    PID=`ps -ef | grep python | grep $PORT | awk '{print $2}'`
    if [ -z "$PID" ]
    then
        echo "Unable to find drano backend running on port $PORT"
    else
        kill $PID
        CORE=$(($1 - 1))
        taskset -c $CORE python -O server.py $PORT &
        echo "Restarted backend for port $PORT"
    fi
else
    echo "To use this script, you must enter a number 1-8, specifying which backend to restart"
fi


import os
import imp
import sys
import re


init_times = []
auth_times = []
id_times = []
list_times = []
logout_times = []
close_times = []
select_times = []
search_times = []
fetch_uid_times = []
fetch_header_times = []
fetch_body_times = []
rewrite_times = []
safe_rewrite_times = []


state = {'prev_time': 0, 'cur_collection': None,
         'rewrite_stage': None, 'safe_time': 0, 'core_time': 0}


def add_time(request, time):

    if state['rewrite_stage']:
        state['core_time'] += time

        if state['rewrite_stage'] == 'safe' and 'UID COPY' in request:
            state['rewrite_stage'] = 'norm'
        elif state['rewrite_stage'] == 'norm' and 'UID COPY' in request:
            state['rewrite_stage'] = 'safe'

        if state['rewrite_stage'] == 'safe':
            state['safe_time'] += time

        if request == "EXPUNGE" and state['rewrite_stage'] == 'safe':
            safe_rewrite_times.append(state['safe_time'])
            rewrite_times.append(state['core_time'] - state['safe_time'])
            state['safe_time'] = 0
            state['core_time'] = 0
            state['rewrite_stage'] = None
        return

    is_command = False

    if request.find("DELETE") == 0:
        return
    if request == "CAPABILITY":
        init_times.append(time)
        is_command = True
    elif request == "AUTHENTICATE XOAUTH2":
        state['cur_collection'] = auth_times
        state['prev_time'] = time
    elif request.find("ID") == 0:
        id_times.append(time)
        is_command = True
    elif request.find('LIST') == 0:
        list_times.append(time)
        is_command = True
    elif request == 'LOGOUT':
        logout_times.append(time)
        is_command = True
    elif request.find('SEARCH') == 0:
        search_times.append(time)
        is_command = True
    elif request.find('SELECT') == 0:
        select_times.append(time)
        is_command = True
    elif request.find('FETCH') == 0:
        is_command = True
        fetch_uid_times.append(time)
    elif request.find('UID FETCH') == 0:
        if '(INTERNALDATE X-GM-MSGID X-GM-LABELS UID FLAGS BODYSTRUCTURE BODY.PEEK[HEADER] BODY.PEEK[1])' in request:
            fetch_header_times.append(time)
        elif '(INTERNALDATE X-GM-MSGID X-GM-LABELS UID FLAGS BODY.PEEK[])' in request:
            state['rewrite_stage'] = 'safe'
            state['core_time'] = time
    elif request == 'CLOSE':
        is_command = True
        close_times.append(time)
    else:
        state['prev_time'] += time

    if is_command and state['cur_collection'] is not None:
        state['cur_collection'].append(state['prev_time'])
        state['prev_time'] = 0
        state['cur_collection'] = None


IMAP_TAG_REMOVER = re.compile('^[A-Z]{4}\d+ ')


script_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.abspath(os.path.join(script_dir, os.pardir))
contrib_dir = os.path.join(root_dir, 'contrib')
sys.path.insert(0, os.path.join(contrib_dir, "imaplib2", "imaplib2"))
config = imp.load_source('config', os.path.join(root_dir, 'config.py'))
profiling = imp.load_source('config', os.path.join(root_dir, 'drano', 'profiling.py'))
Stats = profiling.Stats

netdump_path = config.netdump_path
timing_path = os.path.join(netdump_path, 'times')


def data(name):
    h = open(os.path.join(netdump_path, name), 'r')
    output = h.read()
    h.close()
    return output


def time(name):
    try:
        h = open(os.path.join(timing_path, name), 'r')
        output = h.read()
        h.close()
        return float(output)
    except IOError:
        return None


cur_request = None
cur_time = None

for root, dirs, files in os.walk(netdump_path):
    for a_file in sorted(files):
        if "request-imap" in a_file:
            request = data(a_file)
            request = IMAP_TAG_REMOVER.sub('', request.strip())
            cur_request = request
        elif "response-imap" in a_file:
            time_data = time(a_file)
            if time_data:
                cur_time = time_data

        if cur_time and cur_request:
            add_time(cur_request, cur_time)
            cur_request = None
            cur_time = None

init_stats = Stats(init_times, "CAPABILITY")
auth_stats = Stats(auth_times, "AUTHENTICATE and OAUTH")
id_stats = Stats(id_times, "ID")
list_stats = Stats(list_times, "LIST")
logout_stats = Stats(logout_times, "LOGOUT")
close_stats = Stats(close_times, "CLOSE")
select_stats = Stats(select_times, "SELECT a Mailbox")
search_stats = Stats(search_times, "SEARCH")
fetch_uid_stats = Stats(fetch_uid_times, "FETCHING UIDS")
fetch_header_stats = Stats(fetch_header_times, "FETCHING lite")
rewrite_stats = Stats(rewrite_times, "Rewriting (Core)")
safe_rewrite_stats = Stats(safe_rewrite_times, "Rewriting (safe)")

all_stats = [init_stats,
             auth_stats,
             id_stats,
             list_stats,
             logout_stats,
             close_stats,
             select_stats,
             search_stats,
             fetch_uid_stats,
             fetch_header_stats,
             rewrite_stats,
             safe_rewrite_stats]
for stat in all_stats:
    print stat

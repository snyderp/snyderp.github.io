#!/usr/bin/env python
# This script will archive all logs in the log dir that aren't currently being used
# (ie any log with a date at the end) and does the following with them:
#   * group the logs by date
#   * for each date of logs, creates a tar.gz archive
#   * AES256 CBC encrypts each archive
#   * pushes the logs to a remote server
#   * deletes the log
#
# Note that the parameters for each of the above are taken from the config.py file
# in the application root (config.backup_settings)

import sys
import tempfile
import os
import imp
import tarfile
from datetime import date

try:
    import pexpect
except ImportError:
    print "You need the pexpect library installed to run this script.  Try 'pip install pexpect'"
    sys.exit()

script_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.abspath(os.path.join(script_dir, os.pardir))
log_dir = os.path.abspath(os.path.join(root_dir, "logs"))
config = imp.load_source('config', os.path.join(root_dir, 'config.py'))
passwords = imp.load_source('passwords', os.path.join(root_dir, "drano", 'passwords.py'))
old_logs = [os.path.join(log_dir, f) for f in os.listdir(log_dir) if os.path.isfile(os.path.join(log_dir, f)) and f[-4:] != ".log"]

# Next, we group the old logs into bins, by day.
bup = config.backup_settings
scp_cmd = """scp -o "VerifyHostKeyDNS=no" -o "StrictHostKeyChecking=no" {source} {user}@{host}:{path}/{file}.tar.gz.enc"""
scp_args = dict(user=bup['sshuser'], host=bup['host'], path=bup['path'])

bins = {}
for log in old_logs:
    a_date = date.fromtimestamp(os.path.getmtime(log))
    as_str = a_date.strftime('%Y-%m-%d')
    if as_str not in bins:
        bins[as_str] = []
    bins[as_str].append(log)

for a_date in bins:
    f = tempfile.NamedTemporaryFile(delete=False)
    archive_name = f.name
    f.write('')
    f.close()
    tar = tarfile.open(f.name, "w:gz")
    for a_file in bins[a_date]:
        tar.add(os.path.relpath(a_file))
    tar.close()

    # First, encrypt the files we're looking to shove over to the other server
    child = pexpect.spawn('openssl aes-256-cbc -in {0} -out {1}.enc'.format(f.name, f.name))
    child.expect('password:')
    child.sendline(bup['encrypt_pass'])
    child.expect('password:')
    child.sendline(bup['encrypt_pass'])
    child.wait()
    child.close()

    # Next, shove them over using scp
    scp_args['source'] = archive_name + ".enc"
    scp_args['file'] = a_date
    child = pexpect.spawn(scp_cmd.format(**scp_args))
    child.expect('password')
    child.sendline(bup['sshpass'])
    child.wait()
    child.close()

    # Then, clean up the temp files we've created, and the orig logs
    os.unlink(archive_name)
    os.unlink(archive_name + ".enc")

    for a_file in bins[a_date]:
        os.unlink(a_file)

num_logs = sum([len(bins[a_date]) for a_date in bins])
num_archives = len(bins)

print "Archived {0} logs into {1} archives".format(num_logs, num_archives)

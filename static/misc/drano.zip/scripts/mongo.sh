#!/bin/bash
# Script to take the current mongo configuration out of the drano config
# file (config.py) and use it to create a connection to the mongo instance
# this drano install is running off of

if [ -e 'config.py' ]
then
    CONFIG_FILE='config.py'
else
    CONFIG_FILE='../config.py'
fi

MONGO_DB=`grep -Pow "(?<=dbname=').*?(?=')" $CONFIG_FILE`
MONGO_HOST=`grep -Pow "(?<=host=\W).*?(?=\"|')" $CONFIG_FILE`
MONGO_USER=`grep -Pow "(?<=dbuser=\W).*?(?=\"|')" $CONFIG_FILE`
MONGO_PW=`grep -Pow "(?<=dbpass=\W).*?(?=\"|')" $CONFIG_FILE`

mongo $MONGO_HOST/$MONGO_DB -u $MONGO_USER -p $MONGO_PW

#!/bin/bash

cd contrib
for i in "pybootstrap-forms" "pygmail" ; do
  cd $i
  git pull
  cd ../
done
cd ..

chown -R tornado:tornado .
chmod -R g+rw .

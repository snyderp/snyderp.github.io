"""Simple commandline script to extract the oauth token and IMAP
tag from a collection of netdump data.

Expects to be run with one argument, a path to netdump data"""

import re
import os
import sys

if len(sys.argv) < 2:
    print "Missing argument, path to netdump data"
    sys.exit()

oauth_token_pattern = re.compile('"access_token" : "(.*?)"', re.U)
imap_tag_pattern = re.compile(r'^([A-Z]{4})[0-9]{2}', re.U)

oauth_token = None
imap_tag = None
pre_imap_tags = []

def find_pattern_in_file(a_path, a_pattern):
    handle = open(a_path, 'r')
    for line in handle:
        matches = a_pattern.search(line)
        if matches:
            return matches.group(1)
    handle.close()
    return None

for root, dirs, files in os.walk(sys.argv[1]):
    for a_file in files:
        full_path = os.path.join(root, a_file)

        if "response-https" in full_path and not oauth_token:
            oauth_token = find_pattern_in_file(full_path, oauth_token_pattern)

        if "request-imap" in full_path and not imap_tag:
            a_imap_tag = find_pattern_in_file(full_path, imap_tag_pattern)
            if a_imap_tag not in pre_imap_tags:
                imap_tag = a_imap_tag

        if imap_tag and oauth_token:
            print " * Oauth Token: {token}".format(token=oauth_token)
            print " * IMAP Tag: {tag}".format(tag=imap_tag)
            pre_imap_tags.append(imap_tag)
            imap_tag = None

print "Couldn't find everything.  Here is what I've got"
print " * Oauth Token: {token}".format(token=oauth_token)
print " * IMAP Tag: {tag}".format(tag=imap_tag)

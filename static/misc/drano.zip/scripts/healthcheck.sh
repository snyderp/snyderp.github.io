#!/bin/bash
# Script to check to see if all backends are responding as expected.  If a
# backend doesn't respond within a second, we consider the backend as down /
# unhealth.
#
# Errors are printed out "Problem on backend #". Ohterwise, "All backends are
# healthy" is written to STDOUT


ALL_GOOD=1

for i in {1..8};
do

    PORT="808$i"
    RESPONSE=`wget -q -O- -T 1 http://localhost:808$i | wc -l`
    if [ "$RESPONSE" -eq "0" ]
    then
        ALL_GOOD=0
        echo "Problem on backend $i"
    fi
done

if [ "$ALL_GOOD" -eq 1 ]
then
    echo "All backends are healthy"
fi

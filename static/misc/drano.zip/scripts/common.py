"""Common code, used for initializing and handling common functionality
needed in analytic scripts and other command line tools for interacting
with drano and associated tools.
"""

import os
import imp
import sys
import pymongo

script_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.abspath(os.path.join(script_dir, os.pardir))
contrib_dir = os.path.join(root_dir, 'contrib')
sys.path.insert(0, os.path.join(contrib_dir, "imaplib2", "imaplib2"))
config = imp.load_source('config', os.path.join(root_dir, 'config.py'))

def mongo_database():
    m = config.mongo
    connection = pymongo.MongoClient(m['host'], m['port'])
    database = connection[m['dbname']]
    if 'dbuser' in m:
        database.authenticate(m['dbuser'], m['dbpass'])
    return database

def stats_class():
    profiling = imp.load_source('config', os.path.join(root_dir, 'drano', 'profiling.py'))
    return profiling.Stats

#!/usr/bin/env python
"""
Provides high level statistics about the account audit functionality of the site
"""

from common import mongo_database, stats_class

db = mongo_database()

Stats = stats_class()

pricing_rules_categories = {}
account_prices = []
for row in db.pricing_rules.find():
    if "prices" not in row:
        continue
    account_prices.append(max([i['price'] for i in row["prices"]]))
    severity = row['severity']
    try:
        pricing_rules_categories[severity] += 1
    except KeyError:
        pricing_rules_categories[severity] = 1


usage_counts = []
for row in db.audit.find():
    usage_counts.append(row['price'])

all_stats = [
    Stats(account_prices, "Account Prices"),
    Stats(usage_counts, "Usage Counts")
]

print "Pricing Rules by Severity"
print "==="
for severity_type, count in pricing_rules_categories.items():
    print " * {}: {}".format(severity_type, count)

print ""
for stat in all_stats:
    print stat

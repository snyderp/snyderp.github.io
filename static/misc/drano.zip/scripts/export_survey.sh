#!/bin/bash
# Script that exports all results from a survey to a CSV file.  Takes
# a single argument, the survey versions number, and prints out
# a CSV export to STDOUT

if [ $# -ge 1 ];
then
    VERSION_NUM=$1
else
    echo "Error. Must include survey version to export. [1, 2]"
    exit
fi

if [ -e 'config.py' ]
then
    CONFIG_FILE='config.py'
else
    CONFIG_FILE='../config.py'
fi

MONGO_DB=`grep -Pow "(?<=dbname=').*?(?=')" $CONFIG_FILE`
MONGO_HOST=`grep -Pow "(?<=host=\W).*?(?=\"|')" $CONFIG_FILE`
MONGO_USER=`grep -Pow "(?<=dbuser=\W).*?(?=\"|')" $CONFIG_FILE`
MONGO_PW=`grep -Pow "(?<=dbpass=\W).*?(?=\"|')" $CONFIG_FILE`

if [[ $VERSION_NUM == "1" ]];
then
    MONGO_QUERY="{'version': {'\$exists': false}}"
    FIELDS="gender,age,household_income,marital_status,education_mother,education_father,had_unknown_passwords,found_sensitive_info,redacted_info_from_humans,emailing_services,other_info_to_redact,interest_other_services,interest_cloud_storage,interest_find_replace,interest_encrypt_old,interest_personal_info,interest_attachments,interest_recurring_search,interest_privacy_alerts,interest_speedup,receive_updates,receive_email"
else
    MONGO_QUERY="{'version': 2}"
    FIELDS="gender,age,income,education,privacy_concerns,usability,own_identify_theft,other_identity_theft,business_idenitity_theft,privacy_breach,future_surveys,receive_updates,receive_email"
fi

mongoexport --host $MONGO_HOST --port 27017 --username $MONGO_USER \
    --password $MONGO_PW  --collection survey_results --csv --db $MONGO_DB \
    --query "$MONGO_QUERY" --fields $FIELDS

from common import stats_class
import math

Stats = stats_class()

search_times = [167, 141, 157, 152, 137, 133, 170, 162, 137, 144]
search_imap_times = [67.1, 65.7, 66.4, 65.9, 65.4, 63.7, 76.5, 63.0, 64.7, 63.1]
search_core_times = [math.floor(search_times[i] - search_imap_times[i]) for i in range(len(search_times))]

encrypt_times = [844, 796, 741, 780, 759, 768, 796, 774, 783, 798]
encrypt_imap_times = [838.8, 790.6, 735.7, 773.9, 753.6, 762.4, 790.7, 767.5, 778.3, 791.3]
encrypt_core_times = [math.floor(encrypt_times[i] - encrypt_imap_times[i]) for i in range(len(encrypt_times))]

decrypt_times =      [432, 417, 405, 401, 397, 410, 412, 409, 423, 424]
decrypt_imap_times = [430.4, 413.4, 402.3, 398.5, 395.6, 409.3, 412.0, 409.4, 419.6, 421.6]
decrypt_core_times = [decrypt_times[i] - math.floor(decrypt_imap_times[i]) for i in range(len(decrypt_times))]

all_stats = [
    Stats(search_times, "Search Times"),
    Stats(search_imap_times, "Search IMAP Times"),
    Stats(search_core_times, "Search Core Times"),
    Stats(encrypt_times, "Encrypt Times"),
    Stats(encrypt_imap_times, "Encrypt IMAP Times"),
    Stats(encrypt_core_times, "Encrypt Core Times"),
    Stats(decrypt_times, 'Decrypt Times'),
    Stats(decrypt_imap_times, 'Decrypt IMAP Times'),
    Stats(decrypt_core_times, 'Decrypt Core Times'),
]

for stat in all_stats:
    print stat

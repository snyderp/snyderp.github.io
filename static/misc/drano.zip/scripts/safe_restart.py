#!/usr/bin/env python
#
# Generates a table describing what users are doing on each backend.
# Note that this script requires that the "requests" library be installed from
# pip
#
# The resulting output is a four column table, in the following format:
# email     action      start time      backend/port

import time
import os
import copy
import sys

try:
    import requests
except ImportError:
    print "Unable to load Requests library"
    print "Perhaps `pip install requests`?"
    import sys
    sys.exit()


def check_backends(port):
    url = "http://localhost:{port}/status.json".format(port=port)
    r = requests.get(url)
    return r.json()

probe = len(sys.argv) > 1 and sys.argv[1] == "probe"
backends_to_restart = list(range(8081, 8089))
scripts_dir = os.path.dirname(__file__)
wait_time = 5
row_format = "{:<30}" * 3

while len(backends_to_restart) > 0:
    print "Trying to restart backends: %s" % (backends_to_restart,)
    test_backends = copy.copy(backends_to_restart)
    for backend in test_backends:
        reports = check_backends(backend)
        num_reports = len(reports)
        for report in reports:
            print row_format.format(report['current_work'], report['current_work_start'], report['backend'])

        if num_reports == 0:
            backends_to_restart.remove(backend)
            if probe:
                print " - Would have restarted {port}".format(port=backend)
            else:
                os.system("bash " + os.path.join(scripts_dir, "restart.sh {port}".format(port=backend-8080)))
                print " - Successfully restarted {port}".format(port=backend)
        else:
            print " - Still {num_users} user(s) working on {port}.  Waiting {wait} seconds".format(num_users=num_reports, port=backend, wait=wait_time)
    if len(backends_to_restart) > 0:
        time.sleep(wait_time)

print "Successfully restarted all backends"

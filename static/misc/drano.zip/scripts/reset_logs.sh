#!/bin/bash

for FILE in `find logs/ -type f`
do
    cat /dev/null > $FILE
done

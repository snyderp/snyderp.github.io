import datetime
import os
import imp
import pymongo
import sys
from pytz import timezone
import pytz
from dateutil import parser

script_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.abspath(os.path.join(script_dir, os.pardir))
contrib_dir = os.path.join(root_dir, 'contrib')
sys.path.insert(0, os.path.join(contrib_dir, "imaplib2", "imaplib2"))
config = imp.load_source('config', os.path.join(root_dir, 'config.py'))
m = config.mongo

connection = pymongo.MongoClient(m['host'], m['port'])
db = connection[m['dbname']]

if 'dbuser' in m:
    db.authenticate(m['dbuser'], m['dbpass'])

date_lines = [
    ('clark-mccoy-1', '2014-4-14 11:24 AM', '2014-04-14 10:49 AM', 'a4a2e9b2-d9ef-40d9-a248-7fbb9e27e8e2', 6252, 27),
    ('clark-mccoy-2', '2014-4-14 1:58 PM', '2014-04-14 01:38 PM', 'f612fc38-504d-4d1f-88b2-b040a5cc90da', 4511, 36),
    ('clark-mccoy-3', '2014-4-18 12:16 PM', '2014-04-18 11:59 AM', '0d8482a3-b58e-45b9-ae85-58cb3549c385', 11441, 29),
    ('clark-mccoy-4', '2014-4-18 1:56 PM', '2014-04-18 01:42 PM', '5068359f-0f57-406c-b593-b4f7c3c3fa84', 2323, 6),
    ('clark-mccoy-6', '2014-4-25 2:30 PM', '2014-04-25 02:24 PM', '0bb5e812-4820-4aad-956e-8e9c28967b9a', 7531, 4),
    ('clark-mccoy-8', '2014-4-25 4:37 PM', '2014-04-25 04:02 PM', 'd8755ecd-40e2-4796-b475-9d4321161649', 3998, 8),
    ('clark-mccoy-10', '2014-4-28 7:02 PM', '2014-04-28 06:14 PM', '4044d845-dd66-4ee3-ac83-41ae137738a1', 19546, 315),
    ('clark-mccoy-11', '2014-4-30 5:07 PM', '2014-04-30 04:44 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 3601, 17),
    ('clark-mccoy-12', '2014-5-2 1:01 PM', '2014-05-02 12:37 PM', '93686ba3-741b-46f6-ba7b-490cbc24efb7', 25350, 52),
    ('clark-mcoy-13', '2014-5-2 2:22 PM', '2014-05-02 01:31 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 22501, 50),
    ('clark-mccoy-14', '2014-5-3 2:37 PM', '2014-05-03 02:25 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 40429, 13),
    ('clark-mccoy-15', '2014-5-27 3:10 PM', '2014-05-27 02:51 PM', 'ce0255d8-9242-438b-bfdc-5a9b693e5643', 2740, 3),
    ('clark-mccoy-16', '2014-5-30 12:10 PM', '2014-05-30 11:37 AM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 18666, 94),
    ('clark-mccoy-17', '2014-5-30 1:34 PM', '2014-05-30 01:10 PM', 'bc398c21-b3ce-4974-8f5c-9f5e8086a7a4', 17787, 58),
    ('clark-mccoy-18', '2014-5-30 2:33 PM', '2014-05-30 01:54 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 24869, 69),
    ('clark-mccoy-19', '2014-5-30 3:46 PM', '2014-05-30 03:13 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 24190, 34),
    ('clark-mccoy-20', '2014-5-30 4:21 PM', '2014-05-30 04:08 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 5326, 29),
    ('clark-mccoy-21', '2014-6-2 11:40 AM', '2014-06-02 11:10 AM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 10578, 23),
    ('clark-mccoy-22', '2014-6-2 1:22 PM', '2014-06-02 12:39 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 424744, 125),
    ('clark-mccoy-23', '2014-6-3 2:45 PM', '2014-06-03 02:30 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 737, 0),
    ('clark-mccoy-24', '2014-6-3 3:51 PM', '2014-06-03 03:27 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 1501, 4),
    ('clark-mccoy-25', '2014-6-3 5:43 PM', '2014-06-03 04:47 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 23604, 152),
    ('clark-mccoy-26', '2014-6-6 11:27 AM', '2014-06-06 11:07 AM', '04dd4d97-ec57-4835-86a6-18eb7782b4de', 46632, 188),
    ('clark-mccoy-27', '2014-6-6 12:17 PM', '2014-06-06 12:04 PM', 'b3f10391-a530-42d6-977d-b8981bc398c2', 11625, 272),
    ('clark-mccoy-30', '2014-6-6 3:53 PM', '2014-06-06 03:35 PM', 'ed4804dd-4d97-4ec5-b835-86a618eb7782', 46235, 181),
    ('clark-mccoy-31', '2014-6-13 1:18 PM', '2014-06-13 01:00 PM', 'ec578358-6a61-48eb-b782-b4de5e32a73d', 423, 0),
    ('clark-mccoy-32', '2014-6-16 11:50 AM', '2014-06-16 11:35 AM', '10bb9caa-83d6-421d-a650-2c6bf117681c', 16823, 246),
]

lines = []
lines.append(",".join(["label", "given date", 'audit price', "matched date",
                        'session', '# messages', '# passes', '# redact', '# encrypy']))

tz = timezone('US/Eastern')
for vals in date_lines:
    jason_label = vals[0]
    jason_date = vals[1]
    date = tz.localize(parser.parse(jason_date))

    min_date = date - datetime.timedelta(hours=1)
    max_date = date + datetime.timedelta(minutes=5)
    date_query = {
        "created_on": {
            "$gt": min_date,
            "$lt": max_date
        }
    }
    rows = db.summaries.find(date_query).sort("created_on", -1)
    audit_row = db.audit.find_one({"participant_tag": jason_label})
    if not audit_row:
        print "No match for label: {}".format(jason_label)
        continue
    audit_price = audit_row[u'price']

    most_recent_row = None
    min_time_dif = None
    base_row = [
        jason_label,
        jason_date,
        str(audit_price)
    ]

    closest_row = None
    for row in rows:

        row_time = pytz.utc.localize(row[u'created_on'])
        session = row[u'session']
        num_redact = db.messages.find({'session': session, 'action': "redact"}).count()
        num_encrypt = db.messages.find({'session': session, 'action': "encrypt"}).count()
        if min_time_dif and abs(date - row_time) > min_time_dif:
            continue
        min_time_dif = abs(date - row_time)
        num_passwords = row[u'num_passwords']
        num_messages = row[u'messages']
        matched_date = (row_time - datetime.timedelta(hours=4)).strftime("%Y-%m-%d %I:%M %p")

        closest_row = base_row + [
            matched_date,
            session,
            str(num_messages),
            str(num_passwords),
            str(num_redact),
            str(num_encrypt)
        ]

    lines.append(",".join(closest_row or base_row))

print "\n".join(lines)

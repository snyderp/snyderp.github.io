#!/usr/bin/env python

"""Provides high level overview of the surveys that have been submitted"""

import os
import imp
import sys
import pymongo
import argparse
from collections import OrderedDict

script_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.abspath(os.path.join(script_dir, os.pardir))
contrib_dir = os.path.join(root_dir, 'contrib')
sys.path.insert(0, os.path.join(contrib_dir, "imaplib2", "imaplib2"))
sys.path.insert(0, os.path.join(contrib_dir, "pybootstrap-forms"))
config = imp.load_source('config', os.path.join(root_dir, 'config.py'))
forms = imp.load_source('forms', os.path.join(root_dir, 'drano', 'forms.py'))

import pybootstrap_forms.inputs

m = config.mongo

parser = argparse.ArgumentParser(description='Build graphs and analytics from submitted survey data.')
parser.add_argument('--version', help='Which version of the survey to build analytics for.', type=int, default=2, choices=(1, 2))
args = parser.parse_args()

connection = pymongo.MongoClient(m['host'], m['port'])
db = connection[m['dbname']]

if 'dbuser' in m:
    db.authenticate(m['dbuser'], m['dbpass'])

if args.version == 2:
    results = db.survey_results.find(dict(version=2))
else:
    query = {"version": {"$exists": False}}
    results = db.survey_results.find(query)

form = forms.survey_form(args.version)

mapping = {}
enum_fields = OrderedDict()

for field in form.fields:
    if isinstance(field, pybootstrap_forms.inputs.Multiple):
        mapping[field.name] = field.label
        enum_fields[field.label] = OrderedDict([(k, 0) for k, v in field.value_pairs])

for doc in results:
    for field_name, field_value in doc.items():
        if field_name in mapping:
            try:
                enum_fields[mapping[field_name]][field_value] += 1
            except KeyError:
                pass

for a_field_label, field_values in enum_fields.items():
    print a_field_label
    print "-----------"
    for value_name, value_value in field_values.items():
        print " - {field:40}: {count:>6}".format(field=value_name, count=value_value)
    print ""

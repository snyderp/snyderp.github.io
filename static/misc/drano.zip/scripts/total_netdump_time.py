import os
import imp


script_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.abspath(os.path.join(script_dir, os.pardir))
config = imp.load_source('config', os.path.join(root_dir, 'config.py'))
netdump_path = config.netdump_path
timing_path = os.path.join(netdump_path, 'times')
total_time = []


def data(name):
    h = open(os.path.join(netdump_path, name), 'r')
    output = h.read()
    h.close()
    return output


def time(name):
    try:
        h = open(os.path.join(timing_path, name), 'r')
        output = h.read()
        h.close()
        return float(output)
    except IOError:
        return None


for root, dirs, files in os.walk(timing_path):
    for a_file in sorted(files):
        if "imap" in a_file:
            taken_time = time(a_file)
            if taken_time:
                total_time.append(taken_time)

print sum(total_time)

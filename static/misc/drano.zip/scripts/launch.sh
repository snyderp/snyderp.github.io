#!/bin/bash
# Launching script for drano, which takes one optional command, the number
# of backend processes to start up.
#
# Launching drano consists of the following steps:
#   * Killing any existing drano instances / python processes
#   * Rebuilding the sass -> css file
#   * Removing any aggregatted css and js assets
#   * Launching a new drano process, each pegged to a different core

if [ $# -ge 1 ]
then
    NUM_PROCESSES=$1
else
    NUM_PROCESSES=8
fi

START_PORT=8081
NUM_CORES="`nproc`"

pyscss static/css/drano.scss > static/css/drano.min.css
rm -f static/css/aggregate/*.css
rm -f static/js/aggregate/*.js
find . -name "*.pyo" -exec rm {} \;
find . -name "*.pyo" -exec rm {} \;

killall python
for i in $(seq $START_PORT 1 $(($START_PORT + $NUM_PROCESSES - 1)));
do
    SEL_CORE="$(($i % $NUM_CORES))"
    taskset -c $SEL_CORE python -O server.py $i &
done;

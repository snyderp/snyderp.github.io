import os
import imp
import pymongo
import sys

script_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.abspath(os.path.join(script_dir, os.pardir))
contrib_dir = os.path.join(root_dir, 'contrib')
sys.path.insert(0, os.path.join(contrib_dir, "imaplib2", "imaplib2"))
config = imp.load_source('config', os.path.join(root_dir, 'config.py'))
m = config.mongo

connection = pymongo.MongoClient(m['host'], m['port'])
db = connection[m['dbname']]

if 'dbuser' in m:
    db.authenticate(m['dbuser'], m['dbpass'])

sessions = set()
num_messages = 0
num_passwords = 0
amount_mappings = {
    7159571595: 71595,
    6713467134: 67134,
    1855418554: 18554,
    1883218832: 18832,
    110999110999: 110999,
    857048570485704: 85704,
    8722487224: 87224,
    589095891058910: 58910,
    8571985719: 85719,
    2309823098: 23098,
    3583335833: 35833,
    4082840828: 40828,
    3658636586: 36586,
    7444874448: 744487,
    223099223099: 223099,
    157967157967: 157967,
    7099370993: 70993,
    204722047120471: 20471,
    6434964349: 64349,
    100886100887100887: 100887,
    151911519215192: 15192,
    54535453: 5453,
    378399378400378400: 378400,
    35673567: 3567,
    3347533475: 33475,
    434684346943469: 43469,
    8909989099: 89099,
    2419024190: 24190,
    4247442474: 42474,
    881478814788147: 88147,
}

for row in db.summaries.find():
    sessions.add(row['session'])
    if row['messages'] in amount_mappings:
        num_messages += amount_mappings[row['messages']]
    else:
        num_messages += row['messages']
    num_passwords += row['num_passwords']

num_redacted = db.messages.find({'action': {'$in': ['redact', 'remove']}}).count()
num_encrypted = db.messages.find({'action': 'encrypt'}).count()
num_sessions = len(sessions)

print """
# Sessions: {}
# Messages: {}
# Passwords: {}
# Encryptions: {}
# Redactions: {}
""".format(num_sessions, num_messages, num_passwords, num_encrypted, num_redacted)

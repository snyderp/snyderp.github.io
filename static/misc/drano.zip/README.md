drano
=====

Description
---
Tornado app for running Drano

Requires
---
 * Python &gt;= 2.6
 * [Tornado](http://www.tornadoweb.org/)
 * [Tornadio2](https://github.com/mrjoes/tornadio2)
 * [Google's OAuth2 Client](http://code.google.com/p/google-api-python-client/downloads/list)
 * [httplib2](http://code.google.com/p/httplib2/)
 * [pycrypto](https://www.dlitz.net/software/pycrypto/) for password encryption
 * [asyncmongo](https://github.com/bitly/asyncmongo)

Included Submodules
---
 * [pygmail](https://github.com/snyderp/pygmail)
 * [pybootstrap-forms](https://github.com/snyderp/pybootstrap-forms)
 * [pywebassets](https://github.com/snyderp/pywebassets)

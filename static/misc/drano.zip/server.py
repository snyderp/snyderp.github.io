import sys
import os
import config

[sys.path.insert(0, path) for path in config.paths]

import tornado.ioloop
import drano.controllers as controllers
import drano.websockets
import tornadio2
import tornadio2.server
import drano.debugging
import pygmail.patching


settings = {
    "static_path": os.path.join(os.path.dirname(__file__), "static"),
    "template_path": os.path.join(os.path.dirname(__file__), "views"),
    "socket_io_port": config.socket_io_port,
    "xsrf_cookies": True,
    "cookie_secret": config.cookie_secret,
    "debug": config.debug,
    "log_function": drano.debugging.drano_log,
    "client_timeout": 45,
    "session_expiry": 60
}

routes = [
    # Basic flow for app starts with the landing page, where we
    # give a brief description of whats happening and going on
    (r"/", controllers.Landing),
    # Controller for serving up static pages
    (r"/({0})".format("|".join(controllers.Static.PAGES.keys())), controllers.Static),
    # Consent page, for users opting into analytics tracking
    (r"/consent", controllers.Consent),
    # Page only used for handling the Drano end of oauth authentication.
    # Visitors never see this page
    (r"/oauth2", controllers.Authorize),
    # Page to allow users to deauthenticate completely with Drano
    (r"/logout", controllers.Logout),

    # Landing page for searching the user's gmail account for passwords.
    # This returns a static landing page, which then does the actual searching
    # over netsocket callbacks
    (r"/search/work", controllers.Encrypt),
    # Page displaying the results of the search for passwords to encrypt
    (r"/search/results", controllers.EncryptResults),
    # Page with summary, wrapping up results and an exit quiz
    (r"/search/complete", controllers.Complete),

    # Landing page for the decrypt flow.
    (r"/decrypt", controllers.Decrypt),
    # Landing page for when decryption has completed
    (r"/decrypt/complete", controllers.DecryptComplete),

    # Landing page for websockets for "pricing" the user's mailbox / account
    (r"/audit/work", controllers.AuditWork),

    # Simple JSON service that will return a json description of what
    # users are logged into the site and what they're doing
    (r"/status.json", controllers.Status),

    # Web facing frontend to allow users to manipulate their own session
    # information, to try and trigger errors
    (r"/alter/(expire-oauth|set-transport)", controllers.Alter),

    # Landing page for assigning tracking information to a users in 3rd
    # party studies
    (r"/study/(.*?)/(.*?)", controllers.StudyLanding)
]

if config.debug:
    # Populates an inbox with a series of test messages from the
    # /test_messages directory
    routes.append((r"/fill", controllers.Fill))
    routes.append((r"/touch", controllers.Touch))

SocketRouter = tornadio2.router.TornadioRouter(drano.websockets.SocketIOServer)
routes.extend(SocketRouter.urls)
application = tornado.web.Application(routes, **settings)

if __name__ == "__main__":

    if config.profiler == "plop":
        import drano.profiling
        drano.profiling.plop_profiling(tornado.ioloop.IOLoop,
                                       config.profile_time)

    # If we set, in the config file, SSL options, tell the HTTP server
    # to only accept connections using the given ssl configuration
    if config.ssl_options:
        http_server = tornado.httpserver.HTTPServer(
            application, ssl_options=config.ssl_options)
    else:
        http_server = tornado.httpserver.HTTPServer(application)

    if config.profiler == "heapy":
        # If we're memory profiling, we only want to do so after we've
        # allocated the main tornado objects, to keep some of the noise
        # out of the logs
        import drano.profiling
        drano.profiling.heapy_profiling(tornado.ioloop.IOLoop,
                                        config.profile_time)

    http_server.listen(config.port)

    # If we set in the config file a user to drop down to after launching,
    # drop down here
    if config.tornado_user:
        import pwd
        uid = pwd.getpwnam(config.tornado_user)[2]
        os.setuid(uid)

    if config.log_dir:
        drano.debugging.configure_logger()

    tornadio2.server.SocketServer(application)

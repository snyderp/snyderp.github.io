$(function () {

    // Convenience library that will check to see if we're in a browser that
    // supports all the functionality we need to use qrcodes.
    drano.qrcodes = (function () {

        // By default, we assume that the browser cannot show any qr code
        // functionality.  We then test from there to see what is available.
        var create_qrcodes = false,
            read_qrcodes = false,
            is_canvas_supported = false,
            test_canvas,
            $body = $("body");

        test_canvas = document.createElement('canvas');
        is_canvas_supported = !!(test_canvas.getContext && test_canvas.getContext('2d'));

        create_qrcodes = is_canvas_supported;
        read_qrcodes = is_canvas_supported && navigator && (navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia);

        $body
            .addClass(create_qrcodes ? "create-qrcodes-supported" : "create-qrcodes-unsupported")
            .addClass(read_qrcodes ? "read-qrcodes-supported" : "read-qrcodes-unsupported");

        // Next, if we're in a browser that supports qrcodes, strip out the fallbacks,
        // and likewise, remove the features if we're in a browser that doesn't
        // support qr codes
        $body
            .find(create_qrcodes ? ".qrcodes-create-fallback" : ".qrcodes-create-feature")
            .remove();
        $body
            .find(read_qrcodes ? ".qrcodes-read-fallback" : ".qrcodes-read-feature")
            .remove();

        return {
            supportsReadingQrCodes: function () {
                return read_qrcodes;
            },
            supportsCreatingQrCodes: function () {
                return create_qrcodes;
            }
        };
    }());
});

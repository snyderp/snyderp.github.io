$(function () {

    var $rows = $("tbody tr td:first"),
        $ajax_forms = $(".ajax-submit"),
        $receive_email = $("#receive_email").val(drano.current_email),
        $receive_email_container = $receive_email.closest(".control-group").hide();

    $(".btn-print").click(function () {
        window.print();
        return false;
    });

    $('#receive_updates').on('change', function (e) {
        if (this.checked) {
            $receive_email_container.show(150);
        } else {
            $receive_email_container.hide(150);
        }
    });

    $rows.click(function (event) {

        var $this = $(this),
            $checkbox = $this.find("input[type='checkbox']:first");

        if (event.target.type !== 'checkbox') {
            $checkbox.trigger('click');
        }
    });

    $ajax_forms.find("button[type='submit']").on("click", function () {
        $form = $(this).closest("form");
        $.post(
            $form.attr("action"),
            $form.serialize(),
            function (data) {

                var error_values = "",
                    $error_alert;

                if (data.errors) {

                    error_values += "<ul>";
                    $.each(data.errors, function (indexInArray, valueOfElement) {
                        error_values += "<li>" + valueOfElement + "</li>";
                    });
                    error_values += "</ul>";

                    $error_alert = $("<div class='alert alert-error'>" + error_values + "</div>");
                    $form.before($error_alert);

                    setTimeout(function () {
                        $error_alert.fadeOut(function () {
                            $(this).remove();
                        });
                    }, 5000);

                } else {

                    $form.fadeOut(function () {
                        $(this)
                            .replaceWith("<div class='alert alert-info'>Thank you very much for taking our survey!</div>")
                            .fadeIn();
                    });
                }
            },
            "json"
        );

        return false;
    });
});

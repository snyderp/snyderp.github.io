jQuery(function ($) {

    drano.socket = (function () {

        var protocol = window.location.protocol,
            host = window.location.host,
            d = window.drano,
            s = d.settings,
            utils = d.utils,
            modal = d.modal,
            debug = d.debug,
            prog = d.progress,
            request_token = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                var r = Math.random()*16|0,
                    v = c == 'x' ? r : (r&0x3|0x8);
                return v.toString(16);
            }),
            default_disconnect_callback = function () {

                if (modal) {
                    modal
                        .setBody("<p>An error occured when trying to maintain a connection with Cloudsweeper, and your browser is not able to reconnect. This could be due to a network issue between your computer and Cloudsweeper, or an error in Cloudsweeper itself.</p><p>Unfortunatly we are not able to proceed any further.  To continue please click below and restart your request.</p>")
                        .setTitle("Connection Error")
                        .footer()
                            .append('<a href="/logout" class="btn btn-warning">Return Home</a>');
                }
            },
            disconnect_callback = null,
            transports = ['websocket', 'htmlfile', 'xhr-polling', 'jsonp-polling'],
            transport_pattern = /drano_transport=(.*?)(:?;|\||$)/,
            selected_transport = (function () {
                var match = document.cookie.match(transport_pattern);
                return match ? [match[0]] : null;
            }()),
            stored_events = {}, // If a user wants to associate events with
                                // the socket.io connection before we start the
                                // socket session, store the events here and
                                // then apply them at init()
            establish_connection = function () {

                if (debug) {
                    debug.log("Attempting to establish socket connection");
                }

                var connect_params = {
                    "transports": selected_transport || transports,
                    "sync disconnect on unload": false,
                    "query": ["token=" + s.token,
                              "request_token=" + request_token,
                              "email=" + encodeURIComponent(s.email)].join("&"),
                    'connect timeout': 40000,
                    'max reconnection attempts': 4,
                    'reconnection delay': 1000
                };

                return new io.connect(protocol + "//" + host, connect_params);
            },
            connection = null,
            session_params = {},
            $ = window.jQuery,
            reconnect_failed_error = function (event_name) {

                if (debug) {
                    console.log(event_name);
                }

                return function (obj) {

                    if (debug && obj) {
                        console.log(obj);
                    }

                    drano.socket.unbindLeavePageWarning();

                    if (modal) {
                        modal
                            .setBody("<p>An error occured when trying to maintain a connection with Cloudsweeper, and your browser is not able to reconnect. This could be due to a network issue between your computer and Cloudsweeper, or an error in Cloudsweeper itself.</p><p>Unfortunatly we are not able to proceed any further.  To continue please click below and restart your request.</p>")
                            .setTitle("Connection Error")
                            .footer()
                                .append('<a href="/logout" class="btn btn-warning">Return Home</a>');
                    }
                };
            },
            debug_event = function (connection, event_name) {
                connection.on(event_name, function (obj) {
                    console.log(event_name);
                    console.log(obj);
                });
            };


        if (s.token) {
            session_params['token'] = s.token;
            session_params['request_token'] = request_token;
            session_params['email'] = s.email;

            if (s.mplex_sess) {
                session_params['mplex_sess'] = s.mplex_sess;
            }
        }

        return {
            setDefaultDisconnectCallback: function () {
                disconnect_callback = default_disconnect_callback;
                return this;
            },
            setDisconnectCallback: function (func) {
                disconnect_callback = func;
                return this;
            },
            setWorkComplete: function () {
                drano.socket
                    .setDisconnectCallback(null)
                    .unbindLeavePageWarning();
                return this;
            },
            bindLeavePageWarning: function (msg) {
                msg = msg || d.site_name  + " is still making changes to your account. If you leave the page before this operation is complete, you may have un-recoverable changes";

                $(window).bind('beforeunload', function() {
                    return msg;
                });

                return this;
            },
            unbindLeavePageWarning: function () {
                $(window).unbind('beforeunload');
                $(window).unbind('unload');
                return this;
            },
            closeConnection: function () {
                // To close the connection, we first have to cancel the
                // request token to something that won't match the current
                // request's token (the one we're cancelling), so that the
                // server doesn't think that we're trying to reconnect to
                // an existing process
                drano.socket
                    .addParam("request_token", 'cancel')
                    .emit("close-connection-client-initiated")
                    .disconnect();
                return this;
            },
            disconnect: function () {
                connection.disconnect();
                return this;
            },
            setEvents: function (params) {
                var key;

                if (connection) {
                    for (key in params) {
                        connection.on(key, params[key]);
                    }
                } else {
                    stored_events = $.extend(stored_events, params);
                }
                return this;
            },
            addParam: function (key, value) {
                session_params[key] = value;
                return this;
            },
            resetParams: function () {
                session_params = {
                    'token': s.token
                };
                return this;
            },
            emit: function (event, additional_params) {

                var emit_params;

                if (additional_params) {
                    emit_params = $.extend(session_params, additional_params);
                } else {
                    emit_params = session_params;
                }

                connection.emit(event, emit_params);
                return this;
            },
            connection: function () {
                return connection;
            },
            init: function () {

                if (connection) {
                    return this;
                }

                connection = establish_connection();

                // If the user is browsing away from the current page, make sure
                // that we close the current websocket
                $(window).bind("unload", function () {
                    var raw_socket = drano.socket.connection().socket;
                    if (raw_socket.connected || raw_socket.reconnecting) {
                        drano.socket.closeConnection();
                    }
                });

                connection.on("disconnect", function () {

                    if (debug) {
                        debug.log("Received disconnect for websocket");
                    }

                    if (disconnect_callback) {
                        disconnect_callback();
                    }
                });

                connection.on("imap-error", function (msg) {

                    var error_message;

                    if (debug) {
                        error_message = debug.debugMessage("<div>" + debug.objToDl(msg) + "</div>");
                    } else {
                        error_message = "<p>Please try your connection again at a later time</p>";
                    }

                    drano.socket.setWorkComplete();

                    if (modal) {

                        modal
                            .setTitle("Connection Error")
                            .setBody("<p>An error occured while communicating with GMail's Servers</p>" + error_message)
                            .footer()
                                .empty();

                        modal
                            .open();
                    }
                });

                connection.on("registered-work-changed", function () {

                    drano.socket.setWorkComplete();

                    if (modal) {
                        modal
                            .setBody('<p>This operation has quit because you started performing a different task, possibly in a different window or tab. In order to be as careful as possible with your email, ' + d.site_name + ' will only work on one operation at time.</p><p>Please close this window and be sure to only perform on operation at a time going forward.</p>')
                            .setTitle("Operation Terminated")
                            .footer()
                                .empty()
                                .append('<button class="btn btn-warning dismiss-button">Dismiss</button>');

                        modal
                            .footer()
                                .find(".dismiss-button")
                                    .click(function () {
                                        modal.close();
                                        utils.disablePage();
                                        return false;
                                    });

                        modal
                            .showFooter()
                            .open();
                    }
                });

                connection.on("mailbox-open-error", function (msg) {

                    drano.socket.setWorkComplete();

                    if (modal) {
                        modal
                            .setBody('<p>There was an error attempting to open the folder (or label) <em>' + msg.mailbox_name + '</em> in your account. ' + d.site_name + ' needs to be able to access this folder over IMAP to function correctly.</p><p>You can find <a href="http://email.about.com/od/gmailtips/qt/et_hide_in_imap.htm">more information on how to control which Gmail folders are available via IMAP</a>.</p>')
                            .setTitle("Error Opening " + msg.mailbox_name)
                            .footer()
                                .append('<a href="/logout" class="btn btn-warning">Return Home</a>');

                        modal
                            .showFooter()
                            .open();
                    }
                });

                connection.socket.on('error', function (obj) {
                    console.log(obj);
                });

                connection.on('reconnect_failed', reconnect_failed_error('reconnect_failed'));
                connection.on('connect_failed', reconnect_failed_error('connect_failed'));

                if (debug) {
                    debug_event(connection, 'reconnect_error');
                    debug_event(connection, 'connect');
                    debug_event(connection, 'connecting');
                    debug_event(connection, 'disconnect');
                    debug_event(connection, 'reconnect');
                    debug_event(connection, 'reconnecting');
                }

                connection.on("auth-error", function () {

                    drano.setWorkComplete();

                    if (modal) {
                        modal
                            .setBody("<p>There was an authentication error with GMail.  Logging you out now.</p>")
                            .setTitle('Authentication Error')
                            .open();
                    }

                    // Delete the current session cookie too, to really make
                    // sure we're back at square one
                    document.cookie = 'drano_user=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';

                    if (utils) {
                        utils.logout();
                    }
                });

                if (stored_events) {
                    $.each(stored_events, function (a_event, a_callback) {
                        connection.on(a_event, a_callback);
                    });
                }

                return this;
            }
        };
    }());
});

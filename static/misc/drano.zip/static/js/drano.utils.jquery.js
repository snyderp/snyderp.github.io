drano.utils = (function ($) {

    var host = window.location.host + "/",
        protocol = window.location.protocol,
        base_url = protocol + "//" + host,
        pause_amount = 3000, // Miliseconds before doing a redirect
        prev_log = window.console.log,
        log_messages = [];

    return {
        disablePage: function () {

            var $a = $("a"),
                $buttons = $("button"),
                $inputs = $("input");

            $buttons
                .removeClass("btn-warning")
                .removeClass("btn-primary");

            $a.attr("href", "#")
                .add($buttons).add($inputs)
                    .addClass("disabled")
                    .attr("disabled", "disabled")
                    .click(function () {
                        return false;
                    });

            $("body").addClass("muted");
        },
        staticUrl: function (relative_url) {
            return drano.static_url + relative_url;
        },
        redirect: function (path, immediate) {

            var redirect_path = base_url + path;

            if (immediate) {

                window.location = redirect_path;

            } else {

                setTimeout(function () {
                    window.location = redirect_path;
                }, pause_amount);
            }
        },
        logout: function (immediate) {
            return this.redirect("logout", immediate);
        }
    };
}(jQuery));

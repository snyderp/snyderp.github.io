$(function () {

    var $form = $("#fill-confirm-form"),
        messages_to_delete = 0,
        messages_deleted = 0,
        messages_to_create = 0,
        messages_created = 0,
        d = window.drano,
        modal = d.modal,
        prog = d.progress,
        socket = d.socket.init(),
        utils = d.utils;

    prog.hide();

    $form.submit(function () {
        $(this).hide();
        prog.show();
        socket.emit("mailbox-fill", {
            files: $form.find("select").val()
        });
        return false;
    });

    socket
        .setDefaultDisconnectCallback()
        .setEvents({
            "mailbox-fill-overview": function (msg) {
                socket.bindLeavePageWarning();
                messages_to_delete = msg.to_delete;
                messages_to_create = msg.to_create;
                prog
                    .setDescription("<p>Found " + messages_to_delete + " messages in your inbox currently that need deleting.  Beginning to delete them now&hellip;</p>")
                    .setTotal(messages_to_delete);
            },
            "mailbox-fill-deleted": function (msg) {
                messages_deleted += 1;
                prog
                    .setAmount(messages_deleted)
                    .setDescription("<p>Finished deleting message <em>" + msg.deleted + "</em></p>");
            },
            "mailbox-fill-deleted-complete": function (msg) {
                prog
                    .setDescription("<p>Finished deleting all messages in your INBOX.  Now getting ready to create " + messages_to_create + " test messages.</p>")
                    .setTotal(messages_to_create);
            },
            "mailbox-fill-created": function (msg) {
                messages_created += 1;
                prog
                    .setDescription("<p>Finished creating test message <em>" + msg.created + "</em></p>")
                    .setAmount(messages_created);
            },
            "mailbox-fill-complete": function (msg) {

                socket.setWorkComplete();

                prog
                    .setPercentage(100)
                    .setDescription("<p>Complete!</p>");

                modal
                    .setBody("<p>Mailbox repopulating completed!</p>")
                    .setTitle("Loading Complete")
                    .open();
                utils.redirect("");
            }
        });
});

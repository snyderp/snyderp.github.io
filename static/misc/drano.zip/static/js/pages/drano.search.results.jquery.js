$(function () {

    var $select_all = $("#all"),
        $cancel_button = $("button.btn-cancel"),
        $form_buttons = $("button[type='submit']"),
        $message_checks = $("tbody input[type='checkbox']"),
        $submit_button = null,
        $remove_button = null,
        $close_dialog_button = null,
        $form = $("#password-form"),
        $form_action = $("#submit_action"),
        $confirm_button,
        $password_checks = $(".password-check"),
        d = window.drano,
        modal = d.modal;

    $form_buttons.each(function () {
        var $this = $(this);
        if ($this.hasClass("button-encrypt")) {
            $submit_button = $this;
        } else {
            $remove_button = $this;
        }
    });

    modal.footer().append('<a href="#" id="close-dialog-button" class="btn">Cancel</a> <button class="btn btn-warning" id="confirm-button">Begin Processing</button>');
    modal
        .setTitle("Warning")
        .showFooter();

    $confirm_button = $("#confirm-button");
    $confirm_button.click(function () {
        $form.submit();
    });

    $close_dialog_button = $("#close-dialog-button");
    $close_dialog_button.click(function () {
        modal.close();
    });

    $(".password-holder").tooltip();

    $form_buttons.click(function() {

        var $this = $(this);
        if ($this.hasClass("button-encrypt")) {
            $form_action.val("encrypt");
            $confirm_button.text("Begin Encryption");
            modal.setBody("<p>You are about to change your email data. Are you sure you want to proceed?</p>");
        } else {
            $form_action.val("remove");
            $confirm_button.text("Begin Redaction");
            modal.setBody("<p>You are about to irreversably change your email data. Are you sure you want to proceed?</p>");
        }

        modal.open();
        return false;
    });

    $cancel_button.click(function () {
        $password_checks.each(function () {
            this.checked = false;
        });
        return false;
    });

    $select_all.change(function () {
        var $that = $(this);
        $password_checks.each(function () {
            this.checked = $that.is(":checked");
        });
    });
});

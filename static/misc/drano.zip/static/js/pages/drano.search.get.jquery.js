$(function () {

    var messages_in_mailbox = -1,
        searched_messages = 0,
        found_passwords = 0,
        just_searched = 0,
        d = window.drano,
        socket = d.socket.init(),
        modal = d.modal,
        prog = d.progress,
        utils = d.utils,
        passes = {},
        ordered_passes = [],
        $select_all = $("#all"),
        $num_passwords_mailbox = $(".num-passwords-mailbox"),
        $num_messages_mailbox = $(".num-messages-mailbox"),
        $prog_bar_container = $("#search-bar-container"),
        $complete_container = $("#search-complete-container"),
        $complete_button = $complete_container.find("a"),
        $table = $("#password-table"),
        remove_row_from_table = function (row) {

            var index = ordered_passes.indexOf(row);
            row.elm.detach();
            if (index > -1) {
                ordered_passes.splice(index, 0);
            }
        },
        sort_elm_in_table = function (row) {

            var made_chage = false;

            $.each(ordered_passes, function (key, val) {

                if (row.numSenders() > val.numSenders()) {
                    row.elm.insertBefore(val.elm);
                    ordered_passes.splice(key, 0, row);
                    made_chage = true;
                    return false;
                } else if (row.numSenders() === val.numSenders() && row.numMessages() > val.numMessages()) {
                    row.elm.insertBefore(val.elm);
                    ordered_passes.splice(key, 0, row);
                    made_chage = true;
                    return false;
                }
            });

            if (!made_chage) {
                $table.find("tbody").append(row.elm);
                ordered_passes.push(row);
            }
        },
        obfuscate_password = function (password) {
            var len = password.length,
                obscured_portion,
                output = "";
            return (len <= 2) ? password : [password[0], '*****', password[len -1]].join("");
        },
        PasswordRow;

    PasswordRow = function (instance, table) {

        var html_lines = [
            "<tr><td><input class='password-check' type='checkbox' disabled='disabled'></td>",
            "<td><label><span class='password-holder' data-toggle='tooltip' data-title=''></span></label></td>",
            "<td><h4>Found in <span class='num-instances'>1</span> messages from <span class='num-senders'>1</span> senders.</h4><ul class='sender-list'>  </ul></td></tr>"
        ];

        this.password = instance.password;
        this.hashed_password = instance.hashed_pass;
        this.table = table;
        this.instances = [instance];
        this.senders = [instance.sender];
        this.elm = $(html_lines.join(""));
        this.elm.data("password_object", this);
        this.elm.attr("data-hashed-pass", this.hashed_password);
        this.password_holder = $(this.elm).find(".password-holder");
        this.num_instances_elm = $(this.elm).find('.num-instances');
        this.num_senders_elm = $(this.elm).find('.num-senders');
        this.senders_list_elm = $(this.elm).find('.sender-list');

        this.password_holder
            .attr("data-title", this.password)
            .text(obfuscate_password(instance.password))
            .tooltip();

        sort_elm_in_table(this);
    };

    PasswordRow.prototype.numMessages = function () {
        return this.instances.length;
    };

    PasswordRow.prototype.numSenders = function () {
        return this.senders.length;
    };

    PasswordRow.prototype.addInstance = function (instance) {

        this.instances.push(instance);

        if (this.senders.indexOf(instance.sender) === -1) {

            this.senders.push(instance.sender);
            remove_row_from_table(this);
            sort_elm_in_table(this);
        }
    };

    PasswordRow.prototype.update = function () {

        var num_senders = this.senders.length,
            displayed_senders = this.senders_list_elm.children().length;

        this.num_instances_elm.text(this.instances.length);
        this.num_senders_elm.text(num_senders);

        if (displayed_senders < 5 && displayed_senders !== num_senders) {
            this.senders_list_elm.append("<li>" + this.senders[num_senders - 1] + "</li>");
        } else if (displayed_senders === 5 && this.senders_list_elm.find(".more").length === 0) {
            this.senders_list_elm.append("<li class='more'>And <span class='num-more'>1</span> more</li>");
        } else {
            this.senders_list_elm.find(".num-more").text(num_senders - 5);
        }
    };


    socket
        .setDefaultDisconnectCallback()
        .setEvents({
            "password-search-count": function (msg) {

                socket.bindLeavePageWarning();
                messages_in_mailbox = msg.count;
                prog
                    .setTotal(messages_in_mailbox)
                    .setDescription("<p>Narrowed down my search to " + messages_in_mailbox + " messages.  Starting search now&hellip;</p>");
            },
            "password-search-progress": function (msg) {
                just_searched = 0;
                $.each([msg], function (index, val) {
                    just_searched += val.searched;
                    searched_messages += val.searched;
                    found_passwords += val.found.length;
                    $.each(val.found, function (key, value) {
                        if (!passes[value.password]) {
                            passes[value.password] = new PasswordRow(value, $table);
                        } else {
                            passes[value.password].addInstance(value);
                        }
                        passes[value.password].update();
                    });
                });

                $num_passwords_mailbox.text(found_passwords);
                $num_messages_mailbox.text(searched_messages);

                prog
                    .setAmount(searched_messages)
                    .setDescription("<p>Finished searching messages " + (searched_messages - just_searched + 1) + "-" + searched_messages + " of " + messages_in_mailbox + "</p><p>So far I've found " + found_passwords + " possible passwords.</p>");
            },
            "password-search-mapping" : function (msg) {

                $.each(msg.passwords, function (key, val) {

                    var password = val[0],
                        hashed_pass = val[1];

                    $table
                        .find("tr[data-hashed-pass='" + hashed_pass + "']")
                            .find('input')
                                .val(key)
                                .attr("name", "token_" + key)
                                .attr("id", "token_" + key)
                                .end()
                            .find("label")
                                .attr("for", "token_" + key);
                });
            },
            "password-search-complete": function (msg) {

                socket.setWorkComplete();

                prog
                    .container()
                        .empty()
                        .append($complete_container.show());

                $(".password-check").add($select_all).removeAttr("disabled");
            }
        });

    socket.emit("password-search-begin");

    $select_all.change(function () {
        var $that = $(this);
        $(".password-check").each(function () {
            this.checked = $that.is(":checked");
        });
    });
});

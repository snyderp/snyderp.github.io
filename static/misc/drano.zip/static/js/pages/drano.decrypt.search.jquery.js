$(function () {

    var matching_messages = 0,
        messages_decrypted = 0,
        d = window.drano,
        key = null,
        socket = d.socket,
        modal = d.modal,
        prog = d.progress.hide(),
        utils = d.utils,
        form = d.form,
        $close_button,
        $webcam_button = $("#qr-scan-button"),
        $scan_status = $('#scan-status'),
        qr_reader = window.qrReader;

    qr_reader
        .setHeight(300)
        .setWidth(400)
        .load();

    $webcam_button.click(function () {
        if (qr_reader.isWebCamOn()) {
            qr_reader.stopWebCam();
            $webcam_button.text("Start scanning");
        } else {
            qr_reader.startWebCam();
            $webcam_button.text("Stop scanning");
        }
        return false;
    });

    // Monkey patch the default read function used by the qrcode library
    // so that we can jam the scanned decryption key into the existing
    // form
    qrcode.callback = function (value) {
        form.val(value);
        qr_reader.stopWebCam();
        $webcam_button.text("Start scanning");
        $scan_status.text("QR Code found");
    };

    modal
        .footer()
            .append("<button id='close-button' class='btn btn-warning'>Close</button>");

    $close_button = $("#close-button");
    $close_button.click(function () {
        modal
            .close()
            .hideFooter();
    });

    form
        .setDescription("Enter your key below to reverse the previously encrypted data in your Gmail account.")
        .setLabel('Decryption Key')
        .setButtonText('Begin Decryption');

    form.onSubmit(function () {
        prog.show();
        form.disable();
        $webcam_button.attr("disabled", "disabled");
        key = form.val();
        socket.init();
        socket.addParam("key", key);
        socket.emit("account-decrypt");
        return false;
    });

    socket
        .setDefaultDisconnectCallback()
        .setEvents({
            "account-decrypt-key-error": function (msg) {

                matching_messages = 0;
                messages_decrypted = 0;
                modal
                    .showFooter()
                    .setBody("<p>The value you provided does not appear to be a valid key.  Please double check your entry or rescan your QR code and try again.")
                    .setTitle("Invalid Key")
                    .open();
                prog.hide();
                form
                    .enable()
                    .show();
                $webcam_button.removeAttr("disabled");
            },
            "account-decrypt-count": function (msg) {
                socket.bindLeavePageWarning();
                matching_messages = msg.count;
                prog
                    .setTotal(matching_messages)
                    .setDescription("<p>Found <em>" + matching_messages + "</em> messages that contain sections to decrypt.  Starting to decrypt each instance now.</p>");
            },
            "account-decrypt-progress": function (msg) {

                messages_decrypted += 1;
                prog
                    .setAmount(messages_decrypted)
                    .setDescription("<p>Finished decrypting message " + messages_decrypted + " of " + matching_messages + "</p><p>Just restored <em>" + msg.subject + "</em>.</p>");
            },
            "account-decrypt-complete": function (msg) {

                socket.setWorkComplete();

                prog
                    .setPercentage(100)
                    .setDescription("<p>Find / replace complete!</p>");

                modal
                    .setBody("<p>Finished decrypting process</em>.</p><p>You will be redirected to a summary of the decryption process in a few seconds.</p>")
                    .setTitle("Find / Encrypt Complete")
                    .hideFooter()
                    .open();

                utils.redirect("decrypt/complete");
            }
        });
});

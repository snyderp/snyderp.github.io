$(function () {

    var messages_to_scrub = 0,
        scrubbed_passwords = 0,
        encrypt_errors = 0,
        missing_msg_id_count = 0,
        d = window.drano,
        s = d.settings,
        modal = d.modal,
        prog = d.progress,
        socket = d.socket.init(),
        utils = d.utils,
        qrcodes = d.qrcodes,
        debug = d.debug,
        action = s.action,
        action_past_tense = action === "encrypt" ? "Encrypted" : "Redacted",
        action_verb = action === "encrypt" ? "encryption" : "redaction",
        $confirm_button,
        kill_timer = false,
        timer_started_ts = -1,
        format_time = function () {

            var current_time_ts = Math.floor(new Date().getTime() / 1000),
                time_diff = current_time_ts - timer_started_ts,
                min = Math.floor(time_diff / 60),
                sec = time_diff % 60;

            if (sec < 10) {
                sec = "0" + sec;
            }

            if (min < 10) {
                min = "0" + min;
            }

            return min + ":" + sec;
        },
        update_display_timer = function () {
            if (!kill_timer) {
                prog
                    .descriptionElm()
                        .find(".update-timer")
                            .text(format_time() + " since last update.");
                setTimeout(update_display_timer, 1000);
            }
        };

    modal.hideFooter();

    socket.setDefaultDisconnectCallback();
    socket.setEvents({
        "password-encrypt-details": function (msg) {
            var form_action = action === "encrypt" ? "encrypt" : "redact";
            socket.bindLeavePageWarning();
            messages_to_scrub = msg.count;
            prog
                .setTotal(messages_to_scrub)
                .setDescription("<p>" + messages_to_scrub + " messages left with passwords to " + form_action + ".</p>");
        },
        "password-encrypt-progress": function (msg) {

            var form_action = action === "encrypt" ? "encrypt" : "redact",
                description;

            scrubbed_passwords += 1;

            description = "<p>" + (messages_to_scrub - scrubbed_passwords) + " message(s) left with passwords to " + form_action + ".</p>";
            description += '<p>' + action_past_tense + ' message <em>' + msg.message + '</em>.';


            if (debug) {
                description += '  <span class="update-timer"></span></p>';

                timer_started_ts = Math.floor(new Date().getTime() / 1000);
                update_display_timer();
            }

            prog
                .setAmount(scrubbed_passwords)
                .setDescription(description);
        },
        "password-encrypt-error": function (msg) {
            encrypt_errors += 1;
        },
        "password-encrypt-malformed-message": function (msg) {
            missing_msg_id_count += 1;
        },
        "password-encrypt-cleanup": function (msg) {
            kill_timer = true;
            prog
                .setPercentage(100)
                .setDescription("<p>Cleaning up temporary work. Almost done!</p>");
        },
        "password-encrypt-complete": function (msg) {

            var html, error_html = '';

            socket.setWorkComplete();

            prog
                .setDescription("<p>Password " + action_verb + " complete!</p>");

            if (missing_msg_id_count > 0) {

                error_html += '<div class="alert alert-warning">We were not able to ' + action + ' ' + missing_msg_id_count + ' messages because they were malformed.  Specifically, these messages do not include a <a href="http://tools.ietf.org/html/rfc2822">Message-ID</a>, which email programs use to uniquely identify email messages. No changes were made to these message. Any passwords in these messages will remain unchanged.</div>';
            }

            if (encrypt_errors > 0) {
                error_html += '<div class="alert alert-info">We were not able to ' + action + ' ' + encrypt_errors + " messages with passwords because of an issue on GMails end.  This occasionally happens during periods of high load or other issues on Google's end.  If you'd like, you can " + action + " these remaining messages by tring again later</div>";
            }

            if (action === "encrypt") {

                html = "<p>Finished encrypting all selected passwords.</p><p>To decrypt these items in the future, you will need to use the above key. <p><strong>Be sure to store this key somewhere safe</strong>, as without it your information will be unrecoverable.</p>" + error_html + "<div class'form-actions'><button class='btn btn-warning' id='confirm-button'>I have stored this key some place secure</button></div>";

            } else {

                html = "<p>Finished redacting all selected passwords.</p><p>Your account will now have these passwords replaced with a notice that they were removed by this service.</p>" + error_html + "<div class'form-actions'><button class='btn btn-warning' id='confirm-button'>Continue</button></div>";

            }

            prog.container()
                .html(html);

            $confirm_button = $("#confirm-button").click(function () {
                utils.redirect("search/complete", true);
            });
        }
    });

    if (qrcodes.supportsCreatingQrCodes()) {
        $('#qr-code').qrcode({
            render: "canvas",
            text: s.drano_key,
            width: 400,
            height: 400
        });
    }

    socket.emit("password-encrypt-begin", {
        "pw_mappings": s.passwords,
        "action": action
    });
});

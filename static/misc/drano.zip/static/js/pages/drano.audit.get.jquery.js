$(function () {

        // Indexes correspond to serious, medium, and not-important
        // rule matches, accordingly
    var rule_matches = [[], [], []],
        pricing_total = 0,
        matching_count = 0,
        d = window.drano,
        s = d.settings,
        socket = d.socket.init(),
        modal = d.modal,
        prog = d.progress,
        utils = d.utils,
        $prog_bar_container = $("#search-bar-container"),
        $complete_container = $("#search-complete-container"),
        $results_section = $("#results-section"),
        $severe_rule_list = $results_section.find(".well-alert ul"),
        $medium_rule_list = $results_section.find(".well-warning ul"),
        $no_biggie_rule_list = $results_section.find(".well-success ul"),
        $total_price = $complete_container.find(".cash-money-row"),
        $price_fields = $total_price.find("span").add("#cash-money-text-value"),
        $lists = [$severe_rule_list, $medium_rule_list, $no_biggie_rule_list],
        $columns = $.map($lists, function ($elm) { return $elm.closest("div"); }),
        $intros = $.map($columns, function ($elm) { return $elm.find(".intro"); }),
        to_li = function (html) {
            return "<li style='display: none;'>" + html + "</li>";
        },
        equalize_heights = function (elements) {
            var max_height = -1;

            $.each(elements, function (index, $elm) {

                var col_height = $elm.css("height", "").height();
                if (col_height > max_height) {
                    max_height = col_height;
                }
            });

            $.each(elements, function (index, $elm) {

                $elm.height(max_height);
            });
        },
        favicon_img = function (rule) {
            return "<img src='" + s.favicons_uri + "/" + rule.id + ".png' class='img-polaroid' alt='" + rule.name + "'>";
        },
        add_rule_to_list = function (rule, $list) {

            var list_text = "<a href='" + $.trim(rule.domain) + "'>" + favicon_img(rule) + " " + rule.name + "</a>";

            if (rule.price) {

                if (rule.severity !== "Email plus") {
                    pricing_total += rule.price;
                }

                list_text += "<span class='badge pull-right'>$" + rule.price.toFixed(2) + "</span>";
            }

            $list.prepend(to_li(list_text));
            $list.find("li:first").fadeIn();
            $price_fields.text("$" + pricing_total.toFixed(2));
        };

    equalize_heights($intros);

    socket.setEvents({
        "mailbox-audit-connecting": function () {

            socket.bindLeavePageWarning();
            prog
                .setDescription("<p>Preparing to check your account for ties to other high value accounts attackers could be interested in.</p>");
        },
        "mailbox-audit-num-rules": function (msg) {

            prog
                .setTotal(msg.num_rules)
                .setDescription("<p>There are " + msg.num_rules + " high value accounts and resources we'll look for in your account.  Preparing to search for the first rule.</p>");
        },
        "mailbox-audit-rule-start": function (msg) {

            prog
                .setAmount((msg.rule_index + 1))
                .setDescription("<p>Searching for evidence that access to your account could give an attacker access to an <em>" + msg.name + "</em> account.</p>");
        },
        "mailbox-audit-rule-filter": function (msg) {

            prog
                .setDescription("<p>Found <em>" + msg.match_count + "</em> messages that could tie your email account to a <em>" + msg.name + "</em> account.</p><p>We will now search these messages more carefully to make sure</p>.");
        },
        "mailbox-audit-rule-done": function (msg) {

            if (msg.is_match) {

                switch (msg.rule.severity) {
                    case "Password given":
                        add_rule_to_list(msg.rule, $severe_rule_list);
                        break;

                    case "Email only":
                        add_rule_to_list(msg.rule, $medium_rule_list);
                        break;

                    case "Email plus":
                        add_rule_to_list(msg.rule, $no_biggie_rule_list);
                        break;
                }
                matching_count += 1;
            }

            prog
                .setDescription("<p>Found <em>" + msg.match_count + "</em> messages that could tie your email account to a <em>" + msg.name + "</em> account.</p><p>Finished searching message <em>" + (msg.match_index + 1) + "</em></p>.");
        },
        "mailbox-audit-complete": function (msg) {

            socket.setWorkComplete();

            $.each($lists, function (index, $list_elm) {
                $list_elm.find("li:last").remove();
            });

            prog.container().fadeOut(function () {
                $(this).remove();
            });
        }
    });

    socket
        .setDefaultDisconnectCallback()
        .emit("mailbox-audit");
});

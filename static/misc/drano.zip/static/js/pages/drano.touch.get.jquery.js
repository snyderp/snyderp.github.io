$(function () {

    var $form = $("#fill-confirm-form"),
        messages_to_touch = 0,
        messages_touched = 0,
        amount_processed = 0,
        d = window.drano,
        modal = d.modal,
        prog = d.progress,
        socket = d.socket.init(),
        utils = d.utils;
        bytesToSize2 = function (bytes) {
            var sizes = ['n/a', 'bytes', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB'],
                i = +Math.floor(Math.log(bytes) / Math.log(1024));
            return  (bytes / Math.pow(1024, i)).toFixed( i ? 1 : 0 ) + ' ' + sizes[ isNaN( bytes ) ? 0 : i+1 ];
        },
        labeled = function (label, val) {
            return "<p><strong>" + label + ": </strong> " + val + "</p>";
        };

    prog.hide();

    $form.submit(function () {

        $(this).hide();
        prog.show();
        socket.emit("mailbox-touch");
        return false;
    });

    socket.setDefaultDisconnectCallback();
    socket.setEvents({
        "mailbox-touch-overview": function (msg) {
            socket.bindLeavePageWarning();
            messages_to_touch = msg.to_touch;
            prog
                .setDescription("<p>Found " + messages_to_touch + " messages in your mailbox. Beginning to download and parse them now&hellip;</p>")
                .setTotal(messages_to_touch);
        },
        "mailbox-message-touched": function (msg) {
            var lines = [];
            messages_touched += 1;
            amount_processed += msg.amt;

            if (msg.plain_len) {

                lines = [
                    labeled("Position", messages_touched + " of " + messages_to_touch),
                    labeled("Subject", msg.touched),
                    labeled("Length of HTML", msg.html_len),
                    labeled("Length of Plain Text", msg.plain_len),
                    labeled("Message ID", msg.message_id),
                    labeled("Bytes Downloaded", bytesToSize2(amount_processed)),
                    labeled("Sender (Name)", msg.sender_name),
                    labeled("Sender (Address)", msg.sender_address),
                    labeled("Recipient (Name)", msg.recipient_name),
                    labeled("Recipient (Address)", msg.recipient_address),
                    labeled("Date", msg.date),
                    labeled("Internal Date", msg.internal_date),
                    labeled("Flags", msg.flags),
                    labeled("Labels", msg.labels)
                ];

            } else if (msg.body_len) {

                lines = [
                    labeled("Position", messages_touched + " of " + messages_to_touch),
                    labeled("Subject", msg.touched),
                    labeled("Length of Body", msg.body_len),
                    labeled("Message ID", msg.message_id),
                    labeled("Bytes Downloaded", bytesToSize2(amount_processed)),
                    labeled("Sender (Name)", msg.sender_name),
                    labeled("Sender (Address)", msg.sender_address),
                    labeled("Recipient (Name)", msg.recipient_name),
                    labeled("Recipient (Address)", msg.recipient_address),
                    labeled("Date", msg.date),
                    labeled("Internal Date", msg.internal_date),
                    labeled("Flags", msg.flags),
                    labeled("Labels", msg.labels)
                ];

            }

            prog
                .setAmount(messages_touched)
                .setDescription(lines.join("\n"));
        },
        "mailbox-touch-complete": function (msg) {
            socket.setWorkComplete();

            prog
                .setPercentage(100)
                .setDescription("<p>Finished touching all messages in your INBOX.</p>");

            modal
                .setBody("<p>Finished touching all messages in your INBOX!</p>")
                .setTitle("Test Complete")
                .open();
            utils.redirect("");
        }
    });
});

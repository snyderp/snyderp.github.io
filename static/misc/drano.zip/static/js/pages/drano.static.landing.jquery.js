$(function () {

    var $button = $(".actions a"),
        $consent_modal = $("#opt-in-modal"),
        $stage_1_elm = $(".stage-1"),
        $stage_2_elm = $(".stage-2"),
        $exclude_btn = $(".btn-exclude"),
        s = window.drano.settings;

    $exclude_btn.click(function () {
        $stage_1_elm.hide();
        $stage_2_elm.show();
        return false;
    });

    if (s.stats_record_enabled) {

        $button.click(function () {

            $stage_2_elm.hide();
            $stage_1_elm.show();

            $consent_modal.modal('show');
            return false;
        });
    }
});

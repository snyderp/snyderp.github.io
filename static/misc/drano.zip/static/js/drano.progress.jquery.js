$(function () {

    drano.progress = (function () {

        var $progress_bar = $("#drano-progress-bar")
                .css("width", "0%"),
            $progress_desc = $("#drano-progress-description"),
            $cancel_button = $("#drano-progress-cancel"),
            $container = $progress_desc.closest('div.well'),
            total = 100;

        // Register a default cancel action, which is just to send the
        // "disconnect" message over the websocket
        $cancel_button.click(function () {

            var prog = drano.progress,
                modal = drano.modal,
                socket = drano.socket,
                $confirm_yes_button,
                $confirm_no_button,
                on_confirm = function () {
                    prog
                        .setPercentage(0)
                        .setDescription("<p>Canceling action and closing connection.</p>")
                        .cancelButton()
                            .attr("disabled", "disabled");

                    if (socket) {
                        socket
                            .closeConnection()
                            .unbindLeavePageWarning();
                    }
                };

            // If the modal is loaded on the current page, use it to create
            // a confirmation option first
            if (modal) {

                $confirm_yes_button = $('<button class="btn btn-warning">Cancel Work</button>')
                    .click(function () {

                        on_confirm();
                        modal.close();
                    });

                $confirm_no_button = $('<button class="btn">Continue Work</button>').
                    click(function () {

                        modal.close();
                    });

                modal
                    .setTitle("Cancel Confirmation")
                    .setBody("<p>Are you sure you want to cancel the current action. Doing so could leave your account with work half-processed work.  You will not lose any data, but you could end up with duplicate messages or messages in the '<em>Cloudsweeper Work</em>' folder that you should recover or delete.</p><p><strong>Proceed at your own caution!</strong></p>")
                    .showFooter()
                    .footer()
                        .empty()
                        .append($confirm_no_button)
                        .append($confirm_yes_button);

                modal.open();

            // Otherwise, just perform the close action w/o asking twice
            } else {

                on_confirm();
            }
        });

        return {
            cancelButton: function () {
                return $cancel_button;
            },
            container: function () {
                return $container;
            },
            hide: function () {
                $container.hide();
                return this;
            },
            show: function () {
                $container.show();
                return this;
            },
            setPercentage: function (percentage) {
                $progress_bar.css("width", percentage + "%");
                return this;
            },
            setTotal: function (an_int) {
                total = an_int;
                return this;
            },
            setAmount: function (amount) {
                $progress_bar.css("width", ((amount / total) * 100) + "%");
                return this;
            },
            setDescription: function (html) {
                $progress_desc.html(html);
                return this;
            },
            descriptionElm: function () {
                return $progress_desc;
            }
        };
    }());
});

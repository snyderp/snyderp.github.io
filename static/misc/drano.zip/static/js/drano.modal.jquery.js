$(function () {

    drano.modal = (function () {

        var $modal = $("#drano-modal"),
            modal = $modal.modal({
                backdrop: "static",
                show: false,
                keyboard: false
            }),
            d = window.drano,
            $title = $modal.find(".modal-header h3"),
            $body = $modal.find(".modal-body"),
            $footer = $modal.find(".modal-footer").hide(),
            has_set_width = false;

        return {
            footer: function () {
                return $footer;
            },
            showFooter: function () {
                $footer.show();
                return this;
            },
            hideFooter: function () {
                $footer.hide();
                return this;
            },
            open: function () {
                $modal.modal("show");
                return this;
            },
            close: function () {
                modal.modal('hide');
                return this;
            },
            setBody: function (html) {
                $body.html(html);
                return this;
            },
            setTitle: function (str) {
                $title.text(str);
                return this;
            }
        };
    }());
});

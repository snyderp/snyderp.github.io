(function () {
    // QRCODE reader Copyright 2011 Lazar Laszlo
    // http://www.webqr.com

    var height = 600,
        width = 800,
        out_div = document.getElementById("qr-code-out"),
        qr_canvas = document.getElementById("qr-canvas"),
        qr_main_body = document.getElementById("qr-code-mainbody"),
        qr_status = document.getElementById("scan-status"),
        flash_element = null,
        error_callback,
        vid_html,
        video_element;
    var gCtx = null;
    var imageData = null;
    var stype = 0;
    var gUM = false;
    var webkit = false;
    var vidstream = null;

    function initCanvas(w, h) {

        qr_canvas.style.width = w + "px";
        qr_canvas.style.height = h + "px";
        qr_canvas.width = w;
        qr_canvas.height = h;
        gCtx = qr_canvas.getContext("2d");
        gCtx.clearRect(0, 0, w, h);
        imageData = gCtx.getImageData(0, 0, w, h);
    }

    function captureToCanvas(e) {

        if (stype !== 1) {
            return;
        }

        if (!gUM) {

            if (error_callback) {
                error_callback("Tried to campture to canvas without a valid canvas element");
            }

        } else {

            try {

                gCtx.drawImage(video_element, 0, 0, width, height);

                qrcode.decode();
                qr_status.innerHTML = "scan complete!";
                // if qrcode decodes successfully, it doesn't throw
                stype = 0;
                video_element.pause();
                vidstream.stop();

            } catch (error) {

                setTimeout(captureToCanvas, 500);
            }
        }
    }

    function isCanvasSupported () {
        var elem = document.createElement('canvas');
        return !!(elem.getContext && elem.getContext('2d'));
    }

    function onAcquiredMedia (stream) {
        vidstream = stream;
        video_element.src = webkit
            ? window.webkitURL.createObjectURL(stream)
            : window.URL.createObjectURL(stream);
        gUM = true;
        qr_status.innerHTML = "scanning...";
        setTimeout(captureToCanvas, 500);
    }

    function onErrorAcquiringMedia (e) {
        if (error_callback) {
            error_callback(e);
        }
        gUM = false;
        return;
    }

    function load() {

        if (isCanvasSupported() && window.File && window.FileReader) {

            initCanvas(width, height);
            qrcode.callback = function () {};

        } else {

            qr_main_body.innerHTML = '<p>sorry, your browser does not support the functionality we need to read your qr code.</p><br><br>'+
            '<p id="mp1">try <a href="http://www.mozilla.com/firefox">firefox</a> or <a href="http://chrome.google.com">chrome</a> or <a href="http://www.opera.com">opera</a>.</p>';
        }
    }

    function stopWebCam () {
        stype = 0;
        qr_status.innerHTML = "scanning stopped.";
        if (video_element){
            video_element.pause();
            video_element.src = ""; // might not be cross-browser
        }
        if (vidstream) {
            vidstream.stop();
        }
    }

    function setwebcam () {

        var video_element_id = "qr-code-video";

        if (stype === 1) {
            setTimeout(captureToCanvas, 500);
            return;
        }

        vid_html = vid_html || '<video id="' + video_element_id + '" autoplay style="width: ' + width + 'px; height: ' + height + 'px;"></video>';

        if (navigator.getUserMedia) {

            out_div.innerHTML = vid_html;
            webkit = false;
            video_element = document.getElementById(video_element_id);
            navigator.getUserMedia({video: true, audio: false}, onAcquiredMedia, onErrorAcquiringMedia);

        } else if (navigator.webkitGetUserMedia) {

            out_div.innerHTML = vid_html;
            webkit = true;
            video_element = document.getElementById(video_element_id);
            navigator.webkitGetUserMedia({video: true, audio: false}, onAcquiredMedia, onErrorAcquiringMedia);

        } else if (navigator.mozGetUserMedia) {

            out_div.innerHTML = vid_html;
            webkit = false;
            video_element = document.getElementById(video_element_id);
            navigator.mozGetUserMedia({video: true, audio: false}, onAcquiredMedia, onErrorAcquiringMedia);

        } else {

            if (error_callback) {
                error_callback("couldn't initilize video element");
            }
            return;
        }

        stype = 1;
        setTimeout(captureToCanvas, 500);
    }

    // Now punch through some functionality to other codes
    window.qrReader = {
        setErrorCallback: function (func) {
            error_callback = func;
            return this;
        },
        setHeight: function (h) {
            height = h;
            return this;
        },
        setWidth: function (w) {
            width = w;
            return this;
        },
        load: function () {
            load();
            return this;
        },
        startWebCam: function () {
            setwebcam();
            return this;
        },
        stopWebCam: function () {
          stopWebCam();
          return this;
        },
        setPassLine: function (a_line) {
            passLine(a_line);
        },
        isCanvasSupported: function () {
            return isCanvasSupported();
        },
        isSupported: function () {
            return this.isCanvasSupported() && (navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia);
        },
        isWebCamOn: function () {
            return !!stype;
        }
    };
}());

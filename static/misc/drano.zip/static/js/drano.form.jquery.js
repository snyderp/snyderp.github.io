$(function () {

    drano.form = (function () {

        var $form = $("#drano-form"),
            d = window.drano,
            $input = $form.find("input:first"),
            $label = $form.find("label.form-label"),
            $desc = $form.find(".form-description"),
            $btn = $form.find("button");

        return {
            onSubmit: function (func) {
                $form.submit(func);
                return this;
            },
            val: function (v) {

                if (v !== undefined) {

                    $input.val(v);
                    return this;

                } else {

                    return $input.val();

                }
            },
            hide: function () {
                $form.hide();
                return this;
            },
            show: function () {
                $form.show();
                return this;
            },
            setDescription: function (html) {
                $desc.html(html);
                return this;
            },
            setButtonText: function (str) {
                $btn.text(str);
                return this;
            },
            setLabel: function (str) {
                $label.text(str);
                return this;
            },
            disable: function () {
                $input.add($btn).attr('disabled', 'disabled');
                return this;
            },
            enable: function () {
                $input.add($btn).removeAttr('disabled');
                return this;
            }
        };
    }());
});

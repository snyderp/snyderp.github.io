$(function () {

    drano.debug = (function () {

        return {
            log: function (msg) {
                if (console && console.log) {
                    console.log(msg);
                }
            },
            encodeEntities: function (str) {
                return String(str)
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g,'&gt;')
                    .replace(/"/g, '&quot;');
            },
            debugMessage: function (html) {

                return "<h3>Debug Output</h3>\n" + html;
            },
            objToDl: function (obj) {

                var html = "<dl>\n";

                $.each(obj, function (key, value) {

                    html += "\t<dt>" + key + "</dt>\n";
                    html += "\t<dd>" + drano.debug.encodeEntities(value) + "</dd>\n";
                });

                html += "</dl>\n";
                return html;
            }
        };
    }());
});

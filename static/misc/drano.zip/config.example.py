"""Basic server configuration options for the Drano app"""

import os
from datetime import timedelta

# Whether to launch drano in debug mode (with extra output, no enforeced
# https, etc.)
debug = True

# Main port that Tornado should listen over for serving web pages
port = 80

# Port that all socket_io / websocket traffic should go over
socket_io_port = 8001

# other modules / paths that should automatically be included when
# tornado launches
root_dir = os.path.dirname(__file__)
contrib_dir = os.path.join(root_dir, "contrib")
paths = [os.path.join(contrib_dir, d) for d in os.listdir(contrib_dir)]

# The name of the site, which will appear in <title />, <h1 />, etc.
site_name = "Dope Name"

# A salt for creating secure cookies.  Should be unique per deployment
cookie_secret = "SOMETHING RANDOM"

# The URL that Drano should launch from.  Should _not_ include trailing slash
base_url = "http://localhost"

# The branding name that should appear in passwords that are replaced or
# redacted in users' email messages
tag_name = "Cloudsweeper"

# The full form of the tag that should be used for redacted passwords
removed_tag = "[%s Removed]" % (tag_name,)

# Google provided OAuth2 credentials for completing oauth flow for IMAP access
oauth2_client_id = "FROM GOOGLE"
oauth2_client_secret = "FROM GOOGLE"

# The threshold, in seconds, when oauth tokens should be refreshed with google.
# If an oauth token is within this many seconds of expiring it will be refreshed
oauth2_expiration_threshold = 1200

# Google Analytics account ID.  If included, Google analytics will be
# included on each page view
google_analytics_account_id = None

# Set to a path to write the log to, or None to disable logging
log_dir = None

# The URI root where favicons for for the pricing rules are located
pricing_rules_uri = 'http://example.org/favicons/'

# A timedelta object describing how often we check to see if a user hasn't
# logged in, and thus if we should log them out automatically
session_gc_time = timedelta(hours=12)

# ####################
# Research Statsitics
# ####################

# Whether or not to record user tracking statastics, such as survey results
# and non-ppi containing stats about user's email accounts
stats_record = None

# Connection parameters for connecting to persistant store.
mongo = dict(
    dbname='drano',
    pool_id='webapp',
    port=27017,
    host="127.0.0.1"
)

# ####################
# Production settings
# ####################

# Configuration needed for getting torando to run with ssl.  These are
# options that will be passed down to the socket wrapper
ssl_options = False

# The username that tornado should drop down to and run as, after launching
# and binding ports
tornado_user = False

# ###############################
# Stress Test Recording settings
# ###############################

# Record stress test information.  Setting this to false will cause all the below
# settings to be ignored
stress_test_record = False

# The path to dump all network traffic to, using the netdump module.  If None
# network information won't be dumped at all
netdump_path = os.path.join(root_dir, 'logs', 'netdumps')

# The path to a location on disk that, if not None, will be used to write
# timing information about the corresponding request with the same filename
# in the config.netdump_path directory
netdump_time_path = os.path.join(root_dir, 'logs', 'netdumps', 'times')

# #########################
# Stress test run settings
# #########################

# If stress testing mode is enabled, we make a couple of changes to the
# application, to relax settings like SSL verification
# Setting to false will also make all the below settings irrelevant
stress_test_run = False

# Optional hardcoded oauth credentials.  Useful when doing stress testing
# with hardcoded responses, etc.  Set to None to use standard, oauth flow
# settings. (ie)
devel_oauth_credentials = dict(
    access_token="some token",
    expires_in=3599,
    email="some email",
)

# The IMAP library generates random message tags when doing IMAP communication,
# to avoid issues when multiplexing. This causes our messages to not hash
# as expected though. To overcome this issue, you can set a single, expected
# message tag that matches the tags used when sending messages in the
# netdump data.
imap_message_tag = None

# ###################
# Profiling settings
# ###################

# Whether to run the application in profiling mode.  Options are None, "plop",
# "heapy"
profiler = None

# If this is enabled, profiling informaiton for plop will be written to the
# below directory
plop_path = os.path.join(root_dir, "logs", "plop")

# Path to write heapy logging information to
heapy_path = os.path.join(root_dir, "logs", "heapy")

# Amount of time between each profiler poll
profile_time = 60

# ################
# Backup settings
# ################

# Settings for where archived logs should be encrypted and sent to
backup_settings = dict(
    host=mongo['host'],
    path="",
    sshuser="",
    sshpass="",
    encrypt_pass=""
)

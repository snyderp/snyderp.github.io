
def testdecrypt(key,message):
  pass

if __name__ == '__main__':
  key = 'Cloudsweeper.KU1fdd/56aOm12HTneGNg87DRuUkZT91S1rTQ2pHOkA=.HaXivoy7R12jYsOW+Uqlcw=='
  with open('/var/www/drano/test_messages/offensive_comp') as f:
    message = f.read()
  result = testdecrypt(key,message)
  print result

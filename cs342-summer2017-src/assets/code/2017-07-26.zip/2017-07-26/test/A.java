public class A {
  private A() {
  }
}

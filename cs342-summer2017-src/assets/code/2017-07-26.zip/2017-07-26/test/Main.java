public class Main {
  public static void main(String[] args) {
    A someA = new A();
  }
}

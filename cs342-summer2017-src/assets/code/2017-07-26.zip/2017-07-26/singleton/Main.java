public class Main {

  public static void main(String[] args) {

    AppConfig currentConfig = AppConfig.getInstance();
    System.out.println(currentConfig.installName);


    AppConfig secondConfig = AppConfig.getInstance();
    System.out.println(currentConfig.equals(secondConfig));
  }
}

import java.nio.file.Path;
import java.nio.file.FileSystems;

public class AppConfig {

  static private AppConfig sharedInstance;

  static public AppConfig getInstance() {
    if (AppConfig.sharedInstance == null) {
      AppConfig.sharedInstance = new AppConfig();
    }
    return AppConfig.sharedInstance;
  }


  // Getter/Setter methods omitted for concision.
  public Path logFile;
  public Integer port;
  public String installName;

  private AppConfig() {
    this.logFile = FileSystems.getDefault().getPath("logs", "app.log");
    this.port = new Integer(8080);
    this.installName = "Example installation";
  }
}

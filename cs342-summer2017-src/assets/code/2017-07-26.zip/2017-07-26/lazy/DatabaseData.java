public class DatabaseData {

  protected String[] valueableData;
  protected DatabaseConnection connection;

  public DatabaseData(String[] dataToStore) {
    this.valueableData = dataToStore;
  }

  private DatabaseConnection getConnection() {
    if (this.connection == null) {
      this.connection = new DatabaseConnection("host", "username", "password");
    }

    return this.connection;
  }

  public void save() {
    this.getConnection().saveToDatabase(this.dataToStore);
  }

  public setValuableData(String[] dataToStore) {
    this.valueableData = dataToStore;
  }
}

public class Main {
  public static void main(String[] args) {

    DatabaseData someData = new DatabaseData(args);

    if (args[0] == "save") {
      someData.save();
    }
    System.out.println("Ready to save some data...");
    someData.save();
  }
}

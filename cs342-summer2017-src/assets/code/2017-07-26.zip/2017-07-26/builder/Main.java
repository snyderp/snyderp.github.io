public class Main {

  public static void main(String[] args) {
    CS342URLBuilder builder = new CS342URLBuilder();
    CS342URLBuilder.CS342URL aUrl = builder.start()
        .setScheme("Http")
        .build();
  }
}

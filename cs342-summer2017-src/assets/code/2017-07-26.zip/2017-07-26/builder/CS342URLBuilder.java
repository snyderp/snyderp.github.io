// scheme:[//[user[:password]@]host[:port]][/path][?query][#fragment]

public class CS342URLBuilder {

  private CS342URL partialUrl;

  public class CS342URL {

    public String scheme;
    public String user;
    public String password;
    public String host;
    public Integer port;
    public String path;
    public String query;
    public String fragment;

    private CS342URL() {
    }
  }

  public CS342URLBuilder start() {
    this.partialUrl = new CS342URL();
    return this;
  }

  public CS342URLBuilder setScheme(String scheme) {
    this.partialUrl.scheme = scheme;
    return this;
  }

  public CS342URL build() {
    return this.partialUrl;
  }
}

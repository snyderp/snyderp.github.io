import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.stream.Collectors;
import java.io.IOException;

public class ReadBlocking {
  public static void main(String[] args) throws IOException {
    Path fileToRead = Paths.get(args[0]);
    String contents = Files.readAllLines(fileToRead)
        .stream()
        .collect(Collectors.joining("\n"));

    System.out.println(contents);
    System.out.println("Finished handling input");
  }
}

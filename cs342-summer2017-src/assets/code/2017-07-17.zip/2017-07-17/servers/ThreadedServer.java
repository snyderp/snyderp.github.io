import java.io.InputStream;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.Path;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

public class ThreadedServer {

  public static byte[] expensiveOperation(int index) throws IOException {
    if (index < 0 || index > 5) {
      return null;
    }
    Path fileToRead = Paths.get("files", Integer.toString(index) + ".data");
    byte[] fileContents = Files.readAllBytes(fileToRead);
    return fileContents;
  }

  private static class ResponseThread implements Runnable {
    private Socket socket;

    ResponseThread(Socket socket) {
      this.socket = socket;
    }

    public void run() {
      try {
        InputStream fromSocket = this.socket.getInputStream();
        OutputStream toSocket = this.socket.getOutputStream();

        SharedUtil utils = new SharedUtil();

        List<String> lines = utils.streamToLines(fromSocket);

        if (lines.size() > 0) {
          String receivedString = lines.get(0);
          int fileToReturn = Integer.parseInt(receivedString);
          byte[] returnData = BlockingServer.expensiveOperation(fileToReturn);
          toSocket.write(returnData);
        }
        this.socket.close();
      } catch (Exception error) {}
    }
  }

  public static void main(String[] args) throws IOException {

    ServerSocket listener = new ServerSocket(9090);

    while (true) {

      Socket socket = listener.accept();
      Thread responseThread = new Thread(new ResponseThread(socket));
      responseThread.start();
    }
  }
}

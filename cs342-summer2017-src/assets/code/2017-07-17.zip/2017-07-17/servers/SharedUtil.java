import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;

public class SharedUtil {

  public List<String> streamToLines(InputStream input) {
    List<String> lines = new BufferedReader(new InputStreamReader(input))
        .lines()
        .collect(Collectors.toList());
    return lines;
  }
}

public class Subprocess {

  public static void main(String[] args) {

    Integer index = Integer.parseInt(args[0]);
    try {
      Thread.sleep(1000);
      System.out.printf("Finished %d\n", index + 1);
    } catch (InterruptedException error) {}
  }
}

import java.util.ArrayList;
import java.io.BufferedInputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;


public class Main2 {

  public static void main(String[] args) {

    ArrayList<Process> processes = new ArrayList<>();

    Integer index = 0;
    while (index < 10) {
      String indexStr = String.valueOf(index);
      ProcessBuilder pb = new ProcessBuilder("./simple.sh", indexStr);
      pb.inheritIO().redirectOutput(ProcessBuilder.Redirect.PIPE);
      try {
        Process subProc = pb.start();
        processes.add(subProc);
      } catch (java.io.IOException error) {
        System.out.print(error.toString());
      }
      index += 1;
    }

    for (Process subProcess : processes) {
      try {
        subProcess.waitFor();
        InputStreamReader isr = new InputStreamReader(subProcess.getInputStream());
        BufferedReader reader = new BufferedReader(isr);
        System.out.println(reader.readLine());
      } catch (Exception error) {}
    }

    System.out.println("All done");
  }
}

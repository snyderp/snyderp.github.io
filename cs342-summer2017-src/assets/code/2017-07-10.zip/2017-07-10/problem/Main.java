public class Main {

  public static void expensiveOperation(Integer index) {
    try {
      Thread.sleep(1000);
      System.out.printf("Finished %d\n", index + 1);
    } catch (InterruptedException error) {
    }
  }

  public static void main(String[] args) {

    Integer index = 0;
    while (index < 10) {
      Main.expensiveOperation(index);
      index += 1;
    }

    System.out.println("All done");
  }
}

import java.util.ArrayList;

public class Trouble {

  public static class ChildThread implements Runnable {

    Integer indexName;
    ArrayList<String> reports;

    ChildThread(Integer indexName, ArrayList<String> collection) {
      this.indexName = indexName;
      this.reports = collection;
    }

    public void run() {

      try {
        Thread.sleep(1000);
      } catch (Exception error) {
      }

      long currentTime = System.currentTimeMillis();
      reports.add("Thread " + String.valueOf(this.indexName) + " finished at " + String.valueOf(currentTime));
    }
  }

  public static void main(String[] args) {

    Thread[] childThreads = new Thread[100];
    ArrayList<String> reports = new ArrayList<>(100);
    Integer index = 0;

    while (index < 100) {

      Thread childThread = new Thread(new ChildThread(index, reports));
      childThread.start();
      childThreads[index] = childThread;
      index += 1;
    }

    for (Thread aChild : childThreads) {
      try {
        aChild.join();
      } catch (Exception error) {
      }
    }

    for (String aReport : reports) {
      System.out.println(aReport);
    }

    System.out.println("All done!");
  }
}

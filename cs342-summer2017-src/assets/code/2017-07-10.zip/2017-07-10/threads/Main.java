/**
 * Example of using threads to accomplish tasks concurrently in java
 * using threads.
 */
public class Main {

  public static class ThreadExample implements Runnable {

    Integer indexName;

    ThreadExample(Integer indexName) {
      this.indexName = indexName;
    }

    public void run() {
      try {
        Thread.sleep(1000);
      } catch (Exception error) {
      }

      System.out.printf("Finished %d\n", this.indexName);
    }
  }

  public static void main(String[] args) {

    Thread[] threads = new Thread[10];
    Integer index = 0;

    while (index < 10) {
      try {
        threads[index] = new Thread(new ThreadExample(index));
        threads[index].start();
      } catch (Exception error) {}

      index += 1;
    }

    for (Thread aThread : threads) {
      try {
        aThread.join();
      } catch (Exception error) {
      }
    }

    System.out.println("All done!");
  }
}

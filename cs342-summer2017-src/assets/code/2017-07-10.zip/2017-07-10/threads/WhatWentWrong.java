length1 = anArrayList.size();
length2 = anArrayList.size();
anArrayList.put(length1, "String");
anArrayList.put(length2, "String 2");


import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.List;
import java.io.File;

public class NoOrg {

  public static class JSONView {

    public String toJSON(String name, String type, Integer size) {
      String outputString = "{";

      outputString += "\"name\": \"" + name + "\"";
      outputString += ", \"type\": \"" + type + "\"";
      outputString += ", \"size\": " + Integer.toString(size);

      outputString += "}";

      return outputString;
    }
  }

  public static class FileModel {

    public String getName(Path aFile) {
      return aFile.toString();
    }

    public String getType(Path aFile) {
      return null; // @tbd
    }

    public Integer getSize(Path aFile) throws Exception {
      byte[] contents = Files.readAllBytes(aFile);
      return contents.length;
    }
  }

  public static void main(String[] args) throws Exception {

    Path inputFile = Paths.get(args[0]);
    FileModel ourModel = new FileModel();
    String fileName = ourModel.getName(inputFile);
    String type = ourModel.getType(inputFile);
    Integer size = ourModel.getSize(inputFile);

    JSONView someJSON = new JSONView();
    String jsonString = someJSON.toJSON(fileName, type, size);

    System.out.println(jsonString);
  }
}

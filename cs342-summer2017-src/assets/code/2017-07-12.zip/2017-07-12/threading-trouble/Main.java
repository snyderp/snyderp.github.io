public class Main {

    public static void main(String[] args) {

        Account lucrativeAccount = new Account(100);

        Thread firstRequest = new Thread(() -> {
            lucrativeAccount.withdraw(80);
        });

        Thread secondRequest = new Thread(() -> {
            lucrativeAccount.withdraw(80);
        });

        firstRequest.start();
        secondRequest.start();
    }
}

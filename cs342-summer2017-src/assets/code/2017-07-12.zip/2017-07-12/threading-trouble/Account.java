public class Account {
     // Must be >= 0
    private double balance = 0.0;

    // Assume the existence of other field (e.g. name) and methods
    // such as deposit(), checkBalance() and dispenseNotes() 
    public Account(double openingBal) {
        this.balance = openingBal; 
    }

    public void setBalance(double newBalance) {
        this.balance = newBalance;
    }

    public boolean withdraw(double amount) {
        if (this.balance >= amount) { 
            try {
                Thread.sleep(2000); // Simulate risk checks 
            } catch (InterruptedException e) {
                return false; 
            }
            
            this.balance = this.balance - amount;
            dispenseNotes(amount);
            return true; 
        } 
        return false;
    } 
} 

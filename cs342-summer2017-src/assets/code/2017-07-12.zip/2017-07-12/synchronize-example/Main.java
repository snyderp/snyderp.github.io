public class Main {

  public static void main(String[] args) {

    UnSyncExample example = new UnSyncExample();

    Thread firstThread = new Thread(() -> {
      int firstInitialValue = 1;
      firstInitialValue += 1;
      int firstInt = example.chopAndScrew(firstInitialValue);
      System.out.println(firstInt);
    });

    Thread secondThread = new Thread(() -> {
      int secondInitialValue = 2;
      secondInitialValue += 1;
      int secondInt = example.chopAndScrew(secondInitialValue);
      System.out.println(secondInt);
    });

    firstThread.start();
    secondThread.start();
  }
}

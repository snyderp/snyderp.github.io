public class UnSyncExample {

  private volatile Integer value = 2;

  public synchronized int chopAndScrew(Integer otherValue) {
    this.value = this.value * otherValue * otherValue;
    this.value = this.value - otherValue;
    int anInt = value.intValue();
    return anInt;
  }
}

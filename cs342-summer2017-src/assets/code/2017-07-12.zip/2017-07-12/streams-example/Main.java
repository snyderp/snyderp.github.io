import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Main {
  public static void main(String[] args) {

    List<Integer> theBestNumbers = IntStream.range(0, 10000000).boxed().collect(Collectors.toList());

    List<Integer> biggerNumbers = theBestNumbers.parallelStream()
      .map(x -> x * x)
      .collect(Collectors.toList());

    System.out.println("all done");
  }
}

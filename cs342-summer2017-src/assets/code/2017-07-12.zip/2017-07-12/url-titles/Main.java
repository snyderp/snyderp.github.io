import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.stream.Collectors;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Example code that reads URLs from STDIN, fetches the HTML from that URL,
 * and then extracts the title of the website.
 *
 * Start with 1. fetching the urls serially with a loop, then 2. with a stream,
 * then 3. parallelizing them, and then 4. mapping them to count how often
 * the same titles are used.
 */
public class Main {
  public static void main(String[] args) {

    List<String> urls = new BufferedReader(new InputStreamReader(System.in))
        .lines()
        .collect(Collectors.toList());

    Pattern titlePattern = Pattern.compile("<title>(.*?)</title>");
    OkHttpClient client = new OkHttpClient();

    List<String> websiteTitles = urls.parallelStream()
        .map((aUrl) -> {

          Request request = new Request.Builder()
            .url("https://" + aUrl)
            .build();

          try (Response response = client.newCall(request).execute()) {

            String htmlString = response.body().string();
            Matcher titleMatcher = titlePattern.matcher(htmlString);
            if (titleMatcher.find()) {
              return titleMatcher.group(1);
            }

            return null;

          } catch (IOException error) {

            System.err.println("! Error fetching title for " + aUrl);
            return null;
          }
        })
        .collect(Collectors.toList());


    for (String aTitle : websiteTitles) {
      System.out.println(aTitle);
    }
  }
}

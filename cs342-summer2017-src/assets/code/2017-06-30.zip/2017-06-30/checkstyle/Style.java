public class Style {

  public static void main(String[] args) {

    for (String aString : args) {
      for (char aChar : aString.toCharArray()) {
        System.out.println(aChar);

        if (aChar == 'x') {
          System.out.println("Found it");
          for (String subSubString : args) {
            if (!aString.equals(subSubString)) {
              System.out.println(subSubString);
            }
            System.out.println("please make it stop");
          }
        }
      }
    }
  }
}

/**
 * Which is in the output, on input "xmen"?
 * A. (nothing)
 * B. please make it stop
 * C. xmen
 * D. men
 * E. Trick question, computer explodes
 */

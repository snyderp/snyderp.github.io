import java.util.HashMap;

public class Main {
  public static void main(String[] args) {

    if (args.length == 0) {
      System.err.println("Invalid input, no strings to Web2.0");
      System.exit(1);
    }

    HashMap<String, String> emojiMapper = new HashMap<>();
    emojiMapper.put("smile", "☺️");
    emojiMapper.put("dog", "🐶");
    emojiMapper.put("okay", "👌");

    StringBuilder allInput = new StringBuilder();
    for (String anInput : args) {
      allInput.append(anInput);
    }

    Integer numReplacements = 0;
    String combinedInput = allInput.toString();
    String output = combinedInput;

    for (String aKey : emojiMapper.keySet()) {
      Integer index = output.indexOf(aKey);
      if (index == -1) {
        continue;
      }

      numReplacements += 1;
      output = output.replaceAll(aKey, emojiMapper.get(aKey));
    }

    System.out.printf("(made %d replacements)%n", numReplacements);
    System.out.println(output);
  }
}


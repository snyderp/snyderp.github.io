import java.util.function.Function;

public class Lambda {
  public static void main(String[] args) {
    Function <String, Function<String, String>> highOrderFunc = (a) -> {
      return (b) ->  {
        return a + b;
      };
    };

  }
}

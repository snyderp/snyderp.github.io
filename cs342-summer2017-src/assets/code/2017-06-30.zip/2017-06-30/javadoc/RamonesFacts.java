import java.util.HashMap;

/**
 * Returns the instrument of the specified band member.
 */
public class RamonesFacts {

  /**
  * Returns the instrument of the specified band member.
  *
  * <p>Returns the instrument that a member of the band the ramones plays.
  *
  * @param member String A possible name of a band member.
  *
  * @return String The instrument a band member plays.  If an unrecognized member,
  *                returns null;
  */
  public static String whichInstrument(String member) {
    HashMap<String, String> memberToInstrument = new HashMap<>();
    mapping.put("Joey", "voice");
    mapping.put("Johnny", "guitar");
    mapping.put("Dee Dee", "bass");
    mapping.put("C.J", "bass");
    mapping.put("Marky", "drums");
    mapping.put("Tommy", "drums");
    mapping.put("Richie", "drums");

    if (mapping.containsKey(member)) {
      return mapping.get(member);
    }

    return null;
  }
}

public class FormattingExample {
  public static void main(String[] args) {

    System.out.println("Whats the secret?");

    Boolean gotSecret = false;
    String input = args[0];

    if (input.equals("garfield"))
      System.out.println("Not quite the secret");

    if (input.equals("t-rex"))
      System.out.println("Really not the secret");

    if (input.equals("felix"))
      System.out.println("Yes, that is the secret");
      gotSecret = true;

    if (gotSecret)
      System.out.println("You got the secret right so here is the $$$$");
    else
      System.out.println("Bad job");
  }
}

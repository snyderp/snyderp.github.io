/**
 * Encrypt and send an array of bytes over the network.
 */
public boolean send(byte[] example, Key aKey) {
  // 1. Encrypt bytes under key
  // 2. Send bytes
}


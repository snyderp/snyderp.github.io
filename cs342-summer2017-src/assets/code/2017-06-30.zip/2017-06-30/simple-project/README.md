Great Library Documentation
===

send method (receives byte[] and boolean, returns boolean)
---
This method sends an array of bytes over the network, using TCP.  It returns a
boolean description of whether the data was received correctly.

If boolean parameter


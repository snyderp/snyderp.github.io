public class Easy {

  public static class EasyAddition {

    public Integer add(Integer someInteger, Integer anotherInteger) {
      Integer newInteger = someInteger + anotherInteger;
      return newInteger;
    }
  }

  public static void main(String[] arg) {
    EasyAddition adder = new EasyAddition();
    System.out.println(adder.add(2, 3));
    System.out.println(adder.add(3, 5));
  }
}

/**
 * Code illustrating how lambda works, how to instantiate an instance of a
 * function, and what the syntax boils down to.
 */

import java.util.function.Function;

public class Lambda {

  public static void main(String[] args) {

    someFunc.apply("THIS WOULD NOT WORK");

    final Function<String, String> myFunc = (String someInput) -> {
      return someInput + someInput;
    };

  }
}

/**
 * How do I use this function object?
 *
 * A. myFunc("A")
 * B. new myFunc("A")
 * C. myFunc.apply("A")
 * D. myFunc.Function("A")
 */

import java.io.File;
import java.util.ArrayList;

public class Tree {

  public class Node {
    String fileName;
    Integer depth = 0;
  }

  public static ArrayList<Node> treeMaker(File a, Integer depth) {
    ArrayList<Node> childPaths = new ArrayList<>();
    Node currentPlace = new Node();
    currentPlace.fileName = a.getName();
    currentPlace.depth = depth;
    childPaths.add(currentPlace);

    if (a.isDirectory()) {
      for (File childFile : a.listFiles()) {
        childPaths.addAll(Tree.treeMaker(childFile, depth + 1));
      }
    }

    return childPaths;
  }

  public static void main(String[] args) {

    File start = new File(args[0]);
    ArrayList<String> treePaths = Tree.treeMaker(start, 0);

    for (String aPath : treePaths) {
      System.out.println(aPath);
    }
  }
}

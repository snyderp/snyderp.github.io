public class Difficult {

  public static class DifficultAddition {
    private Integer priorValue = 0;

    public Integer add(Integer someInteger) {
      Integer newInteger = this.priorValue + someInteger;
      this.priorValue = newInteger;
      return newInteger;
    }
  }

  public static void main(String[] arg) {
    DifficultAddition adder = new DifficultAddition();
    System.out.println(adder.add(2));
    System.out.println(adder.add(3));
  }
}

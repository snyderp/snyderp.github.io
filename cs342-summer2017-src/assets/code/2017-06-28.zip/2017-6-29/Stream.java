import java.util.ArrayList;
import java.util.Arrays;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Stream {
  public static void main(String[] args) {

    ArrayList<String> argsList = new ArrayList<>();
    argsList.addAll(Arrays.asList(args));

    final Function<String, String> myMapFunction = new Function<String, String>() {
      public String apply(String input) {
        return input + "cat";
      }
    };

    Object whatever;
    whatever = argsList.stream().map(myMapFunction).collect(Collectors.joining("-and then-"));

    System.out.println(whatever);
  }
}

/**
 * Example code showing how lambda can be used to simplify code that used
 * to require glue classes.
 */

import java.io.File;
import java.io.FilenameFilter;

public class FileFilter {

  public static void main(String[] args) {

    File dir = new File(args[0]);

    // https://docs.oracle.com/javase/7/docs/api/java/io/File.html#list(java.io.FilenameFilter)
    String[] filelist = dir.list((file, string) -> {
      return string.contains("java");
    });

    for (String aFilename : filelist) {
      System.out.println(aFilename);
    }
  }
}

/**
 * Whats the percentage of useful code here (for the FilenameFilter)?
 *
 * A. 100%
 * B. 80%
 * C. 50%
 * D. 20%
 * E. 0%
 */

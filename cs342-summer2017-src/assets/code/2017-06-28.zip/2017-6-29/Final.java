import java.util.function.Function;
import java.util.function.Predicate;

public class Final {

  public static void main(String[] args) {

    final Predicate<String> coolPredicateBro = new Predicate<String>() {
      public boolean test(String someString) {
        return someString.equals("BART");
      }
    };

    System.out.println(coolPredicateBro.test("BART"));
    System.out.println(coolPredicateBro.test("NOT BART NO MATTER WHAT"));

    final Predicate<String> shortPred = (String a) -> {return a.equals("BART");};

    System.out.println(shortPred.test("BART"));
    System.out.println(shortPred.test("NOT BART NO MATTER WHAT"));
  }

}


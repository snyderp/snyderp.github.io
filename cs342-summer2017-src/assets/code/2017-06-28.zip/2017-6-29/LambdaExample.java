import java.util.function.Function;

public class LambdaExample {
  public static void main(String[] args) {
    Function<String, String> myFunc = (String a) -> {
      return a + "B";
    };

    Function<Object, String> = String::valueOf;

    String newString = myFunc.apply("BART");
    System.out.println(newString);
  }
}

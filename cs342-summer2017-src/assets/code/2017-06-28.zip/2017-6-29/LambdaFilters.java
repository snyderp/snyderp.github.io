/**
 * Code to illustrate how to use lambdas with collections to filter and process
 * collections.
 */

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.function.Function;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class LambdaFilters {

  public static void main(String[] args) {

    ArrayList<String> inputStrings = new ArrayList<>(Arrays.asList(args));

    // First, lets make all the input strings cuter
    Object result = inputStrings.stream()
      .map((a) -> {
        return "🐱" + a + "🐱";
      })
      .filter((a) -> {
        return a.contains("dog");
      })
      .map((a) -> {
        return "✌🏻"+ a;
      });
      .collect(Collectors.joining(" - "));

    // Next, lets print out all the input strings without a loop

    // Next, lets only allow input strings

  }
}

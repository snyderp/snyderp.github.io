import edu.uic.crimecode.Sneakers;

public class Main {
  public static void main(String[] args) {
    Sneakers greatShoe = new Sneakers();
  }
}

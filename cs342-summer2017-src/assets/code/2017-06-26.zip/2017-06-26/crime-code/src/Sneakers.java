/**
 * Class to represent neat shoes.
 */
public class Sneakers {
  private String shoeName;
  private Integer shoeSize;
}

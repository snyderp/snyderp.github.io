package edu.uic.crimecode;

public class Sneakers {
  private String criminalName;
  private Integer yearsInPrison;

  public static void main(String[] args) {
    System.out.println("entry point");
  }
}

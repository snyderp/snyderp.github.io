public class   UglyCode {
  public static void main(String[] args )
  {
      String fakeout="HERE";
      System
        .out
          .println(fakeout);
  }
}

/**

 struct band {
   char   *  name;
   person ** members;
   int       num_members;
 };

  person band_tallest_member(band *a_band) {…}
**/

public class Encapsulation {

  String name;
  Person[] members;
  int num_members;

  public Person getTallestMember() {
    for (Person aPerson: members) {
      // return tallest
    }
  }

  public boolean isMember(String memberName) {
    for (Person aPerson: members) {
      // return tallest
    }
  }

  public static void main(Strings[] args) {
  }
}

public class Polymorphism {

  public static class PeopleDoingThingsTogether {
    private String name;
    public void setName(String name) {
      this.name = name;
    }
  }

  public static class Band extends PeopleDoingThingsTogether {
  }

  public static class Company extends PeopleDoingThingsTogether {
  }

  public void testFunc(PeopleDoingThingsTogether somePeople) {
    somePeople.setName("WHATEVER");
  }

  public static void main(String[] args) {

    Polymorphism me = new Polymorphism();
    PeopleDoingThingsTogether people = new PeopleDoingThingsTogether();
    Company myCompany = new Company();
    me.testFunc(myCompany);
  }
}

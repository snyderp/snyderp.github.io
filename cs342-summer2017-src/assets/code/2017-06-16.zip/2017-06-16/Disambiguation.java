/*
 * Demonstration of how disambiguation happens, and how method signatures are
 * defined in Java.
 */

public class Disambiguation {

  public static class ExampleClass {
    private String sampleString;
  }

  public static void main(Strings[] args) {

    ExampleClass exampleInstance = new ExampleClass();
  }
}

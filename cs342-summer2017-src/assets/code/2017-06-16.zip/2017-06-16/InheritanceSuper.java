/**
 * Demonstration of using super for inheritance, and of abstract methods.
 */

import java.util.ArrayList;

public class InheritanceSuper {

  public static class Cats {
    public ArrayList<String> catAttributes = new ArrayList<>();
    public void setupAttributes() {
      this.catAttributes.add("cute");
      this.catAttributes.add("really nice to pet");
      this.catAttributes.add("great at purring");
    }
  }

  public static class Tiger extends Cats {
    public void setupAttributes() {
      this.setupAttributes();
      this.catAttributes.add("good at killing");
    }
  }

  public static class Tabby extends Cats {
  }

  public static void main(String[] args) {
  }
}

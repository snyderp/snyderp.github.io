public class Abstract {

  private static abstract class Parent {
    public String tryALittleTenderness() {
      return "You look very nice today.";
    }
  }

  private static class Child extends Parent {
  }


  public static void main(String[] args) {
    Child sweetChildOfMine = new Child();
    System.out.println(sweetChildOfMine.tryALittleTenderness());
  }
}

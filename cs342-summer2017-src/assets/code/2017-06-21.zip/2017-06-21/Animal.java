public abstract class Animal {
  public abstract String getDescription();
}

public abstract class Mammal extends Animal {
}

public class Dog extends Mammal {
  public String getDescription() {
    return "I'm an animal that'll live on your floor.";
  }
}

public class Whale extends Mammal {
  public String getDescription() {
    return "I'm an animal the size of several animals.";
  }
}

public class Walrus extends Mammal {
}

// Animal genericAnimal = new Animal();
// Mammal warmAnimal = new Mammal();
Dog pleaseInMyHouseAnimal = new Dog();
Whale notInMyHouseAnimal = new Whale();

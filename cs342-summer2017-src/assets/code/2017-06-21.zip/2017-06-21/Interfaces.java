interface Recordable {
  public Data getRecording();
}

public class Interfaces {

  // Nested classes
  abstract public static class Entertainment {}
  public static class Live extends Entertainment {}
  public static class Opera extends Live implements Recordable {}
  public static class WhirlyBall extends Live {}
  public static class Historical extends Entertainment {}
  public static class Vinyl extends Historical implements Recordable {}
  public static class Book extends Historical {}


  // Methods on Interfaces instances
  public void record(Recordable anItemToRecord) {
    // Capture that special moment forever…
    Data rawData = anItemToRecord.getRecording();
    // And now write it do disk
    // …
  }


  // Program entry point
  public static void main(String[] args) {

    Opera operaExample = new Opera();
    Vinyl vinylExample = new Vinyl();
    WhirlyBall whirlyExample = new WhirlyBall();

    Interfaces interfaceExample = new Interfaces();

    interfaceExample.record(operaExample); // Should be cool
    interfaceExample.record(vinylExample); // Should be cool
    interfaceExample.record(whirlyExample); // Compiler should catch
  }
}
